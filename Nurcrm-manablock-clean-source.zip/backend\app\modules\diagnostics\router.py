from __future__ import annotations

import shutil
from pathlib import Path

from fastapi import APIRouter, Depends
from fastapi.responses import FileResponse
from pydantic import BaseModel
from sqlalchemy import func, select, text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.core.security import get_current_user, require_roles
from app.db.database import get_db_session
from app.db.models import Product, Sale, User

router = APIRouter(prefix="/api/diagnostics", tags=["diagnostics"])
settings = get_settings()


class DiagnosticsInfo(BaseModel):
    app_name: str
    app_version: str
    sqlite_path: str
    sqlite_size_bytes: int
    users_count: int
    products_count: int
    sales_count: int
    db_ok: bool


@router.get("/info", response_model=DiagnosticsInfo)
async def diagnostics_info(
    session: AsyncSession = Depends(get_db_session),
    _: User = Depends(get_current_user),
) -> DiagnosticsInfo:
    db_path = Path(settings.sqlite_path)
    size = db_path.stat().st_size if db_path.exists() else 0
    users_count = (await session.execute(select(func.count()).select_from(User))).scalar_one()
    products_count = (await session.execute(select(func.count()).select_from(Product))).scalar_one()
    sales_count = (await session.execute(select(func.count()).select_from(Sale))).scalar_one()
    db_ok = True
    try:
        await session.execute(text("SELECT 1"))
    except Exception:  # noqa: BLE001
        db_ok = False
    return DiagnosticsInfo(
        app_name=settings.app_name,
        app_version=settings.app_version,
        sqlite_path=str(db_path),
        sqlite_size_bytes=size,
        users_count=int(users_count or 0),
        products_count=int(products_count or 0),
        sales_count=int(sales_count or 0),
        db_ok=db_ok,
    )


@router.get("/export-db")
async def export_db(
    _: User = Depends(require_roles("owner", "admin")),
) -> FileResponse:
    db_path = Path(settings.sqlite_path)
    if not db_path.exists():
        # create empty file copy
        export_path = db_path.with_suffix(".export.db")
        export_path.write_bytes(b"")
        return FileResponse(path=str(export_path), filename="nurcrm-export.db", media_type="application/octet-stream")
    export_path = db_path.parent / "nurcrm-export.db"
    shutil.copy2(db_path, export_path)
    return FileResponse(path=str(export_path), filename="nurcrm-export.db", media_type="application/octet-stream")
