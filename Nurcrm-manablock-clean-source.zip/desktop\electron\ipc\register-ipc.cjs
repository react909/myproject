const { ipcMain, BrowserWindow, app } = require('electron')
const logger = require('../services/logger.cjs')
const appState = require('../services/app-state.cjs')
const updater = require('../updater/updater.cjs')
const deviceManager = require('../devices/device-manager.cjs')
const systemBridge = require('../services/system-bridge.cjs')

function registerIpc(getMainWindow) {
  updater.initUpdater(getMainWindow)

  ipcMain.handle('app-get-meta', () => ({
    version: app.getVersion(),
    isPackaged: app.isPackaged,
    platform: process.platform,
    state: appState.readState(),
  }))

  ipcMain.handle('app-mark-ready', () => {
    if (app.isPackaged) {
      return appState.markApplicationLaunch(app.getVersion())
    }
    return appState.readState()
  })

  ipcMain.handle('logs-read', (_e, channel, limit) => logger.readRecent(channel || 'app', limit || 50))

  ipcMain.handle('updater-get-info', () => ({
    currentVersion: updater.getCurrentVersion(),
    changelog: updater.loadChangelog(),
  }))

  ipcMain.handle('updater-check', async (_e, feedUrl) => updater.checkForUpdates(feedUrl))
  ipcMain.handle('updater-download', async () => updater.downloadUpdate())
  ipcMain.handle('updater-install', () => updater.quitAndInstall())
  ipcMain.handle('updater-changelog', (_e, version) => updater.getChangelogFor(version))

  ipcMain.handle('devices-apply-settings', (_e, settings) => {
    deviceManager.applySettings(settings)
    return { ok: true }
  })

  ipcMain.handle('devices-status', () => deviceManager.getStatus())
  ipcMain.handle('devices-test-printer', (_e, settings) => deviceManager.testPrinter(settings))
  ipcMain.handle('devices-test-scale', (_e, settings) => deviceManager.testScale(settings))
  ipcMain.handle('devices-diagnostics', (_e, settings) => deviceManager.runFullDiagnostics(settings))
  ipcMain.handle('devices-print-receipt', (_e, payload, settings) =>
    deviceManager.printReceipt(payload, settings),
  )
  ipcMain.handle('devices-list-ports', () => deviceManager.listSerialPorts())
  ipcMain.handle('devices-scale-live', () => deviceManager.getLiveWeight())
  ipcMain.handle('devices-scale-read', () => deviceManager.requestScaleRead())
  ipcMain.handle('devices-scale-set', (_e, kg) => {
    deviceManager.setScaleWeightKg(kg)
    return deviceManager.getLiveWeight()
  })

  ipcMain.handle('devices-report-barcode', (_e, code) => {
    deviceManager.reportBarcodeScan(code)
    return deviceManager.getStatus()
  })

  ipcMain.handle('devices-reconnect', (_e, settings) =>
    deviceManager.reconnectDevices(settings),
  )

  ipcMain.handle('system-set-autolaunch', (_e, enabled) =>
    systemBridge.setAutoLaunch(enabled),
  )

  ipcMain.handle('system-open-touch-keyboard', () => ({
    ok: true,
    message: 'Используйте встроенную VirtualKeyboard в интерфейсе',
  }))

  ipcMain.handle('system-apply-kiosk', (event, enabled) => {
    const win = BrowserWindow.fromWebContents(event.sender)
    systemBridge.applyKioskToWindow(win, { alwaysFullscreen: !!enabled })
    return { ok: true }
  })

  ipcMain.handle('window-get-fullscreen', (event) => {
    const win = BrowserWindow.fromWebContents(event.sender)
    return win && !win.isDestroyed() ? win.isFullScreen() : false
  })

  ipcMain.handle('window-set-fullscreen', (event, flag) => {
    const win = BrowserWindow.fromWebContents(event.sender)
    if (win && !win.isDestroyed()) win.setFullScreen(!!flag)
  })

  ipcMain.handle('window-toggle-fullscreen', async (event) => {
    const win = BrowserWindow.fromWebContents(event.sender)
    if (!win || win.isDestroyed()) return false
    win.setFullScreen(!win.isFullScreen())
    await new Promise((r) => setImmediate(r))
    return win.isFullScreen()
  })

  ipcMain.handle('window-minimize', (event) => {
    const win = BrowserWindow.fromWebContents(event.sender)
    if (win && !win.isDestroyed()) {
      if (win.isFullScreen()) win.setFullScreen(false)
      win.minimize()
    }
  })

  ipcMain.handle('window-close', (event) => {
    const win = BrowserWindow.fromWebContents(event.sender)
    if (win && !win.isDestroyed()) win.close()
  })

  logger.append('app', 'info', 'IPC handlers registered')
}

module.exports = { registerIpc }
