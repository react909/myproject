# NurCRM Offline — Local Backend

Fully offline FastAPI + SQLite POS API. No external network required.

## Dev

```bash
cd backend
pip install -r requirements.txt
set SQLITE_PATH=%USERPROFILE%\AppData\Roaming\NurCRM Manablock\nurcrm.db
python main.py
```

API: `http://127.0.0.1:8000`  
Health: `GET /health`  
First run: `GET /api/setup/status`, `POST /api/setup/init`

## Build exe (for Electron packaging)

```powershell
.\build.ps1
```

Output: `dist/backend/backend.exe` (bundled by electron-builder as `resources/backend`).
