import { useCallback, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { motion, AnimatePresence } from "framer-motion";
import "./VirtualKeyboard.css";

function updateFieldValue(
  input: HTMLInputElement | HTMLTextAreaElement,
  value: string,
) {
  const proto =
    input instanceof HTMLTextAreaElement
      ? window.HTMLTextAreaElement.prototype
      : window.HTMLInputElement.prototype;
  const descriptor = Object.getOwnPropertyDescriptor(proto, "value");
  descriptor?.set?.call(input, value);
  input.dispatchEvent(new Event("input", { bubbles: true }));
}

// ===== РАСКЛАДКИ =====

const RU_ROWS_LOWER = [
  ["й", "ц", "у", "к", "е", "н", "г", "ш", "щ", "з", "х"],
  ["ф", "ы", "в", "а", "п", "р", "о", "л", "д", "ж", "э"],
  ["я", "ч", "с", "м", "и", "т", "ь", "б", "ю", "ё"],
];

const RU_ROWS_UPPER = [
  ["Й", "Ц", "У", "К", "Е", "Н", "Г", "Ш", "Щ", "З", "Х"],
  ["Ф", "Ы", "В", "А", "П", "Р", "О", "Л", "Д", "Ж", "Э"],
  ["Я", "Ч", "С", "М", "И", "Т", "Ь", "Б", "Ю", "Ё"],
];

const EN_ROWS_LOWER = [
  ["q", "w", "e", "r", "t", "y", "u", "i", "o", "p"],
  ["a", "s", "d", "f", "g", "h", "j", "k", "l"],
  ["z", "x", "c", "v", "b", "n", "m"],
];

const EN_ROWS_UPPER = [
  ["Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"],
  ["A", "S", "D", "F", "G", "H", "J", "K", "L"],
  ["Z", "X", "C", "V", "B", "N", "M"],
];

const SYMBOLS_PAGE_1 = [
  ["!", "@", "#", "$", "%", "^", "&", "*", "(", ")"],
  ["-", "_", "+", "=", "{", "}", "[", "]", "\\", "|"],
  [";", ":", "'", '"', ",", ".", "<", ">", "/", "?"],
];

const SYMBOLS_PAGE_2 = [
  ["€", "£", "¥", "₽", "¢", "©", "®", "™", "°", "±"],
  ["~", "`", "§", "¶", "†", "‡", "•", "…", "‰", "′"],
  ["←", "→", "↑", "↓", "↔", "✓", "✗", "★", "☆", "♪"],
];

// Правый калькуляторный блок
const CALC_ROWS = [
  ["7", "8", "9"],
  ["4", "5", "6"],
  ["1", "2", "3"],
  ["0", ".", ","],
];

type KeyboardLayout = "russian" | "english" | "symbols1" | "symbols2";
type KeyboardSize = "small" | "medium" | "large";

// ===== ИКОНКИ =====

function KeyboardOpenIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <rect x="2" y="5" width="20" height="14" rx="2" />
      <path d="M5 8h2M11 8h2M17 8h2M5 12h8M15 12h2M5 16h14" />
    </svg>
  );
}

function CloseIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2.5"
    >
      <path d="M18 6L6 18M6 6l12 12" />
    </svg>
  );
}

// function EnterIcon() {
//   return (
//     <svg
//       viewBox="0 0 24 24"
//       fill="none"
//       stroke="currentColor"
//       strokeWidth="2.5"
//     >
//       <polyline points="23 4 23 10 17 10" />
//       <path d="M20.49 15a9 9 0 1 1 .12-4.49" />
//     </svg>
//   );
// }

export type VirtualKeyboardProps = {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  onEnter?: () => void | Promise<void>;
};

export function VirtualKeyboard({
  isOpen,
  onOpenChange,
  onEnter,
}: VirtualKeyboardProps) {
  const [layout, setLayout] = useState<KeyboardLayout>("russian");
  const [capsLock, setCapsLock] = useState(false);
  const [shift, setShift] = useState(false);
  const [keyboardSize, setKeyboardSize] = useState<KeyboardSize>("large");

  const activeInputRef = useRef<HTMLInputElement | HTMLTextAreaElement | null>(
    null,
  );
  const backspaceTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(
    null,
  );
  const backspaceIntervalRef = useRef<ReturnType<typeof setInterval> | null>(
    null,
  );
  const isBackspacePressedRef = useRef(false);

  useEffect(() => {
    const handleFocusIn = (e: FocusEvent) => {
      const target = e.target as HTMLElement;
      if (
        target instanceof HTMLInputElement ||
        target instanceof HTMLTextAreaElement
      ) {
        activeInputRef.current = target;
      }
    };
    document.addEventListener("focusin", handleFocusIn);
    return () => document.removeEventListener("focusin", handleFocusIn);
  }, []);

  const insertText = useCallback((text: string) => {
    const input = activeInputRef.current;
    if (!input) return;
    const start = input.selectionStart ?? input.value.length;
    const end = input.selectionEnd ?? input.value.length;
    const newValue =
      input.value.slice(0, start) + text + input.value.slice(end);
    updateFieldValue(input, newValue);
    const pos = start + text.length;
    input.focus();
    input.setSelectionRange(pos, pos);
  }, []);

  const handleBackspaceOnce = useCallback(() => {
    const input = activeInputRef.current;
    if (!input) return;
    const start = input.selectionStart ?? input.value.length;
    const end = input.selectionEnd ?? input.value.length;
    if (start === end && start === 0) return;
    let newValue: string;
    let newCursorPos: number;
    if (start === end) {
      newValue = input.value.slice(0, start - 1) + input.value.slice(start);
      newCursorPos = start - 1;
    } else {
      newValue = input.value.slice(0, start) + input.value.slice(end);
      newCursorPos = start;
    }
    updateFieldValue(input, newValue);
    input.focus();
    input.setSelectionRange(newCursorPos, newCursorPos);
  }, []);

  const startBackspaceHold = useCallback(() => {
    if (isBackspacePressedRef.current) return;
    isBackspacePressedRef.current = true;
    handleBackspaceOnce();
    backspaceTimeoutRef.current = setTimeout(() => {
      backspaceIntervalRef.current = setInterval(handleBackspaceOnce, 50);
    }, 300);
  }, [handleBackspaceOnce]);

  const stopBackspaceHold = useCallback(() => {
    isBackspacePressedRef.current = false;
    if (backspaceTimeoutRef.current) clearTimeout(backspaceTimeoutRef.current);
    if (backspaceIntervalRef.current)
      clearInterval(backspaceIntervalRef.current);
  }, []);

  const handleKey = useCallback(
    (key: string) => {
      if (key === "SPACE") {
        insertText(" ");
      } else if (key === "ENTER") {
        void Promise.resolve(onEnter?.());
      } else {
        insertText(key);
      }
      // После нажатия сбрасываем shift (но не capsLock)
      if (shift && !capsLock) {
        setShift(false);
      }
    },
    [insertText, shift, capsLock, onEnter],
  );

  const toggleShift = () => {
    if (capsLock) {
      setCapsLock(false);
      setShift(false);
    } else {
      setShift((s) => !s);
    }
  };

  const toggleCapsLock = () => {
    setCapsLock((c) => {
      if (c) setShift(false);
      return !c;
    });
    setShift(false);
  };

  // Определяем строки для левой части
  const isUpper = capsLock || shift;

  const getLetterRows = (): string[][] => {
    if (layout === "russian") return isUpper ? RU_ROWS_UPPER : RU_ROWS_LOWER;
    if (layout === "english") return isUpper ? EN_ROWS_UPPER : EN_ROWS_LOWER;
    if (layout === "symbols1") return SYMBOLS_PAGE_1;
    return SYMBOLS_PAGE_2;
  };

  const letterRows = getLetterRows();
  const showCalc = layout === "russian" || layout === "english";

  const layer = (
    <div className="virtual-keyboard-portal">
      {/* Кнопка открытия */}
      <AnimatePresence>
        {!isOpen && (
          <motion.button
            type="button"
            className="keyboard-open-btn"
            onClick={() => onOpenChange(true)}
            initial={{ x: -30, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: -30, opacity: 0 }}
            transition={{ duration: 0.25 }}
          >
            <KeyboardOpenIcon />
          </motion.button>
        )}
      </AnimatePresence>

      {/* Клавиатура */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            className="keyboard-overlay"
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ duration: 0.35 }}
          >
            <div className={`keyboard-container size-${keyboardSize}`}>
              {/* ===== HEADER ===== */}
              <div className="keyboard-header">
                <div className="header-left">
                  <button
                    className={`tab-btn ${layout === "russian" ? "active" : ""}`}
                    onClick={() => setLayout("russian")}
                  >
                    АБВ
                  </button>
                  <button
                    className={`tab-btn ${layout === "english" ? "active" : ""}`}
                    onClick={() => setLayout("english")}
                  >
                    ABC
                  </button>
                  <button
                    className={`tab-btn ${layout === "symbols1" ? "active" : ""}`}
                    onClick={() => setLayout("symbols1")}
                  >
                    #+=
                  </button>
                  <button
                    className={`tab-btn ${layout === "symbols2" ? "active" : ""}`}
                    onClick={() => setLayout("symbols2")}
                  >
                    ☺
                  </button>
                </div>

                <div className="header-right">
                  {(["small", "medium", "large"] as KeyboardSize[]).map(
                    (size) => (
                      <button
                        key={size}
                        className={`size-tab ${keyboardSize === size ? "active" : ""}`}
                        onClick={() => setKeyboardSize(size)}
                      >
                        {size === "small" ? "S" : size === "medium" ? "M" : "L"}
                      </button>
                    ),
                  )}

                  <motion.button
                    className="close-btn"
                    onClick={() => onOpenChange(false)}
                    whileTap={{ scale: 0.92 }}
                  >
                    <CloseIcon />
                  </motion.button>
                </div>
              </div>

              {/* ===== ТЕЛО ===== */}
              <div className="keyboard-body">
                <div className="keyboard-split">
                  {/* ——— ЛЕВАЯ ЧАСТЬ: буквы ——— */}
                  <div className="split-letters">
                    <div className="keys-container">
                      {letterRows.map((row, rowIndex) => (
                        <div key={rowIndex} className="key-row">
                          {row.map((key) => (
                            <button
                              key={key}
                              type="button"
                              className="key"
                              onClick={() => handleKey(key)}
                            >
                              {key}
                            </button>
                          ))}
                        </div>
                      ))}

                      {/* Функциональный ряд */}
                      <div className="key-row function-keys">
                        {showCalc && (
                          <>
                            <button
                              type="button"
                              className={`key special ${shift && !capsLock ? "active" : ""}`}
                              onClick={toggleShift}
                            >
                              ⇧ Shift
                            </button>
                            <button
                              type="button"
                              className={`key special ${capsLock ? "active" : ""}`}
                              onClick={toggleCapsLock}
                            >
                              ⇪ Caps
                            </button>
                          </>
                        )}

                        {(layout === "symbols1" || layout === "symbols2") && (
                          <button
                            type="button"
                            className="key special"
                            onClick={() =>
                              setLayout(
                                layout === "symbols1" ? "symbols2" : "symbols1",
                              )
                            }
                          >
                            {layout === "symbols1" ? "☺" : "↶"}
                          </button>
                        )}

                        <button
                          type="button"
                          className="key special space"
                          onClick={() => handleKey("SPACE")}
                        >
                          Пробел
                        </button>

                        <button
                          type="button"
                          className="key special backspace"
                          onMouseDown={startBackspaceHold}
                          onMouseUp={stopBackspaceHold}
                          onMouseLeave={stopBackspaceHold}
                          onTouchStart={startBackspaceHold}
                          onTouchEnd={stopBackspaceHold}
                          onTouchCancel={stopBackspaceHold}
                        >
                          ⌫
                        </button>

                        <button
                          type="button"
                          className="key special enter"
                          onClick={() => handleKey("ENTER")}
                        >
                          <svg
                            xmlns="http://w3.org"
                            width="24"
                            height="24"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <polyline points="9 10 4 15 9 20" />
                            <path d="M20 4v7a4 4 0 0 1-4 4H4" />
                          </svg>
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* ——— ПРАВАЯ ЧАСТЬ: калькулятор ——— */}
                  {showCalc && (
                    <div className="split-calc">
                      <div className="calc-grid">
                        {CALC_ROWS.map((row, rowIndex) => (
                          <div key={rowIndex} className="calc-row">
                            {row.map((key) => (
                              <button
                                key={key}
                                type="button"
                                className="key calc-key"
                                onClick={() => handleKey(key)}
                              >
                                {key}
                              </button>
                            ))}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );

  return createPortal(layer, document.body);
}
