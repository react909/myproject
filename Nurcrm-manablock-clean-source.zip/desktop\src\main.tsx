import React from 'react'
import ReactDOM from 'react-dom/client'
import { App } from './App'
import './style.css'

const root = document.querySelector<HTMLDivElement>('#app')!
const tree = import.meta.env.PROD ? <App /> : (
  <React.StrictMode>
    <App />
  </React.StrictMode>
)

ReactDOM.createRoot(root).render(tree)
