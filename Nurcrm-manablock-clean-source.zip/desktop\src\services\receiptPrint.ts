import { loadSettings } from '../settings/appSettings'
import { printReceipt } from './devices/device.client'
import type { ReceiptPrintPayload as TemplatePayload } from '../receipt/receiptTemplate'
import type { Receipt } from '../pages/Receipts/types'
import type { CartItem } from '../right-panel/helpers'
import { formatMoney, getLineDiscountAmount, getLineNetTotal, isProductCartLine } from '../right-panel/helpers'
import type { CrmShiftSummary } from './posShift'

export type ReceiptPrintPayload = TemplatePayload

function paymentLabel(method?: string): string {
  if (method === 'card') return 'Карта'
  if (method === 'mixed') return 'Смешанная'
  if (method === 'debt') return 'В долг'
  return 'Наличные'
}

export function cartLinesToPrintPayload(
  lines: CartItem[],
  opts: {
    cashier: string
    total: number
    discountTotal?: number
    date?: string
    thankYou?: string
    paymentMethod?: string
    storeName?: string
    cashReceived?: number
    change?: number
  },
): ReceiptPrintPayload {
  const settings = loadSettings()
  const products = lines.filter(isProductCartLine)
  const store = settings.paymentQr
  const gross = products.reduce((s, l) => s + getLineGrossSafe(l), 0)
  const discountTotal = opts.discountTotal ?? 0
  const method = opts.paymentMethod ?? 'Наличные'
  const showCash = method.includes('Налич') || method === 'Смешанная'
  return {
    storeName: opts.storeName ?? store.storeName ?? 'Мой магазин',
    storeAddress: store.storeAddress?.trim() || undefined,
    storePhone: store.storePhone?.trim() || undefined,
    lines: products.map((l) => {
      const lineDiscount = getLineDiscountAmount(l)
      const net = getLineNetTotal(l)
      return {
        name: l.name,
        qty: l.type === 'weight' ? l.weightKg.toFixed(3) : String(l.quantity),
        unit: l.type === 'weight' ? 'кг' : 'шт',
        price: formatMoney(l.price),
        sum: formatMoney(net),
        discount: lineDiscount > 0 ? `${formatMoney(lineDiscount)} сом` : undefined,
      }
    }),
    gross: discountTotal > 0 ? `${formatMoney(gross)} сом` : undefined,
    total: `${formatMoney(opts.total)} сом`,
    discount:
      discountTotal > 0 ? `${formatMoney(discountTotal)} сом` : undefined,
    paymentMethod: method,
    cash:
      showCash && opts.cashReceived != null && opts.cashReceived > 0
        ? `${formatMoney(opts.cashReceived)} сом`
        : undefined,
    change:
      showCash && opts.change != null && opts.change > 0
        ? `${formatMoney(opts.change)} сом`
        : undefined,
    cashier: opts.cashier,
    date: opts.date ?? new Date().toLocaleString('ru-RU'),
    thankYou: opts.thankYou ?? 'Спасибо за покупку!',
  }
}

function getLineGrossSafe(l: CartItem): number {
  if (l.isGroupHeader) return 0
  const raw = l.type === 'piece' ? l.price * l.quantity : l.price * l.weightKg
  return Math.round(raw * 100) / 100
}

export function historyReceiptToPrintPayload(receipt: Receipt): ReceiptPrintPayload {
  const settings = loadSettings()
  const store = settings.paymentQr
  const method = paymentLabel(receipt.paymentMethod)
  const showCash = receipt.paymentMethod === 'cash' || receipt.paymentMethod === 'mixed'
  return {
    storeName: store.storeName ?? 'Мой магазин',
    storeAddress: store.storeAddress?.trim() || undefined,
    storePhone: store.storePhone?.trim() || undefined,
    lines: receipt.items.map((item) => ({
      name: item.name,
      qty: item.isWeight
        ? `${item.quantity.toFixed(3)}`
        : `${Math.round(item.quantity)}`,
      unit: item.isWeight ? 'кг' : 'шт',
      price: formatMoney(item.price),
      sum: formatMoney(item.total),
    })),
    total: `${formatMoney(receipt.total)} сом`,
    discount:
      receipt.discount > 0 ? `${formatMoney(receipt.discount)} сом` : undefined,
    paymentMethod: method,
    cash:
      showCash && receipt.cashGiven != null && receipt.cashGiven > 0
        ? `${formatMoney(receipt.cashGiven)} сом`
        : undefined,
    change:
      showCash && receipt.change != null && receipt.change > 0
        ? `${formatMoney(receipt.change)} сом`
        : undefined,
    cashier: receipt.cashier,
    date: `${receipt.date} ${receipt.time}`,
    thankYou: `Дубликат · ${receipt.number}`,
  }
}

export function buildShiftCloseReceiptPayload(
  summary: {
    cashier: string
    openedAt?: string
    closedAt: string
    openCash: number
    closeCash: number
    salesCount: number
    salesTotal: number
    cashboxName?: string
  },
): ReceiptPrintPayload {
  const settings = loadSettings()
  const store = settings.paymentQr
  const fmt = (n: number) => `${formatMoney(n)} сом`
  return {
    storeName: store.storeName ?? 'Мой магазин',
    storeAddress: store.storeAddress?.trim() || undefined,
    storePhone: store.storePhone?.trim() || undefined,
    receiptNumber: 'Z-ОТЧЁТ',
    date: new Date(summary.closedAt).toLocaleString('ru-RU'),
    lines: [
      { name: 'Открытие смены', sum: fmt(summary.openCash) },
      { name: 'Продаж (чеков)', sum: String(summary.salesCount) },
      { name: 'Выручка за смену', sum: fmt(summary.salesTotal) },
      { name: 'В кассе при закрытии', sum: fmt(summary.closeCash) },
      ...(summary.cashboxName
        ? [{ name: 'Касса', sum: summary.cashboxName }]
        : []),
    ],
    total: fmt(summary.salesTotal),
    paymentMethod: 'Закрытие смены',
    cashier: summary.cashier,
    thankYou: summary.openedAt
      ? `Смена: ${new Date(summary.openedAt).toLocaleString('ru-RU')}`
      : 'Смена закрыта',
  }
}

export function shiftSummaryToClosePayload(
  shift: CrmShiftSummary,
  cashier: string,
  closeCash: number,
  openedAt?: string,
  closedAt?: string,
): ReceiptPrintPayload {
  return buildShiftCloseReceiptPayload({
    cashier,
    openedAt,
    closedAt: closedAt ?? new Date().toISOString(),
    openCash: shift.openingCash,
    closeCash,
    salesCount: shift.salesCount,
    salesTotal: shift.salesTotal,
    cashboxName: shift.cashboxName,
  })
}

export async function printShiftCloseReceipt(payload: ReceiptPrintPayload) {
  const settings = loadSettings()
  if (!settings.printer.enabled) {
    return { ok: false, message: 'Принтер отключён' }
  }
  try {
    return await printReceipt(payload, settings)
  } catch (err: any) {
    return { ok: false, message: err?.message ?? 'Ошибка печати Z-отчёта' }
  }
}

export async function printDuplicateReceipt(receipt: Receipt) {
  const settings = loadSettings()
  if (!settings.printer.enabled) {
    return { ok: false, message: 'Включите принтер в Настройках → Печать чеков' }
  }
  try {
    return await printReceipt(historyReceiptToPrintPayload(receipt), settings)
  } catch (err: any) {
    return { ok: false, message: err?.message ?? 'Ошибка печати' }
  }
}

export async function printCartReceipt(
  lines: CartItem[],
  opts: {
    cashier: string
    total: number
    discountTotal?: number
    paymentMethod?: string
    cashReceived?: number
    change?: number
  },
) {
  const settings = loadSettings()
  if (!settings.printer.enabled) {
    return { ok: false, message: 'Принтер отключён в настройках' }
  }
  try {
    return await printReceipt(cartLinesToPrintPayload(lines, opts), settings)
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Ошибка печати'
    return { ok: false, message: msg }
  }
}

export async function printDebtPaymentReceipt(opts: {
  clientName: string
  phone?: string
  debtNumber: string
  paidAmount: number
  remainingBalance: number
  method: 'cash' | 'card'
  cashReceived?: number
  change?: number
  cashier: string
}) {
  const settings = loadSettings()
  if (!settings.printer.enabled) {
    return { ok: false, message: 'Принтер отключён в настройках' }
  }
  const store = settings.paymentQr
  const methodLabel = opts.method === 'card' ? 'Безнал' : 'Наличные'
  const payload: ReceiptPrintPayload = {
    storeName: store.storeName ?? 'Мой магазин',
    storeAddress: store.storeAddress?.trim() || undefined,
    storePhone: store.storePhone?.trim() || undefined,
    receiptNumber: `ДОЛГ ${opts.debtNumber}`,
    date: new Date().toLocaleString('ru-RU'),
    lines: [
      {
        name: `Погашение долга · ${opts.clientName}`,
        sum: `${formatMoney(opts.paidAmount)} сом`,
      },
      ...(opts.phone ? [{ name: `Телефон: ${opts.phone}`, sum: '' }] : []),
      ...(opts.remainingBalance > 0.01
        ? [{ name: 'Остаток долга', sum: `${formatMoney(opts.remainingBalance)} сом` }]
        : []),
    ],
    total: `${formatMoney(opts.paidAmount)} сом`,
    paymentMethod: methodLabel,
    cash:
      opts.method === 'cash' && opts.cashReceived != null && opts.cashReceived > 0
        ? `${formatMoney(opts.cashReceived)} сом`
        : undefined,
    change:
      opts.method === 'cash' && opts.change != null && opts.change > 0
        ? `${formatMoney(opts.change)} сом`
        : undefined,
    cashier: opts.cashier,
    thankYou: opts.remainingBalance > 0.01 ? 'Частичное погашение долга' : 'Долг погашен полностью',
  }
  try {
    return await printReceipt(payload, settings)
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Ошибка печати'
    return { ok: false, message: msg }
  }
}
