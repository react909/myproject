import { Link } from 'react-router-dom'

type Props = {
  period: 'day' | 'week' | 'month'
  onPeriodChange: (p: 'day' | 'week' | 'month') => void
  onRefresh: () => void
  onExport?: () => void
  onClear?: () => void
  isRefreshing: boolean
  embedded?: boolean
  revenue: number
  revenueChange: string
  revenuePositive: boolean
}

const PERIODS = [
  { id: 'day'   as const, label: 'День'    },
  { id: 'week'  as const, label: 'Неделя'  },
  { id: 'month' as const, label: 'Месяц'   },
]

export function FinanceHeader({
  period, onPeriodChange, onRefresh, onExport, onClear,
  isRefreshing, embedded, revenue,
  revenueChange, revenuePositive,
}: Props) {
  return (
    <header className={`fh${embedded ? ' fh--embedded' : ''}`}>
      <div className="fh__top">
        {!embedded && (
          <Link to="/" className="fh__back">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" strokeWidth="2.2"
              strokeLinecap="round" strokeLinejoin="round">
              <path d="M19 12H5m0 0 7 7m-7-7 7-7"/>
            </svg>
            Касса
          </Link>
        )}

        <div className="fh__title-block">
          <h1 className="fh__title">Финансы</h1>
          <p className="fh__sub">Полный финансовый обзор</p>
        </div>

        <div className="fh__actions">
          {/* Переключатель периода */}
          <div className="fh__periods">
            {PERIODS.map(p => (
              <button
                key={p.id}
                type="button"
                onClick={() => onPeriodChange(p.id)}
                className={`fh__period-btn${period === p.id ? ' fh__period-btn--on' : ''}`}
              >
                {p.label}
              </button>
            ))}
          </div>

          {onExport ? (
            <button
              type="button"
              onClick={onExport}
              className="fh__export"
              title="Скачать отчёт CSV"
            >
              CSV
            </button>
          ) : null}

          {/* Кнопка обновить */}
          <button
            type="button"
            onClick={onRefresh}
            disabled={isRefreshing}
            className={`fh__refresh${isRefreshing ? ' fh__refresh--spin' : ''}`}
            title="Обновить"
          >
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" strokeWidth="2.2"
              strokeLinecap="round" strokeLinejoin="round">
              <path d="M1 4v6h6M23 20v-6h-6"/>
              <path d="M20.49 9A9 9 0 0 0 5.64 5.64L1 10m22 4-4.64 4.36A9 9 0 0 1 3.51 15"/>
            </svg>
          </button>
          {onClear ? (
            <button
              type="button"
              onClick={onClear}
              className="fh__refresh"
              title="Очистить локальную статистику"
            >
              0
            </button>
          ) : null}
        </div>
      </div>

      {/* Быстрая плашка с главной метрикой */}
      <div className="fh__kpi-strip">
        <div className="fh__kpi">
          <span className="fh__kpi-label">Выручка за период</span>
          <div className="fh__kpi-row">
            <span className="fh__kpi-value">
              {revenue.toLocaleString('ru-RU')} сом
            </span>
            <span className={`fh__kpi-badge${revenuePositive ? ' fh__kpi-badge--up' : ' fh__kpi-badge--down'}`}>
              {revenuePositive ? '↑' : '↓'} {revenueChange}
            </span>
          </div>
        </div>

        <div className="fh__kpi-divider" />

        <div className="fh__kpi">
          <span className="fh__kpi-label">Статус смены</span>
          <div className="fh__kpi-row">
            <span className="fh__kpi-status">
              <span className="fh__kpi-dot" />
              Открыта
            </span>
          </div>
        </div>

        <div className="fh__kpi-divider" />

        <div className="fh__kpi">
          <span className="fh__kpi-label">Последнее обновление</span>
          <span className="fh__kpi-time">
            {new Date().toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}
          </span>
        </div>
      </div>
    </header>
  )
}