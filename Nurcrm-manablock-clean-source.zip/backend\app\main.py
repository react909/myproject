from __future__ import annotations

import asyncio
import sys

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

from app.core.config import get_settings
from app.db.database import init_db
from app.modules.analytics.router import router as analytics_router
from app.modules.auth.router import router as auth_router
from app.modules.diagnostics.router import router as diagnostics_router
from app.modules.products.router import router as products_router
from app.modules.sales.router import router as sales_router
from app.modules.settings.router import router as settings_router
from app.modules.setup.router import router as setup_router
from app.modules.shifts.router import router as shifts_router
from app.modules.stock.router import router as stock_router
from app.modules.users.router import router as users_router

settings = get_settings()

app = FastAPI(title=settings.app_name, version=settings.app_version)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://127.0.0.1:5173",
        "http://localhost:5173",
        "http://127.0.0.1:4173",
        "http://localhost:4173",
        "file://",
        "null",
        "*",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def on_startup() -> None:
    await init_db()


@app.get("/health")
async def healthcheck() -> dict[str, str]:
    return {"status": "ok", "app": settings.app_name, "version": settings.app_version}


app.include_router(setup_router)
app.include_router(auth_router)
app.include_router(users_router)
app.include_router(products_router)
app.include_router(stock_router)
app.include_router(sales_router)
app.include_router(shifts_router)
app.include_router(settings_router)
app.include_router(analytics_router)
app.include_router(diagnostics_router)
