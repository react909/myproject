from __future__ import annotations

from datetime import datetime
from typing import Optional
from uuid import uuid4

from sqlalchemy import (
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


class StoreSettings(Base):
    __tablename__ = "store_settings"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    # Stable local identifier allows a future Cloud migration without
    # replacing local primary keys or losing offline data.
    installation_id: Mapped[str] = mapped_column(
        String(36), nullable=False, default=lambda: str(uuid4()), unique=True
    )
    edition: Mapped[str] = mapped_column(String(16), nullable=False, default="start")
    company_name: Mapped[str] = mapped_column(String(255), nullable=False, default="")
    store_name: Mapped[str] = mapped_column(String(255), nullable=False, default="Мой магазин")
    owner_name: Mapped[str] = mapped_column(String(255), nullable=False, default="")
    inn: Mapped[str] = mapped_column(String(32), nullable=False, default="")
    email: Mapped[str] = mapped_column(String(255), nullable=False, default="")
    currency: Mapped[str] = mapped_column(String(16), nullable=False, default="KGS")
    currency_label: Mapped[str] = mapped_column(String(32), nullable=False, default="сом")
    address: Mapped[str] = mapped_column(String(512), nullable=False, default="")
    phone: Mapped[str] = mapped_column(String(64), nullable=False, default="")
    setup_completed: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    setup_version: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    username: Mapped[str] = mapped_column(String(255), unique=True, index=True, nullable=False)
    full_name: Mapped[str] = mapped_column(String(255), nullable=False, default="")
    hashed_password: Mapped[str] = mapped_column(String(255), nullable=False)
    role: Mapped[str] = mapped_column(String(32), nullable=False, default="cashier")  # owner|admin|cashier
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class Category(Base):
    __tablename__ = "categories"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    sort_order: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    products: Mapped[list["Product"]] = relationship(back_populates="category")


class Product(Base):
    __tablename__ = "products"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    barcode: Mapped[str] = mapped_column(String(64), nullable=False, default="", index=True)
    extra_barcodes: Mapped[str] = mapped_column(Text, nullable=False, default="")  # comma-separated
    kind: Mapped[str] = mapped_column(String(32), nullable=False, default="piece")  # piece|weight|service
    unit: Mapped[str] = mapped_column(String(16), nullable=False, default="шт")
    price: Mapped[float] = mapped_column(Float, nullable=False, default=0)
    wholesale_price: Mapped[float] = mapped_column(Float, nullable=False, default=0)
    cost_price: Mapped[float] = mapped_column(Float, nullable=False, default=0)
    stock_qty: Mapped[float] = mapped_column(Float, nullable=False, default=0)
    category_id: Mapped[Optional[int]] = mapped_column(ForeignKey("categories.id"), nullable=True)
    image: Mapped[str] = mapped_column(Text, nullable=False, default="")
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    category: Mapped[Optional[Category]] = relationship(back_populates="products")
    stock_moves: Mapped[list["StockMove"]] = relationship(back_populates="product")


class StockMove(Base):
    __tablename__ = "stock_moves"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id"), nullable=False, index=True)
    qty_delta: Mapped[float] = mapped_column(Float, nullable=False)
    reason: Mapped[str] = mapped_column(String(64), nullable=False)  # sale|purchase|adjust|return
    ref_type: Mapped[str] = mapped_column(String(32), nullable=False, default="")
    ref_id: Mapped[str] = mapped_column(String(64), nullable=False, default="")
    note: Mapped[str] = mapped_column(String(512), nullable=False, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    user_id: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"), nullable=True)

    product: Mapped[Product] = relationship(back_populates="stock_moves")


class Shift(Base):
    __tablename__ = "shifts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    opened_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    closed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    open_cash: Mapped[float] = mapped_column(Float, nullable=False, default=0)
    close_cash: Mapped[float] = mapped_column(Float, nullable=False, default=0)
    sales_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    sales_total: Mapped[float] = mapped_column(Float, nullable=False, default=0)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    status: Mapped[str] = mapped_column(String(16), nullable=False, default="open")  # open|closed
    cashbox_name: Mapped[str] = mapped_column(String(128), nullable=False, default="Основная")


class Sale(Base):
    __tablename__ = "sales"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    doc_number: Mapped[int] = mapped_column(Integer, nullable=False, index=True)
    status: Mapped[str] = mapped_column(String(32), nullable=False, default="paid")  # paid|debt|canceled|refunded|partial_refund
    payment_method: Mapped[str] = mapped_column(String(32), nullable=False, default="cash")
    subtotal: Mapped[float] = mapped_column(Float, nullable=False, default=0)
    discount_total: Mapped[float] = mapped_column(Float, nullable=False, default=0)
    total: Mapped[float] = mapped_column(Float, nullable=False, default=0)
    cash_received: Mapped[float] = mapped_column(Float, nullable=False, default=0)
    card_amount: Mapped[float] = mapped_column(Float, nullable=False, default=0)
    change_amount: Mapped[float] = mapped_column(Float, nullable=False, default=0)
    debt_balance: Mapped[float] = mapped_column(Float, nullable=False, default=0)
    client_name: Mapped[str] = mapped_column(String(255), nullable=False, default="")
    client_phone: Mapped[str] = mapped_column(String(64), nullable=False, default="")
    shift_id: Mapped[Optional[int]] = mapped_column(ForeignKey("shifts.id"), nullable=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    cashier_name: Mapped[str] = mapped_column(String(255), nullable=False, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), index=True)
    paid_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    note: Mapped[str] = mapped_column(String(512), nullable=False, default="")

    items: Mapped[list["SaleItem"]] = relationship(back_populates="sale", cascade="all, delete-orphan")
    payments: Mapped[list["DebtPayment"]] = relationship(back_populates="sale", cascade="all, delete-orphan")


class SaleItem(Base):
    __tablename__ = "sale_items"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    sale_id: Mapped[int] = mapped_column(ForeignKey("sales.id"), nullable=False, index=True)
    product_id: Mapped[Optional[int]] = mapped_column(ForeignKey("products.id"), nullable=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    is_weight: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    is_service: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    quantity: Mapped[float] = mapped_column(Float, nullable=False, default=1)
    unit_price: Mapped[float] = mapped_column(Float, nullable=False, default=0)
    discount: Mapped[float] = mapped_column(Float, nullable=False, default=0)
    line_total: Mapped[float] = mapped_column(Float, nullable=False, default=0)
    cost_price: Mapped[float] = mapped_column(Float, nullable=False, default=0)

    sale: Mapped[Sale] = relationship(back_populates="items")


class DebtPayment(Base):
    __tablename__ = "debt_payments"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    sale_id: Mapped[int] = mapped_column(ForeignKey("sales.id"), nullable=False, index=True)
    amount: Mapped[float] = mapped_column(Float, nullable=False)
    payment_method: Mapped[str] = mapped_column(String(32), nullable=False, default="cash")
    cash_received: Mapped[float] = mapped_column(Float, nullable=False, default=0)
    change_amount: Mapped[float] = mapped_column(Float, nullable=False, default=0)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    note: Mapped[str] = mapped_column(String(255), nullable=False, default="")

    sale: Mapped[Sale] = relationship(back_populates="payments")


class SaleCounter(Base):
    """Singleton for sale document numbers."""

    __tablename__ = "sale_counters"
    __table_args__ = (UniqueConstraint("id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, default=1)
    last_number: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
