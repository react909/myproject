const { app, shell } = require('electron')

function setAutoLaunch(enabled) {
  if (process.platform !== 'win32') {
    return { ok: false, message: 'Автозапуск настроен только для Windows' }
  }
  try {
    app.setLoginItemSettings({
      openAtLogin: !!enabled,
      path: process.execPath,
      args: [],
    })
    return { ok: true, enabled: !!enabled }
  } catch (e) {
    return { ok: false, message: e.message }
  }
}

/** Windows OSK/TabTip отключены — только встроенная VirtualKeyboard в renderer. */
function openWindowsTouchKeyboard() {
  return { ok: true, message: 'Встроенная клавиатура NurCRM' }
}

function applyKioskToWindow(win, systemSettings) {
  if (!win || win.isDestroyed()) return
  const kiosk = !!systemSettings?.alwaysFullscreen
  win.setMenuBarVisibility(false)
  if (kiosk) {
    win.setFullScreen(true)
    win.setAlwaysOnTop(false)
    win.setResizable(false)
    win.setMaximizable(false)
    win.setMinimizable(false)
    if (!win._nurcrmKioskGuard) {
      win._nurcrmKioskGuard = true
      win.on('minimize', () => {
        if (!win.isDestroyed()) win.restore()
      })
    }
  } else {
    win.setResizable(true)
    win.setMaximizable(true)
    win.setMinimizable(true)
  }
}

module.exports = {
  setAutoLaunch,
  openWindowsTouchKeyboard,
  applyKioskToWindow,
  openExternal: (url) => shell.openExternal(url),
}
