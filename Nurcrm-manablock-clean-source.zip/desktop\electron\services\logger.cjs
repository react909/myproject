const fs = require('node:fs')
const path = require('node:path')
const { app } = require('electron')

const LOG_DIR = () => path.join(app.getPath('userData'), 'logs')

function ensureDir() {
  const dir = LOG_DIR()
  fs.mkdirSync(dir, { recursive: true })
  return dir
}

function logFileName(channel) {
  const d = new Date()
  const day = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
  return `${channel}-${day}.log`
}

function append(channel, level, message, meta) {
  try {
    const dir = ensureDir()
    const line = JSON.stringify({
      ts: new Date().toISOString(),
      level,
      message,
      meta: meta ?? null,
    })
    fs.appendFileSync(path.join(dir, logFileName(channel)), line + '\n', 'utf8')
  } catch {
    /* ignore disk errors */
  }
}

function readRecent(channel, limit = 80) {
  try {
    const file = path.join(ensureDir(), logFileName(channel))
    if (!fs.existsSync(file)) return []
    const lines = fs.readFileSync(file, 'utf8').trim().split('\n').filter(Boolean)
    return lines.slice(-limit).map((l) => {
      try {
        return JSON.parse(l)
      } catch {
        return { ts: '', level: 'info', message: l }
      }
    })
  } catch {
    return []
  }
}

module.exports = { append, readRecent, LOG_DIR }
