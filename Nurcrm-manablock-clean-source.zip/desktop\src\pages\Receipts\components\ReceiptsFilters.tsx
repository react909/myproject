// src/pages/Receipts/components/ReceiptsFilters.tsx

import type { ReceiptsFilters } from '../types'
import { filtersForPeriod } from '../receiptFilters'

type ReceiptsFiltersProps = {
  filters: ReceiptsFilters
  onFiltersChange: (filters: ReceiptsFilters) => void
  cashiers: string[]
}

export function ReceiptsFilters({ filters, onFiltersChange, cashiers }: ReceiptsFiltersProps) {
  const update = (key: keyof ReceiptsFilters, value: string) => {
    onFiltersChange({ ...filters, [key]: value })
  }

  const setPeriod = (period: ReceiptsFilters['period']) => {
    onFiltersChange(filtersForPeriod(period))
  }

  return (
    <div className="receipts-filters">
      <div className="receipts-filters__periods">
        <button
          type="button"
          className={`receipts-period-btn${filters.period === 'today' ? ' is-active' : ''}`}
          onClick={() => setPeriod('today')}
        >
          Сегодня
        </button>
        <button
          type="button"
          className={`receipts-period-btn${filters.period === 'week' ? ' is-active' : ''}`}
          onClick={() => setPeriod('week')}
        >
          7 дней
        </button>
        <button
          type="button"
          className={`receipts-period-btn${filters.period === 'all' ? ' is-active' : ''}`}
          onClick={() => setPeriod('all')}
        >
          Все
        </button>
      </div>

      <div className="receipts-filters__row">
        <label className="receipts-filter receipts-filter--search">
          <span className="receipts-filter__label">№ документа</span>
          <input
            type="text"
            className="receipts-filter__input"
            placeholder="R-001234"
            value={filters.search}
            onChange={(e) => update('search', e.target.value)}
          />
        </label>

        <label className="receipts-filter">
          <span className="receipts-filter__label">Клиент</span>
          <input
            type="text"
            className="receipts-filter__input"
            placeholder="Имя клиента"
            value={filters.customer}
            onChange={(e) => update('customer', e.target.value)}
          />
        </label>

        <label className="receipts-filter">
          <span className="receipts-filter__label">Товар</span>
          <input
            type="text"
            className="receipts-filter__input"
            placeholder="Название товара"
            value={filters.product}
            onChange={(e) => update('product', e.target.value)}
          />
        </label>
      </div>

      <div className="receipts-filters__row">
        <label className="receipts-filter">
          <span className="receipts-filter__label">С часа</span>
          <input
            type="time"
            className="receipts-filter__input"
            value={filters.timeFrom}
            onChange={(e) => update('timeFrom', e.target.value)}
          />
        </label>

        <label className="receipts-filter">
          <span className="receipts-filter__label">По час</span>
          <input
            type="time"
            className="receipts-filter__input"
            value={filters.timeTo}
            onChange={(e) => update('timeTo', e.target.value)}
          />
        </label>

        <label className="receipts-filter">
          <span className="receipts-filter__label">Оплата</span>
          <select
            className="receipts-filter__select"
            value={filters.paymentMethod}
            onChange={(e) => update('paymentMethod', e.target.value)}
          >
            <option value="all">Все</option>
            <option value="cash">Наличные</option>
            <option value="card">Карта</option>
            <option value="mixed">Смешанная</option>
            <option value="debt">В долг</option>
          </select>
        </label>

        <label className="receipts-filter">
          <span className="receipts-filter__label">Статус</span>
          <select
            className="receipts-filter__select"
            value={filters.status}
            onChange={(e) => update('status', e.target.value)}
          >
            <option value="all">Все</option>
            <option value="completed">Продано</option>
            <option value="debt">Долг</option>
            <option value="refunded">Возврат</option>
            <option value="partial_refund">Частичный возврат</option>
            <option value="canceled">Отменён</option>
          </select>
        </label>

        <label className="receipts-filter">
          <span className="receipts-filter__label">Кассир</span>
          <select
            className="receipts-filter__select"
            value={filters.cashier}
            onChange={(e) => update('cashier', e.target.value)}
          >
            <option value="all">Все</option>
            {cashiers.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </label>

        <button
          type="button"
          className="receipts-filter__reset"
          onClick={() => onFiltersChange(filtersForPeriod('today'))}
        >
          Сброс
        </button>
      </div>
    </div>
  )
}
