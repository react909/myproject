// src/settings/SettingsSidebar.tsx

import type { ComponentType } from 'react'
import { NavLink } from 'react-router-dom'
import {
  IconSidebarDiagnostics,
  IconSidebarDisplay,
  IconSidebarPrinter,
  IconSidebarScale,
  IconSidebarSystem,
  IconSidebarUpdates,
} from './SettingsIcons'

type SidebarItem = {
  id: string
  label: string
  path: string
  Icon: ComponentType<{ className?: string }>
}

/** Порядок совпадает с маршрутами `/settings/*` в App.tsx */
const ITEMS: SidebarItem[] = [
  { id: 'scale', label: 'Весы', path: '/settings/scale', Icon: IconSidebarScale },
  { id: 'printer', label: 'Печать', path: '/settings/printer', Icon: IconSidebarPrinter },
  { id: 'payment', label: 'Оплата / QR', path: '/settings/payment', Icon: IconSidebarPrinter },
  { id: 'display', label: 'Экран', path: '/settings/display', Icon: IconSidebarDisplay },
  { id: 'system', label: 'Система', path: '/settings/system', Icon: IconSidebarSystem },
  { id: 'updates', label: 'Обновления', path: '/settings/updates', Icon: IconSidebarUpdates },
  { id: 'diagnostics', label: 'Диагностика', path: '/settings/diagnostics', Icon: IconSidebarDiagnostics },
]

export function SettingsSidebar() {
  return (
    <aside className="settings-sidebar">
      <div className="settings-sidebar__header">
        <h2>Настройки</h2>
      </div>
      <nav className="settings-sidebar__nav">
        {ITEMS.map(({ id, label, path, Icon }) => (
          <NavLink
            key={id}
            to={path}
            end
            className={({ isActive }) =>
              `settings-nav-item${isActive ? ' settings-nav-item--active' : ''}`
            }
          >
            <span className="settings-nav-item__icon">
              <Icon />
            </span>
            <span className="settings-nav-item__label">{label}</span>
          </NavLink>
        ))}
      </nav>
    </aside>
  )
}
