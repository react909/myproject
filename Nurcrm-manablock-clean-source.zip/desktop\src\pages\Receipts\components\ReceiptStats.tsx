import { useEffect, useRef } from 'react'

type Props = {
  totalReceipts: number
  totalRevenue: number
  totalRefunds: number
  avgCheck: number
}

const ICONS = {
  receipts: (
    <svg width="17" height="17" viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M4 2h16v22l-3-2-2 2-2-2-2 2-2-2-3 2V2z"/>
      <path d="M8 8h8M8 12h8M8 16h5"/>
    </svg>
  ),
  revenue: (
    <svg width="17" height="17" viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="2" y="5" width="20" height="14" rx="3"/>
      <path d="M2 10h20M6 15h4"/>
    </svg>
  ),
  refunds: (
    <svg width="17" height="17" viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="1 4 1 10 7 10"/>
      <path d="M3.51 15a9 9 0 1 0 .49-3.96"/>
    </svg>
  ),
  avgCheck: (
    <svg width="17" height="17" viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/>
      <polyline points="17 6 23 6 23 12"/>
    </svg>
  ),
}

function MiniSpark({ color, value }: { color: string; value: number }) {
  const base = Math.max(0, value)
  const data = Array.from({ length: 10 }, (_, i) => Math.round(base * ((i + 1) / 10)))
  const max = Math.max(...data)
  const min = Math.min(...data)
  const range = max - min || 1
  const W = 200; const H = 44

  const pts = data.map((v, i) => [
    (i / (data.length - 1)) * W,
    H - ((v - min) / range) * (H - 6) - 3,
  ] as [number, number])

  const pathD = pts.reduce((acc, [x, y], i) => {
    if (i === 0) return `M ${x},${y}`
    const [px, py] = pts[i - 1]
    const cx = (px + x) / 2
    return `${acc} C ${cx},${py} ${cx},${y} ${x},${y}`
  }, '')

  const fillD = `${pathD} L ${W},${H} L 0,${H} Z`
  const id = `rss-${color.replace(/[^a-z0-9]/gi, '')}`

  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`}
      preserveAspectRatio="none" style={{ display: 'block', width: '100%', height: '100%' }}>
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%"   stopColor={color} stopOpacity="0.25"/>
          <stop offset="100%" stopColor={color} stopOpacity="0"/>
        </linearGradient>
      </defs>
      <path d={fillD} fill={`url(#${id})`}/>
      <path d={pathD} fill="none" stroke={color} strokeWidth="2"
        strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  )
}

export function ReceiptsStats({ totalReceipts, totalRevenue, totalRefunds, avgCheck }: Props) {
  const refs = useRef<(HTMLDivElement | null)[]>([])

  useEffect(() => {
    refs.current.forEach((el, i) => {
      if (!el) return
      el.style.opacity = '0'
      el.style.transform = 'translateY(16px)'
      setTimeout(() => {
        el.style.transition = 'opacity 300ms ease, transform 400ms cubic-bezier(0.34,1.3,0.64,1)'
        el.style.opacity = '1'
        el.style.transform = 'translateY(0)'
      }, i * 60)
    })
  }, [])

  const stats = [
    {
      label: 'Всего чеков', value: totalReceipts.toLocaleString('ru-RU'),
      sub: 'за выбранный период',
      icon: ICONS.receipts, spark: '#2e90fa', raw: totalReceipts,
    },
    {
      label: 'Выручка', value: `${totalRevenue.toLocaleString('ru-RU')} сом`,
      sub: 'по завершённым чекам',
      icon: ICONS.revenue, spark: '#f5a623', raw: totalRevenue,
    },
    {
      label: 'Возвраты', value: `${totalRefunds.toLocaleString('ru-RU')} сом`,
      sub: 'сумма всех возвратов',
      icon: ICONS.refunds, spark: '#f04438', raw: totalRefunds,
      red: true,
    },
    {
      label: 'Средний чек', value: `${avgCheck.toLocaleString('ru-RU')} сом`,
      sub: 'выручка ÷ кол-во чеков',
      icon: ICONS.avgCheck, spark: '#12b76a', raw: avgCheck,
    },
  ]

  return (
    <div className="receipts-stats">
      {stats.map((s, i) => (
        <div
          key={s.label}
          ref={el => { refs.current[i] = el }}
          className="receipts-stat"
        >
          <div className="receipts-stat__top">
            <span className="receipts-stat__icon">{s.icon}</span>
          </div>
          <p className={`receipts-stat__value${s.red ? ' receipts-stat__value--red' : ''}`}>
            {s.value}
          </p>
          <p className="receipts-stat__label">{s.label}</p>
          <p className="receipts-stat__sub">{s.sub}</p>
          <div className="receipts-stat__spark">
            <MiniSpark color={s.spark} value={s.raw}/>
          </div>
        </div>
      ))}
    </div>
  )
}