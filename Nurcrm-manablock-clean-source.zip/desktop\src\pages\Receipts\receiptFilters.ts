import type { ReceiptsFilters } from './types'
import { todayIsoDate } from '../../utils/today'

export function defaultReceiptsFilters(): ReceiptsFilters {
  const today = todayIsoDate()
  return {
    search: '',
    customer: '',
    product: '',
    dateFrom: today,
    dateTo: today,
    timeFrom: '',
    timeTo: '',
    paymentMethod: 'all',
    status: 'all',
    cashier: 'all',
    period: 'today',
  }
}

export function filtersForPeriod(period: ReceiptsFilters['period']): ReceiptsFilters {
  const base = defaultReceiptsFilters()
  const today = todayIsoDate()
  if (period === 'today') return { ...base, period: 'today', dateFrom: today, dateTo: today }
  if (period === 'week') {
    const d = new Date()
    d.setDate(d.getDate() - 6)
    const from = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
    return { ...base, period: 'week', dateFrom: from, dateTo: today }
  }
  return {
    ...base,
    period: 'all',
    dateFrom: '',
    dateTo: '',
  }
}
