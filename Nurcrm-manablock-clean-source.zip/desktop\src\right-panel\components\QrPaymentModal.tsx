import { memo, useEffect } from 'react'
import { motion } from 'framer-motion'
import { ModalPortal } from '../../components/ModalPortal'
import { formatMoney } from '../helpers'
import './QrPaymentModal.css'

type Props = {
  total: number
  storeName?: string
  cashierName?: string
  imageDataUrl?: string
  paymentUrl?: string
  onConfirm: () => void
  onClose: () => void
}

export const QrPaymentModal = memo(function QrPaymentModal({
  total,
  storeName = 'NurCRM Manablock',
  cashierName = 'Кассир',
  imageDataUrl,
  paymentUrl,
  onConfirm,
  onClose,
}: Props) {
  const qrSrc =
    imageDataUrl
    || (paymentUrl
      ? `https://api.qrserver.com/v1/create-qr-code/?size=520x520&data=${encodeURIComponent(paymentUrl)}`
      : null)

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault()
        e.stopImmediatePropagation()
        onClose()
        return
      }
      if (e.key === 'Enter' && !e.repeat) {
        e.preventDefault()
        e.stopImmediatePropagation()
        onConfirm()
      }
    }
    window.addEventListener('keydown', onKey, true)
    return () => window.removeEventListener('keydown', onKey, true)
  }, [onClose, onConfirm])

  return (
    <ModalPortal>
      <motion.div
        className="qrpay-overlay qrpay-overlay--fullscreen"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={(e) => e.target === e.currentTarget && onClose()}
      >
        <motion.div
          className="qrpay-panel qrpay-panel--fullscreen"
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          role="dialog"
          aria-modal="true"
          aria-label="Оплата по QR"
        >
          <header className="qrpay-meta">
            <p className="qrpay-store">{storeName}</p>
            <p className="qrpay-sum">{formatMoney(total)} сом</p>
            <p className="qrpay-cashier">Кассир: {cashierName}</p>
          </header>

          <p className="qrpay-hint">Отсканируйте QR · Enter — подтвердить оплату</p>

          <div className="qrpay-frame">
            {qrSrc ? (
              <img src={qrSrc} alt="QR для оплаты" className="qrpay-img" />
            ) : (
              <div className="qrpay-placeholder">
                QR не настроен — загрузите в панели управления товарами
              </div>
            )}
          </div>

          {paymentUrl && !imageDataUrl && (
            <p className="qrpay-link">{paymentUrl}</p>
          )}

          <div className="qrpay-actions">
            <button type="button" className="qrpay-btn qrpay-btn--ghost" onClick={onClose}>
              Отмена
            </button>
            <button type="button" className="qrpay-btn qrpay-btn--ok" onClick={onConfirm}>
              Подтвердить оплату
            </button>
          </div>
        </motion.div>
      </motion.div>
    </ModalPortal>
  )
})
