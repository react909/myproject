import { useState } from 'react'
import type { HourlyPoint } from '../AnalyticsPage'

export function HourlyHeatmap({ data }: { data: HourlyPoint[] }) {
  const points = data.length > 0 ? data : Array.from({ length: 24 }, (_, hour) => ({ hour, sales: 0 }))
  const max = Math.max(...points.map(d => d.sales), 1)
  const [hov, setHov] = useState<number | null>(null)

  const getColor = (sales: number) => {
    const t = sales / max
    if (t < 0.2)  return { bg: 'rgba(245,166,35,0.08)',  text: 'var(--text-3)' }
    if (t < 0.45) return { bg: 'rgba(245,166,35,0.22)',  text: 'var(--text-2)' }
    if (t < 0.70) return { bg: 'rgba(245,166,35,0.50)',  text: 'var(--text-1)' }
    if (t < 0.88) return { bg: 'rgba(245,166,35,0.75)',  text: '#fff' }
    return               { bg: 'rgba(213,135,26,0.95)',  text: '#fff' }
  }

  const peak = points.reduce((a, b) => a.sales > b.sales ? a : b)

  return (
    <section className="hm__card">
      <div className="hm__head">
        <h3 className="hm__title">Продажи по часам</h3>
        <div className="hm__peak">
          Пик: <strong>{peak.hour}:00</strong> — {peak.sales.toLocaleString('ru-RU')} сом
        </div>
      </div>

      {/* Тепловая карта */}
      <div className="hm__grid">
        {points.map(({ hour, sales }) => {
          const { bg, text } = getColor(sales)
          const isHov = hov === hour
          return (
            <div
              key={hour}
              className={`hm__cell${isHov ? ' hm__cell--hov' : ''}`}
              style={{ background: bg, color: text }}
              onMouseEnter={() => setHov(hour)}
              onMouseLeave={() => setHov(null)}
            >
              <span className="hm__cell-hour">{hour}</span>
              <span className="hm__cell-val">
                {sales >= 1000 ? `${(sales / 1000).toFixed(1)}k` : sales || '—'}
              </span>

              {isHov && (
                <div className="hm__cell-tip">
                  <strong>{hour}:00 – {hour + 1}:00</strong>
                  <span>{sales.toLocaleString('ru-RU')} сом</span>
                  <span>{(sales / max * 100).toFixed(0)}% от пика</span>
                </div>
              )}
            </div>
          )
        })}
      </div>

      {/* Легенда */}
      <div className="hm__legend">
        <span className="hm__leg-label">Мало</span>
        <div className="hm__leg-scale">
          {[0.08, 0.22, 0.45, 0.70, 0.92].map(o => (
            <div key={o} className="hm__leg-seg"
              style={{ background: `rgba(245,166,35,${o})` }}/>
          ))}
        </div>
        <span className="hm__leg-label">Много</span>
      </div>
    </section>
  )
}