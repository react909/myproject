import { useState } from 'react'
import { apiPost } from '../api/client'
import logoImage from '../assets/images.png'
import './ServiceCodeScreen.css'

type Props = {
  onVerified: (setupToken: string) => void
  onNotify?: (message: string) => void
}

export function ServiceCodeScreen({ onVerified, onNotify }: Props) {
  const [code, setCode] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')

  const submit = async () => {
    if (!code.trim()) {
      setError('Введите сервисный код установки')
      return
    }

    setBusy(true)
    setError('')
    try {
      const response = await apiPost(
        '/api/setup/verify-service-code',
        { code: code.trim() },
      )
      const token = response.data?.setup_token
      if (!token) throw new Error('Локальный сервер не подтвердил код')
      onNotify?.('Сервисный код подтверждён')
      onVerified(token)
    } catch (caught: unknown) {
      const err = caught as {
        response?: { data?: { detail?: string } }
        message?: string
      }
      setError(
        err.response?.data?.detail
        ?? err.message
        ?? 'Не удалось проверить сервисный код',
      )
    } finally {
      setBusy(false)
    }
  }

  return (
    <main className="service-code">
      <section className="service-code__card">
        <div className="service-code__brand">
          <img src={logoImage} alt="" />
          <div>
            <strong>NurCRM Offline</strong>
            <span>Первоначальная установка</span>
          </div>
        </div>

        <div className="service-code__lock" aria-hidden="true">⌁</div>
        <span className="service-code__eyebrow">Защищённая настройка</span>
        <h1>Введите сервисный код</h1>
        <p>
          Код подтверждает право на первоначальную настройку системы.
          Проверка выполняется только на этом компьютере, без интернета.
        </p>

        <form
          onSubmit={(event) => {
            event.preventDefault()
            void submit()
          }}
        >
          <label>
            <span>Сервисный код установки</span>
            <input
              autoFocus
              value={code}
              onChange={(event) => setCode(event.target.value.toUpperCase())}
              autoComplete="off"
              spellCheck={false}
              placeholder="Введите код"
              disabled={busy}
            />
          </label>

          {error && <div className="service-code__error" role="alert">{error}</div>}

          <button type="submit" disabled={busy}>
            {busy ? 'Проверка…' : 'Продолжить настройку'}
          </button>
        </form>

        <small>Код проверяется локальным сервером NurCRM.</small>
      </section>
    </main>
  )
}
