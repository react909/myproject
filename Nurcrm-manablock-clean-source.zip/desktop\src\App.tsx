// App.tsx — логин / первый запуск + роутинг (локальный Offline POS)

import { useEffect, useRef, useState } from 'react'
import { HashRouter, Navigate, Route, Routes } from 'react-router-dom'
import { LoginScreen, type LoginScreenHandle } from './auth/LoginScreen'
import { FirstRunSetup } from './auth/FirstRunSetup'
import { ServiceCodeScreen } from './auth/ServiceCodeScreen'
import { VirtualKeyboard } from './virtual-keyboard/VirtualKeyboard'
import { SettingsPage } from './settings/SettingsPage'
import { useSystemSettings } from './hooks/useSystemSettings'
import { useVirtualKeyboardFocus } from './hooks/useVirtualKeyboardFocus'
import { ScaleSection } from './settings/sections/ScaleSection'
import { PrinterSection } from './settings/sections/PrinterSection'
import { SystemSection } from './settings/sections/SystemSection'
import { UpdatesSection } from './settings/sections/UpdatesSection'
import { DiagnosticsSection } from './settings/sections/DiagnosticsSection'
import { DisplaySection } from './settings/sections/DisplaySection'
import { PaymentSection } from './settings/sections/PaymentSection'
import { HeavyPageGate } from './pages/HeavyPageGate'
import { LoadingScreen } from './pages/LoadingScreen'
import { PanelPage } from './pages/PanelPage'
import { DashboardPage } from './pages/DashboardPage'
import { FinancePage } from './pages/Finance/FinancePage'
import { AnalyticsPage } from './pages/Analytics/AnalyticsPage'
import { ReceiptsPage } from './pages/Receipts/ReceiptsPage'
import { NotificationProvider } from './components/notifications/NotificationProvider'
import { PosConnectionProvider } from './context/PosConnectionProvider'
import { clearAccountSession } from './services/accountSession'
import { runPosInit } from './services/posInit'
import { readProductsCacheStaleOk } from './services/products'
import { apiGet } from './api/client'
import type { Product } from './catalog/mockProducts'
import './style.css'

type UserSession = { user: { username: string } }

type PosBootState = {
  status: 'idle' | 'loading' | 'ready' | 'error'
  message: string
  products: Product[]
  warnings: string[]
}

type SetupGate = 'loading' | 'needs_setup' | 'ready' | 'backend_error'

export function App() {
  useSystemSettings()
  const [setupGate, setSetupGate] = useState<SetupGate>('loading')
  const [setupToken, setSetupToken] = useState<string | null>(null)
  const [setupCheckNonce, setSetupCheckNonce] = useState(0)
  // A completed setup opens the workspace once. Every later application
  // launch intentionally starts from the local login screen.
  const [session, setSession] = useState<UserSession | null>(null)
  const [posBoot, setPosBoot] = useState<PosBootState>({
    status: 'idle',
    message: '',
    products: [],
    warnings: [],
  })
  const [message, setMessage] = useState('Введите логин и нажмите «Войти».')
  const [keyboardOpen, setKeyboardOpen] = useState(false)
  useVirtualKeyboardFocus(setKeyboardOpen)
  const loginScreenRef = useRef<LoginScreenHandle | null>(null)
  const activeInputRef = useRef<HTMLInputElement | null>(null)

  useEffect(() => {
    let cancelled = false
    setSetupGate('loading')
    setSetupToken(null)

    const checkSetup = async () => {
      for (let attempt = 0; attempt < 12; attempt += 1) {
        try {
          const res = await apiGet('/api/setup/status')
          if (cancelled) return
          setSetupGate(res.data?.needs_setup ? 'needs_setup' : 'ready')
          return
        } catch {
          if (cancelled) return
          await new Promise((resolve) => window.setTimeout(resolve, 500))
        }
      }
      if (!cancelled) setSetupGate('backend_error')
    }

    void checkSetup()
    return () => {
      cancelled = true
    }
  }, [setupCheckNonce])

  useEffect(() => {
    if (!session) {
      setPosBoot({ status: 'idle', message: '', products: [], warnings: [] })
      return undefined
    }

    const controller = new AbortController()
    setPosBoot({
      status: 'loading',
      message: 'Проверка локального сервера…',
      products: [],
      warnings: [],
    })

    void runPosInit(
      (progress) => {
        setPosBoot((prev) => ({ ...prev, message: progress.message }))
      },
      controller.signal,
    )
      .then((result) => {
        setPosBoot({
          status: 'ready',
          message: '',
          products: result.products,
          warnings: result.warnings,
        })
      })
      .catch((err: unknown) => {
        if (controller.signal.aborted) return
        const errMessage =
          err && typeof err === 'object' && 'message' in err && typeof (err as { message: string }).message === 'string'
            ? (err as { message: string }).message
            : 'Не удалось подготовить кассу'
        setPosBoot({
          status: 'error',
          message: errMessage,
          products: readProductsCacheStaleOk(),
          warnings: [errMessage],
        })
      })

    return () => controller.abort()
  }, [session?.user.username])

  const handleLogout = () => {
    clearAccountSession()
    setSession(null)
  }

  const keyboard = (
    <VirtualKeyboard
      isOpen={keyboardOpen}
      onOpenChange={setKeyboardOpen}
      onEnter={
        !session && setupGate === 'ready'
          ? () => void loginScreenRef.current?.submit()
          : undefined
      }
    />
  )

  if (setupGate === 'loading') {
    return (
      <>
        <div className="screen-shell">
          <LoadingScreen title="Запуск…" subtitle="Подключение к локальному серверу" />
        </div>
        {keyboard}
      </>
    )
  }

  if (setupGate === 'backend_error') {
    return (
      <>
        <div className="screen-shell">
          <LoadingScreen
            title="Локальный сервер не запустился"
            subtitle="Перезапустите приложение или нажмите «Повторить». Интернет не требуется."
          />
          <div className="bottom-message" role="status">
            <button
              type="button"
              onClick={() => setSetupCheckNonce((value) => value + 1)}
            >
              Повторить
            </button>
          </div>
        </div>
        {keyboard}
      </>
    )
  }

  if (setupGate === 'needs_setup') {
    if (!setupToken) {
      return (
        <>
          <div className="screen-shell">
            <ServiceCodeScreen
              onVerified={setSetupToken}
              onNotify={setMessage}
            />
            <div className="bottom-message" role="status">
              {message}
            </div>
          </div>
          {keyboard}
        </>
      )
    }

    return (
      <>
        <div className="screen-shell">
          <FirstRunSetup
            setupToken={setupToken}
            onDone={(username) => {
              setSetupGate('ready')
              setSession({ user: { username } })
              setMessage(`Настройка завершена. Добро пожаловать, ${username}.`)
            }}
            onNotify={setMessage}
          />
          <div className="bottom-message" role="status">
            {message}
          </div>
        </div>
        {keyboard}
      </>
    )
  }

  if (!session) {
    return (
      <>
        <div className="screen-shell">
          <LoginScreen
            ref={loginScreenRef}
            activeInputRef={activeInputRef}
            onSuccess={(username) => {
              setMessage(`Касса готова, ${username}.`)
              setSession({ user: { username } })
            }}
            onNotify={setMessage}
          />
          <div className="bottom-message" role="status">
            {message}
          </div>
        </div>
        {keyboard}
      </>
    )
  }

  if (posBoot.status === 'error' && posBoot.products.length === 0) {
    return (
      <>
        <div className="screen-shell">
          <LoadingScreen
            title="Не удалось подготовить кассу"
            subtitle={posBoot.message || 'Проверьте локальный сервер и повторите вход'}
          />
          <div className="bottom-message" role="status">
            <button type="button" onClick={handleLogout}>
              Выйти и повторить
            </button>
          </div>
        </div>
        {keyboard}
      </>
    )
  }

  if (posBoot.status === 'loading') {
    return (
      <>
        <div className="screen-shell">
          <LoadingScreen
            title="Подготовка кассы…"
            subtitle={posBoot.message || 'Каталог, устройства'}
          />
        </div>
        {keyboard}
      </>
    )
  }

  const posReady = posBoot.status === 'ready'
  const initWarnings = posBoot.warnings

  return (
    <NotificationProvider>
      <PosConnectionProvider>
        <HashRouter>
        <Routes>
          <Route
            path="/"
            element={
              <DashboardPage
                username={session.user.username}
                onLogout={handleLogout}
                initialProducts={posBoot.products}
                posReady={posReady}
                initWarnings={initWarnings}
              />
            }
          />

          <Route
            path="/panel"
            element={
              <HeavyPageGate
                loadingTitle="Панель управления…"
                loadingSubtitle="Подготовка разделов и фильтров"
              >
                <PanelPage />
              </HeavyPageGate>
            }
          />

          <Route path="/settings" element={<SettingsPage />}>
            <Route index element={<Navigate to="/settings/scale" replace />} />
            <Route path="connection" element={<Navigate to="/settings/scale" replace />} />
            <Route path="scale" element={<ScaleSection />} />
            <Route path="printer" element={<PrinterSection />} />
            <Route path="payment" element={<PaymentSection />} />
            <Route path="display" element={<DisplaySection />} />
            <Route path="system" element={<SystemSection />} />
            <Route path="updates" element={<UpdatesSection />} />
            <Route path="diagnostics" element={<DiagnosticsSection />} />
          </Route>

          <Route path="/finance" element={<FinancePage />} />
          <Route path="/analytics" element={<AnalyticsPage />} />
          <Route path="/receipts" element={<ReceiptsPage />} />

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </HashRouter>
      </PosConnectionProvider>
      {keyboard}
    </NotificationProvider>
  )
}
