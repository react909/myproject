const { app, BrowserWindow, session, net, ipcMain, dialog } = require('electron')
const fs = require('node:fs')
const http = require('node:http')
const path = require('node:path')
const { spawn } = require('node:child_process')

const logger = require('./services/logger.cjs')
const appState = require('./services/app-state.cjs')
const splash = require('./services/splash-window.cjs')
const { resolveAppIconImage } = require('./services/icon-path.cjs')

/** Проверка критичных модулей до загрузки IPC/принтера (иначе падение в main process). */
function assertPackagedRuntimeModules() {
  const receiptRender = path.join(__dirname, 'receipt', 'receipt-render.cjs')
  if (!fs.existsSync(receiptRender)) {
    const message =
      'Не найден модуль печати чеков (receipt-render.cjs).\n\n' +
      'Переустановите NurCRM Manablock из актуального установщика.'
    try {
      dialog.showErrorBox('NurCRM Manablock — ошибка запуска', message)
    } catch {
      console.error(message)
    }
    app.exit(1)
    return
  }
  require('./receipt/receipt-render.cjs')
}

assertPackagedRuntimeModules()

const { registerIpc } = require('./ipc/register-ipc.cjs')

let backendProcess = null
let backendOwnedByApp = false
let mainWindow = null

const isDev = !app.isPackaged

app.setAppUserModelId('com.nurcrm.manablock')

// ── CORS bypass for external API (e.g. https://app.nurcrm.kg) ──
// Electron renderer runs from file:// which triggers CORS preflight.
// We intercept OPTIONS requests and add proper CORS headers to responses.
function setupCorsBypass(win) {
  const filter = { urls: ['https://app.nurcrm.kg/*'] }

  // Handle OPTIONS preflight: respond with 200 + CORS headers
  win.webContents.session.webRequest.onBeforeSendHeaders(filter, (details, callback) => {
    // Remove Origin and Referer to avoid CORS preflight on some servers
    delete details.requestHeaders['Origin']
    delete details.requestHeaders['Referer']
    callback({ requestHeaders: details.requestHeaders })
  })

  win.webContents.session.webRequest.onHeadersReceived(filter, (details, callback) => {
    const headers = { ...details.responseHeaders }
    headers['Access-Control-Allow-Origin'] = ['*']
    headers['Access-Control-Allow-Methods'] = ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS']
    headers['Access-Control-Allow-Headers'] = ['Content-Type', 'Authorization', 'X-Requested-With']
    headers['Access-Control-Allow-Credentials'] = ['true']
    callback({ responseHeaders: headers })
  })
}

if (!isDev) {
  app.commandLine.appendSwitch('disable-renderer-backgrounding')
}

function getRendererIndexPath() {
  return path.join(app.getAppPath(), 'dist', 'index.html')
}

function getMainWindow() {
  return mainWindow && !mainWindow.isDestroyed() ? mainWindow : null
}

function pingBackend() {
  return new Promise((resolve) => {
    const request = http.get('http://127.0.0.1:8000/health', (response) => {
      resolve(response.statusCode === 200)
      response.resume()
    })
    request.on('error', () => resolve(false))
    request.setTimeout(1500, () => {
      request.destroy()
      resolve(false)
    })
  })
}

function resolveBackendCommand() {
  if (isDev) {
    return {
      command: 'python',
      args: ['main.py'],
      cwd: path.resolve(__dirname, '../../backend'),
    }
  }
  const frontendDir = path.dirname(process.execPath)
  const siblingBackendDir = path.resolve(frontendDir, '../backend')
  const bundledBackendDir = path.join(process.resourcesPath, 'backend')
  const backendDir = fs.existsSync(path.join(siblingBackendDir, 'backend.exe'))
    ? siblingBackendDir
    : bundledBackendDir
  return {
    command: path.join(backendDir, 'backend.exe'),
    args: [],
    cwd: backendDir,
  }
}

async function waitForBackend(timeoutMs = 30000) {
  const started = Date.now()
  while (Date.now() - started < timeoutMs) {
    if (await pingBackend()) return true
    await new Promise((r) => setTimeout(r, 400))
  }
  return false
}

async function startBackend() {
  if (await pingBackend()) {
    logger.append('backend', 'info', 'already running on :8000')
    return true
  }
  const { command, args, cwd } = resolveBackendCommand()
  if (!isDev && !fs.existsSync(command)) {
    logger.append('backend', 'warn', 'backend.exe not found', { command })
    return false
  }
  const sqlitePath = path.join(app.getPath('userData'), 'nurcrm.db')
  logger.append('backend', 'info', 'starting', { command, cwd, sqlitePath })
  backendProcess = spawn(command, args, {
    cwd,
    windowsHide: true,
    env: {
      ...process.env,
      PYTHONUNBUFFERED: '1',
      UVICORN_LOOP: 'asyncio',
      SQLITE_PATH: sqlitePath,
    },
  })
  backendOwnedByApp = true
  backendProcess.stdout?.on('data', (c) => process.stdout.write(`[backend] ${c}`))
  backendProcess.stderr?.on('data', (c) => process.stderr.write(`[backend] ${c}`))
  backendProcess.on('exit', (code) => {
    backendProcess = null
    if (code && code !== 0) logger.append('backend', 'error', `exit ${code}`)
  })
  const ok = await waitForBackend(30000)
  if (!ok) logger.append('backend', 'error', 'health check timeout after start')
  return ok
}

function stopBackend() {
  if (backendOwnedByApp && backendProcess && !backendProcess.killed) {
    backendProcess.kill()
  }
}

function createWindow() {
  const appIcon = resolveAppIconImage()
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 960,
    backgroundColor: '#0f1419',
    title: 'NurCRM Manablock',
    icon: appIcon,
    frame: false,
    autoHideMenuBar: true,
    show: false,
    fullscreen: !isDev,
    kiosk: false,
    movable: isDev,
    minimizable: true,
    maximizable: true,
    resizable: isDev,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      backgroundThrottling: false,
    },
  })
  mainWindow.setMenuBarVisibility(false)

  // Fix: на части моноблоков после «свернуть → развернуть» frameless-fullscreen окно
  // теряет композицию и показывает серый экран. Принудительно перерисовываем
  // и заново включаем полноэкранный режим при восстановлении.
  const repaintAfterRestore = () => {
    if (!mainWindow || mainWindow.isDestroyed()) return
    try {
      if (!isDev && !mainWindow.isFullScreen()) mainWindow.setFullScreen(true)
      mainWindow.webContents.invalidate()
    } catch {
      /* ignore */
    }
  }
  mainWindow.on('restore', repaintAfterRestore)
  mainWindow.on('show', repaintAfterRestore)
  mainWindow.on('focus', repaintAfterRestore)

  mainWindow.once('ready-to-show', () => {
    splash.closeSplash()
    mainWindow.maximize()
    if (!isDev) mainWindow.setFullScreen(true)
    mainWindow.show()
    if (app.isPackaged) appState.markApplicationLaunch(app.getVersion())
  })

  if (isDev) {
    void mainWindow.loadURL('http://127.0.0.1:5173')
  } else {
    const indexPath = getRendererIndexPath()
    if (!fs.existsSync(indexPath)) {
      logger.append('app', 'error', 'index.html missing', { indexPath })
    }
    void mainWindow.loadFile(indexPath)
  }

  const broadcastFs = (v) => {
    if (mainWindow && !mainWindow.isDestroyed()) {
      try {
        mainWindow.webContents.send('fullscreen-changed', v)
      } catch {
        /* ignore */
      }
    }
  }

  // Handle F11 key for fullscreen toggle
  mainWindow.webContents.on('before-input-event', (event, input) => {
    if (input.key === 'F11' && input.type === 'keyDown') {
      event.preventDefault()
      const isFs = mainWindow.isFullScreen()
      mainWindow.setFullScreen(!isFs)
    }
  })

  mainWindow.on('enter-full-screen', () => broadcastFs(true))
  mainWindow.on('leave-full-screen', () => broadcastFs(false))
  // Apply CORS bypass for external API calls
  setupCorsBypass(mainWindow)

  mainWindow.on('closed', () => {
    mainWindow = null
  })
}

app.whenReady().then(async () => {
  registerIpc(getMainWindow)
  const splashDeadline =
    app.isPackaged
      ? setTimeout(() => splash.closeSplash(), 1600)
      : null

  if (app.isPackaged) {
    splash.createSplash()
    splash.setSplashMessage('Запуск NurCRM Manablock…')
  }
  await startBackend()
  if (app.isPackaged) splash.setSplashMessage('Загрузка интерфейса…')
  createWindow()
  if (splashDeadline) clearTimeout(splashDeadline)
  // ── API proxy: use native fetch (Node 18+ / Electron 28+) — no CORS, no header stripping ──
  ipcMain.handle('api-request', async (_event, { method, url, headers, body }) => {
    console.log(`[IPC-API] ${method} ${url}`)
    const safeHeaders = { ...headers }
    if (safeHeaders.Authorization) safeHeaders.Authorization = 'Bearer ***'
    console.log('[IPC-API] headers:', JSON.stringify(safeHeaders))
    try {
      const fetchOptions = {
        method,
        headers: { ...headers },
        body: body || undefined,
      }
      const response = await fetch(url, fetchOptions)
      const text = await response.text()
      let data = null
      try { data = JSON.parse(text) } catch { data = text }
      if (response.status >= 400) {
        console.warn(`[IPC-API] Response: ${response.status}`, JSON.stringify(data).slice(0, 700))
      } else {
        console.log(`[IPC-API] Response: ${response.status}`)
      }
      return { status: response.status, headers: Object.fromEntries(response.headers), data }
    } catch (err) {
      console.error('[IPC-API] Fetch error:', err.message)
      return { status: 0, data: { error: err.message } }
    }
  })

  logger.append('app', 'info', 'application ready', { version: app.getVersion(), isDev })

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow()
  })
})

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit()
})

app.on('before-quit', () => {
  stopBackend()
  splash.closeSplash()
})
