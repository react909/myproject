import { useMemo, useState } from 'react'
import client from '../api/client'
import { prepareAccountSession } from '../services/accountSession'
import logoImage from '../assets/images.png'
import './FirstRunSetup.css'

type Props = {
  setupToken: string
  onDone: (username: string) => void
  onNotify?: (message: string) => void
}

type Edition = 'start' | 'standard'

const CURRENCIES = [
  { code: 'KGS', label: 'Кыргызский сом', symbol: 'сом' },
  { code: 'KZT', label: 'Казахстанский тенге', symbol: '₸' },
  { code: 'RUB', label: 'Российский рубль', symbol: '₽' },
  { code: 'USD', label: 'Доллар США', symbol: '$' },
]

const STEPS = [
  { title: 'Добро пожаловать', short: 'Начало' },
  { title: 'Редакция', short: 'Возможности' },
  { title: 'Организация', short: 'Данные компании' },
  { title: 'Администратор', short: 'Доступ' },
  { title: 'Завершение', short: 'Создание системы' },
] as const

export function FirstRunSetup({ setupToken, onDone, onNotify }: Props) {
  const [step, setStep] = useState(0)
  const [edition, setEdition] = useState<Edition>('start')
  const [companyName, setCompanyName] = useState('')
  const [ownerName, setOwnerName] = useState('')
  const [inn, setInn] = useState('')
  const [phone, setPhone] = useState('')
  const [email, setEmail] = useState('')
  const [address, setAddress] = useState('')
  const [currency, setCurrency] = useState('KGS')
  const [username, setUsername] = useState('admin')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')

  const selectedCurrency = useMemo(
    () => CURRENCIES.find((item) => item.code === currency) ?? CURRENCIES[0]!,
    [currency],
  )

  const passwordStrength = useMemo(() => {
    let value = 0
    if (password.length >= 6) value += 1
    if (password.length >= 10) value += 1
    if (/[A-ZА-Я]/.test(password) && /\d/.test(password)) value += 1
    return value
  }, [password])

  const validate = (target = step): boolean => {
    setError('')
    if (target === 2) {
      if (!companyName.trim()) {
        setError('Введите название компании')
        return false
      }
      if (!ownerName.trim()) {
        setError('Введите имя владельца')
        return false
      }
      if (email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
        setError('Проверьте адрес электронной почты')
        return false
      }
    }
    if (target === 3) {
      if (username.trim().length < 2) {
        setError('Логин должен содержать минимум 2 символа')
        return false
      }
      if (password.length < 6) {
        setError('Пароль должен содержать минимум 6 символов')
        return false
      }
    }
    return true
  }

  const next = () => {
    if (!validate()) return
    setStep((current) => Math.min(STEPS.length - 1, current + 1))
  }

  const back = () => {
    setError('')
    setStep((current) => Math.max(0, current - 1))
  }

  const finish = async () => {
    if (![2, 3].every((index) => validate(index))) return
    setBusy(true)
    setError('')
    try {
      const response = await client.post('/api/setup/init', {
        setup_token: setupToken,
        edition,
        company_name: companyName.trim(),
        store_name: companyName.trim(),
        owner_name: ownerName.trim(),
        inn: inn.trim(),
        phone: phone.trim(),
        email: email.trim(),
        address: address.trim(),
        currency: selectedCurrency.code,
        currency_label: selectedCurrency.symbol,
        username: username.trim(),
        password,
      })

      const token = response.data?.access_token
      if (!token) throw new Error('Локальный сервер не создал сеанс администратора')

      localStorage.setItem('nurcrm-token', token)
      localStorage.setItem('nurcrm-user-email', username.trim())
      localStorage.setItem('nurcrm-last-username', username.trim())
      localStorage.setItem('nurcrm-api-url', 'http://127.0.0.1:8000')
      localStorage.removeItem('nurcrm-refresh-token')
      if (response.data?.user) {
        localStorage.setItem('nurcrm-user', JSON.stringify(response.data.user))
      }
      prepareAccountSession(username.trim())
      onNotify?.('NurCRM Offline готов к работе')
      onDone(username.trim())
    } catch (caught: unknown) {
      const err = caught as {
        response?: { data?: { detail?: string } }
        message?: string
      }
      setError(
        err.response?.data?.detail
        ?? err.message
        ?? 'Не удалось завершить первоначальную настройку',
      )
    } finally {
      setBusy(false)
    }
  }

  return (
    <main className="first-run">
      <aside className="first-run__sidebar">
        <div className="first-run__brand">
          <img src={logoImage} alt="" />
          <div>
            <strong>NurCRM Offline</strong>
            <span>Мастер первого запуска</span>
          </div>
        </div>

        <ol className="first-run__steps">
          {STEPS.map((item, index) => (
            <li
              key={item.title}
              className={[
                index === step ? 'is-active' : '',
                index < step ? 'is-complete' : '',
              ].filter(Boolean).join(' ')}
            >
              <span className="first-run__step-number">
                {index < step ? '✓' : index + 1}
              </span>
              <span>
                <strong>{item.title}</strong>
                <small>{item.short}</small>
              </span>
            </li>
          ))}
        </ol>

        <div className="first-run__offline-note">
          <strong>Полностью локальная система</strong>
          <span>Без интернета, GitHub, лицензирования и внешних API.</span>
        </div>
      </aside>

      <section className="first-run__content">
        <form
          className="first-run__panel"
          onSubmit={(event) => {
            event.preventDefault()
            if (step === 4) void finish()
            else next()
          }}
        >
          {step === 0 && <WelcomeStep />}

          {step === 1 && (
            <>
              <StepHeader
                step={step}
                title="Выберите редакцию"
                text="Редакция определяет доступные функции. Выбор сохраняется только в локальной базе."
              />
              <div className="first-run__edition-grid">
                <EditionCard
                  value="start"
                  selected={edition === 'start'}
                  title="Start"
                  description="Базовая касса для небольшого магазина"
                  features={['Продажи и чеки', 'Товары и остатки', 'Смены и базовая аналитика']}
                  onSelect={setEdition}
                />
                <EditionCard
                  value="standard"
                  selected={edition === 'standard'}
                  title="Standard"
                  description="Расширенная редакция для растущего бизнеса"
                  features={['Все функции Start', 'Расширенные финансы', 'Роли и дополнительные отчёты']}
                  onSelect={setEdition}
                />
              </div>
              <p className="first-run__local-caption">
                Сейчас редакция активируется локально. Сервер лицензий не используется.
              </p>
            </>
          )}

          {step === 2 && (
            <>
              <StepHeader
                step={step}
                title="Создание организации"
                text="Информация сохранится в SQLite и будет использоваться в чеках и документах."
              />
              <div className="first-run__fields first-run__fields--organization">
                <Field label="Название компании" required wide>
                  <input
                    autoFocus
                    value={companyName}
                    onChange={(event) => setCompanyName(event.target.value)}
                    placeholder="ОсОО «Моя компания»"
                  />
                </Field>
                <Field label="Владелец" required>
                  <input
                    value={ownerName}
                    onChange={(event) => setOwnerName(event.target.value)}
                    placeholder="Имя и фамилия"
                  />
                </Field>
                <Field label="ИНН">
                  <input
                    inputMode="numeric"
                    value={inn}
                    onChange={(event) => setInn(event.target.value)}
                    placeholder="Необязательно"
                  />
                </Field>
                <Field label="Телефон">
                  <input
                    inputMode="tel"
                    value={phone}
                    onChange={(event) => setPhone(event.target.value)}
                    placeholder="+996 555 000 000"
                  />
                </Field>
                <Field label="Email">
                  <input
                    inputMode="email"
                    value={email}
                    onChange={(event) => setEmail(event.target.value)}
                    placeholder="shop@example.com"
                  />
                </Field>
                <Field label="Адрес" wide>
                  <input
                    value={address}
                    onChange={(event) => setAddress(event.target.value)}
                    placeholder="Город, улица, дом"
                  />
                </Field>
                <Field label="Валюта" wide>
                  <select value={currency} onChange={(event) => setCurrency(event.target.value)}>
                    {CURRENCIES.map((item) => (
                      <option key={item.code} value={item.code}>
                        {item.label} ({item.symbol})
                      </option>
                    ))}
                  </select>
                </Field>
              </div>
            </>
          )}

          {step === 3 && (
            <>
              <StepHeader
                step={step}
                title="Создание администратора"
                text="Администратор получит полный доступ к настройкам, товарам и финансам."
              />
              <div className="first-run__fields">
                <Field label="Логин" required wide hint="Используйте его для последующих входов.">
                  <input
                    autoFocus
                    value={username}
                    onChange={(event) => setUsername(event.target.value.replace(/\s/g, ''))}
                    autoComplete="username"
                  />
                </Field>
                <Field label="Пароль" required>
                  <div className="first-run__password">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(event) => setPassword(event.target.value)}
                      autoComplete="new-password"
                      placeholder="Минимум 6 символов"
                    />
                    <button type="button" onClick={() => setShowPassword((value) => !value)}>
                      {showPassword ? 'Скрыть' : 'Показать'}
                    </button>
                  </div>
                  <span className={`first-run__strength level-${passwordStrength}`}>
                    <i /><i /><i />
                  </span>
                </Field>
                <div className="first-run__security-note first-run__field--wide">
                  Пароль хешируется и хранится только в локальной базе данных.
                </div>
              </div>
            </>
          )}

          {step === 4 && (
            <>
              <StepHeader
                step={step}
                title="Всё готово к созданию"
                text="Проверьте основные данные и завершите настройку."
              />
              <div className="first-run__summary">
                <SummaryRow label="Редакция" value={edition === 'start' ? 'Start' : 'Standard'} onEdit={() => setStep(1)} />
                <SummaryRow label="Компания" value={companyName} onEdit={() => setStep(2)} />
                <SummaryRow label="Владелец" value={ownerName} onEdit={() => setStep(2)} />
                <SummaryRow label="Валюта" value={`${selectedCurrency.label} (${selectedCurrency.symbol})`} onEdit={() => setStep(2)} />
                <SummaryRow label="Администратор" value={username} onEdit={() => setStep(3)} />
              </div>
              <div className="first-run__finish-note">
                <strong>После завершения</strong>
                <span>
                  Будут сохранены настройки организации, создан администратор и открыт рабочий стол NurCRM.
                </span>
              </div>
            </>
          )}

          {error && <p className="first-run__error" role="alert">{error}</p>}

          <footer className="first-run__actions">
            {step > 0 ? (
              <button type="button" className="first-run__secondary" onClick={back} disabled={busy}>
                Назад
              </button>
            ) : <span />}
            <button type="submit" className="first-run__primary" disabled={busy}>
              {busy
                ? 'Создание локальной системы…'
                : step === 0
                  ? 'Начать настройку'
                  : step === 4
                    ? 'Завершить и открыть NurCRM'
                    : 'Продолжить'}
            </button>
          </footer>
        </form>
      </section>
    </main>
  )
}

function WelcomeStep() {
  return (
    <div className="first-run__welcome">
      <span className="first-run__eyebrow">Первый запуск</span>
      <h1>Добро пожаловать в NurCRM Offline</h1>
      <p>
        Автономная система для продаж, товаров, остатков, чеков и аналитики.
        Она работает на вашем компьютере и не требует подключения к интернету.
      </p>
      <div className="first-run__welcome-points">
        <div><strong>Локальная база</strong><span>Данные остаются на вашем устройстве</span></div>
        <div><strong>Оборудование</strong><span>Принтер, сканер штрихкодов и весы</span></div>
        <div><strong>Простая настройка</strong><span>Мастер займёт всего несколько минут</span></div>
      </div>
    </div>
  )
}

function StepHeader({ step, title, text }: { step: number; title: string; text: string }) {
  return (
    <header className="first-run__header">
      <span className="first-run__eyebrow">Шаг {step + 1} из {STEPS.length}</span>
      <h1>{title}</h1>
      <p>{text}</p>
    </header>
  )
}

function EditionCard({
  value,
  selected,
  title,
  description,
  features,
  onSelect,
}: {
  value: Edition
  selected: boolean
  title: string
  description: string
  features: string[]
  onSelect: (value: Edition) => void
}) {
  return (
    <button
      type="button"
      className={`first-run__edition${selected ? ' is-selected' : ''}`}
      onClick={() => onSelect(value)}
      aria-pressed={selected}
    >
      <span className="first-run__radio" aria-hidden="true"><i /></span>
      <strong>{title}</strong>
      <small>{description}</small>
      <ul>{features.map((feature) => <li key={feature}>{feature}</li>)}</ul>
    </button>
  )
}

function Field({
  label,
  required = false,
  wide = false,
  hint,
  children,
}: {
  label: string
  required?: boolean
  wide?: boolean
  hint?: string
  children: React.ReactNode
}) {
  return (
    <label className={`first-run__field${wide ? ' first-run__field--wide' : ''}`}>
      <span>{label}{required && <b> *</b>}</span>
      {children}
      {hint && <small>{hint}</small>}
    </label>
  )
}

function SummaryRow({
  label,
  value,
  onEdit,
}: {
  label: string
  value: string
  onEdit: () => void
}) {
  return (
    <div className="first-run__summary-row">
      <span>{label}</span>
      <strong>{value.trim() || 'Не указано'}</strong>
      <button type="button" onClick={onEdit}>Изменить</button>
    </div>
  )
}
