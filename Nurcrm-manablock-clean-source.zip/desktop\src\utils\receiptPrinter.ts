export interface ReceiptItem {
    name: string
    quantity: number
    price: number
    total: number
    isWeight?: boolean
  }
  
  export interface ReceiptData {
    storeName: string
    storeAddress: string
    inn: string
    date: string
    time: string
    receiptNumber: string
    cashier: string
    items: ReceiptItem[]
    subtotal: number
    discount: number
    total: number
    paymentMethod: string
    /** Сдача (наличные) */
    change?: number
  }
  
  export async function printReceipt(data: ReceiptData): Promise<boolean> {
    const printWindow = window.open('', '_blank', 'width=400,height=600')
    if (!printWindow) {
      alert('Не удалось открыть окно печати. Разрешите всплывающие окна.')
      return false
    }
  
    const itemsHtml = data.items.map(item => `
      <tr>
        <td style="padding: 8px 0;">${item.name}</td>
        <td style="text-align: center; padding: 8px 0;">
          ${item.isWeight ? `${item.quantity.toFixed(3)} кг` : `${item.quantity} шт`}
        </td>
        <td style="text-align: right; padding: 8px 0;">${item.total.toFixed(2)} сом</td>
      </tr>
    `).join('')

    const changeRow =
      data.change != null && data.change > 0 && data.paymentMethod.includes('Наличн')
        ? `<div class="total-line">
            <span>СДАЧА:</span>
            <span>${data.change.toFixed(2)} сом</span>
          </div>`
        : ''
  
    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <title>Чек №${data.receiptNumber}</title>
        <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body {
            font-family: 'Courier New', monospace;
            font-size: 12px;
            padding: 20px;
            width: 300px;
            margin: 0 auto;
          }
          .header { text-align: center; margin-bottom: 20px; }
          .store-name { font-size: 16px; font-weight: bold; margin-bottom: 5px; }
          .store-address { font-size: 10px; color: #666; margin-bottom: 3px; }
          .receipt-info { text-align: center; margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1px dashed #000; }
          .receipt-number { font-weight: bold; }
          .items-table { width: 100%; margin-bottom: 20px; }
          .items-table th { border-bottom: 1px solid #000; padding-bottom: 5px; text-align: left; }
          .items-table th:last-child { text-align: right; }
          .total-row { margin-top: 20px; padding-top: 10px; border-top: 1px dashed #000; }
          .total-line { display: flex; justify-content: space-between; margin-bottom: 5px; }
          .grand-total { font-size: 14px; font-weight: bold; margin-top: 10px; padding-top: 10px; border-top: 1px solid #000; }
          .footer { text-align: center; margin-top: 20px; padding-top: 10px; border-top: 1px dashed #000; font-size: 10px; }
          .barcode { text-align: center; margin: 15px 0; font-family: monospace; letter-spacing: 2px; }
          @media print {
            body { margin: 0; padding: 10px; }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="store-name">${data.storeName}</div>
          <div class="store-address">${data.storeAddress}</div>
          <div class="store-address">ИНН: ${data.inn}</div>
        </div>
        
        <div class="receipt-info">
          <div>КАССОВЫЙ ЧЕК</div>
          <div class="receipt-number">№ ${data.receiptNumber}</div>
          <div>${data.date} ${data.time}</div>
          <div>Кассир: ${data.cashier}</div>
        </div>
        
        <table class="items-table">
          <thead>
            <tr>
              <th>Товар</th>
              <th>Кол-во</th>
              <th>Сумма</th>
            </tr>
          </thead>
          <tbody>
            ${itemsHtml}
          </tbody>
        </table>
        
        <div class="total-row">
          <div class="total-line">
            <span>ИТОГО:</span>
            <span>${data.subtotal.toFixed(2)} сом</span>
          </div>
          ${data.discount > 0 ? `
          <div class="total-line">
            <span>СКИДКА:</span>
            <span>-${data.discount.toFixed(2)} сом</span>
          </div>
          ` : ''}
          <div class="grand-total">
            <div style="display: flex; justify-content: space-between;">
              <span>К ОПЛАТЕ:</span>
              <span>${data.total.toFixed(2)} сом</span>
            </div>
          </div>
          ${changeRow}
        </div>
        
        <div class="footer">
          <div>Способ оплаты: ${data.paymentMethod}</div>
          <div>Спасибо за покупку!</div>
          <div class="barcode">${data.receiptNumber.padStart(12, '0')}</div>
        </div>
        
        <script>
          window.onload = () => {
            window.print()
            window.onafterprint = () => window.close()
          }
        </script>
      </body>
      </html>
    `
  
    printWindow.document.write(html)
    printWindow.document.close()
    return true
  }