const { contextBridge, ipcRenderer } = require('electron')

contextBridge.exposeInMainWorld('nurcrm', {
  platform: process.platform,
  getMeta: () => ipcRenderer.invoke('app-get-meta'),
  markReady: () => ipcRenderer.invoke('app-mark-ready'),
  apiRequest: (opts) => ipcRenderer.invoke('api-request', opts),
})

contextBridge.exposeInMainWorld('electronAPI', {
  minimize: () => ipcRenderer.invoke('window-minimize'),
  close: () => ipcRenderer.invoke('window-close'),
  getFullscreen: () => ipcRenderer.invoke('window-get-fullscreen'),
  setFullscreen: (v) => ipcRenderer.invoke('window-set-fullscreen', v),
  toggleFullscreen: () => ipcRenderer.invoke('window-toggle-fullscreen'),
  onFullscreenChange: (cb) => {
    const fn = (_e, v) => cb(!!v)
    ipcRenderer.on('fullscreen-changed', fn)
    return () => ipcRenderer.removeListener('fullscreen-changed', fn)
  },
})

contextBridge.exposeInMainWorld('updaterAPI', {
  getInfo: () => ipcRenderer.invoke('updater-get-info'),
  check: (feedUrl) => ipcRenderer.invoke('updater-check', feedUrl),
  download: () => ipcRenderer.invoke('updater-download'),
  install: () => ipcRenderer.invoke('updater-install'),
  getChangelog: (version) => ipcRenderer.invoke('updater-changelog', version),
  onStatus: (cb) => {
    const fn = (_e, payload) => cb(payload)
    ipcRenderer.on('updater:status', fn)
    return () => ipcRenderer.removeListener('updater:status', fn)
  },
  onProgress: (cb) => {
    const fn = (_e, payload) => cb(payload)
    ipcRenderer.on('updater:progress', fn)
    return () => ipcRenderer.removeListener('updater:progress', fn)
  },
})

contextBridge.exposeInMainWorld('devicesAPI', {
  applySettings: (settings) => ipcRenderer.invoke('devices-apply-settings', settings),
  getStatus: () => ipcRenderer.invoke('devices-status'),
  testPrinter: (settings) => ipcRenderer.invoke('devices-test-printer', settings),
  testScale: (settings) => ipcRenderer.invoke('devices-test-scale', settings),
  runDiagnostics: (settings) => ipcRenderer.invoke('devices-diagnostics', settings),
  printReceipt: (payload, settings) => ipcRenderer.invoke('devices-print-receipt', payload, settings),
  listPorts: () => ipcRenderer.invoke('devices-list-ports'),
  getLiveWeight: () => ipcRenderer.invoke('devices-scale-live'),
  requestScaleRead: () => ipcRenderer.invoke('devices-scale-read'),
  setScaleWeightKg: (kg) => ipcRenderer.invoke('devices-scale-set', kg),
  reportBarcodeScan: (code) => ipcRenderer.invoke('devices-report-barcode', code),
  onScaleWeight: (cb) => {
    const fn = (_e, payload) => cb(payload)
    ipcRenderer.on('scale-weight-changed', fn)
    return () => ipcRenderer.removeListener('scale-weight-changed', fn)
  },
  reconnect: (settings) => ipcRenderer.invoke('devices-reconnect', settings),
})

contextBridge.exposeInMainWorld('systemAPI', {
  setAutoLaunch: (enabled) => ipcRenderer.invoke('system-set-autolaunch', enabled),
  openTouchKeyboard: () => ipcRenderer.invoke('system-open-touch-keyboard'),
  applyKiosk: (enabled) => ipcRenderer.invoke('system-apply-kiosk', enabled),
})

contextBridge.exposeInMainWorld('logsAPI', {
  read: (channel, limit) => ipcRenderer.invoke('logs-read', channel, limit),
})
