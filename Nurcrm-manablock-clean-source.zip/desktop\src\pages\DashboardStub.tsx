import { Link } from 'react-router-dom'

/**
 * Заглушка: в проекте отсутствует DashboardPage (экран кассы).
 * После восстановления замените маршрут «/» на <DashboardPage />.
 */
export function DashboardStub() {
  return (
    <div className="screen-shell" style={{ padding: 32, maxWidth: 520, margin: '0 auto' }}>
      <h1 style={{ fontSize: 22, marginBottom: 12 }}>Касса</h1>
      <p style={{ color: '#495057', lineHeight: 1.5, marginBottom: 16 }}>
        Файл экрана кассы в репозитории не найден. Откройте панель управления или настройки.
      </p>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}>
        <Link
          to="/panel"
          style={{
            padding: '10px 18px',
            background: '#fbbf24',
            color: '#422006',
            borderRadius: 10,
            fontWeight: 700,
            textDecoration: 'none',
          }}
        >
          Панель управления
        </Link>
        <Link
          to="/settings"
          style={{
            padding: '10px 18px',
            border: '1px solid #dee2e6',
            borderRadius: 10,
            fontWeight: 600,
            textDecoration: 'none',
            color: '#343a40',
          }}
        >
          Настройки
        </Link>
      </div>
    </div>
  )
}
