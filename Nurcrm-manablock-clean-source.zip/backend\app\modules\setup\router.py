from __future__ import annotations

import asyncio
import secrets

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.security import (
    create_access_token,
    create_setup_token,
    hash_password,
    verify_setup_token,
)
from app.db.database import get_db_session
from app.db.models import StoreSettings, User

router = APIRouter(prefix="/api/setup", tags=["setup"])
CURRENT_SETUP_VERSION = 2
INSTALLATION_SERVICE_CODE = "NURCRM-2026"


class SetupStatusResponse(BaseModel):
    needs_setup: bool
    setup_version: int = 0
    database_ready: bool = True
    edition: str | None = None
    company_name: str | None = None
    store_name: str | None = None
    currency: str | None = None


class SetupInitRequest(BaseModel):
    setup_token: str = Field(min_length=1)
    edition: str = Field(default="start", pattern="^(start|standard)$")
    company_name: str = Field(min_length=1, max_length=255)
    store_name: str = Field(min_length=1, max_length=255)
    owner_name: str = Field(min_length=1, max_length=255)
    inn: str = Field(default="", max_length=32)
    email: str = Field(default="", max_length=255)
    username: str = Field(min_length=2, max_length=255, default="admin")
    password: str = Field(min_length=6, max_length=128)
    currency: str = Field(default="KGS", max_length=16)
    currency_label: str = Field(default="сом", max_length=32)
    address: str = Field(default="", max_length=512)
    phone: str = Field(default="", max_length=64)


class SetupInitResponse(BaseModel):
    ok: bool = True
    access_token: str
    token_type: str = "bearer"
    user: dict
    store: dict


class ServiceCodeRequest(BaseModel):
    code: str = Field(min_length=1, max_length=64)


class ServiceCodeResponse(BaseModel):
    setup_token: str
    expires_in_minutes: int = 30


@router.get("/status", response_model=SetupStatusResponse)
async def setup_status(session: AsyncSession = Depends(get_db_session)) -> SetupStatusResponse:
    row = (await session.execute(select(StoreSettings).limit(1))).scalar_one_or_none()
    administrator = (
        await session.execute(
            select(User).where(
                User.is_active.is_(True),
                User.role.in_([ "owner", "admin" ]),
            ).limit(1)
        )
    ).scalar_one_or_none()
    if (
        row is None
        or not row.setup_completed
        or row.setup_version < CURRENT_SETUP_VERSION
        or administrator is None
    ):
        return SetupStatusResponse(needs_setup=True)
    return SetupStatusResponse(
        needs_setup=False,
        setup_version=row.setup_version,
        edition=row.edition,
        company_name=row.company_name,
        store_name=row.store_name,
        currency=row.currency,
    )


@router.post("/verify-service-code", response_model=ServiceCodeResponse)
async def verify_service_code(payload: ServiceCodeRequest) -> ServiceCodeResponse:
    if not secrets.compare_digest(payload.code.strip().upper(), INSTALLATION_SERVICE_CODE):
        await asyncio.sleep(0.4)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Неверный сервисный код установки.",
        )
    return ServiceCodeResponse(setup_token=create_setup_token())


@router.post("/init", response_model=SetupInitResponse, status_code=status.HTTP_201_CREATED)
async def setup_init(
    payload: SetupInitRequest,
    session: AsyncSession = Depends(get_db_session),
) -> SetupInitResponse:
    if not verify_setup_token(payload.setup_token):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Подтвердите сервисный код установки.",
        )

    existing = (await session.execute(select(StoreSettings).limit(1))).scalar_one_or_none()
    existing_administrator = (
        await session.execute(
            select(User).where(
                User.is_active.is_(True),
                User.role.in_(["owner", "admin"]),
            ).limit(1)
        )
    ).scalar_one_or_none()
    if (
        existing
        and existing.setup_completed
        and existing.setup_version >= CURRENT_SETUP_VERSION
        and existing_administrator is not None
    ):
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Система уже настроена.")

    user_exists = (
        await session.execute(select(User).where(User.username == payload.username))
    ).scalar_one_or_none()

    store = existing or StoreSettings()
    store.edition = payload.edition
    store.company_name = payload.company_name.strip()
    store.store_name = payload.store_name.strip()
    store.owner_name = payload.owner_name.strip()
    store.inn = payload.inn.strip()
    store.email = payload.email.strip()
    store.currency = payload.currency.strip() or "KGS"
    store.currency_label = payload.currency_label.strip() or "сом"
    store.address = payload.address.strip()
    store.phone = payload.phone.strip()
    store.setup_completed = True
    store.setup_version = CURRENT_SETUP_VERSION
    if existing is None:
        session.add(store)

    if user_exists is None:
        user = User(username=payload.username.strip())
        session.add(user)
    else:
        user = user_exists
    user.full_name = payload.owner_name.strip()
    user.hashed_password = hash_password(payload.password)
    user.role = "owner"
    user.is_active = True
    await session.commit()
    await session.refresh(user)
    await session.refresh(store)

    token = create_access_token(user)
    return SetupInitResponse(
        access_token=token,
        user={
            "id": user.id,
            "username": user.username,
            "full_name": user.full_name,
            "role": user.role,
        },
        store={
            "installation_id": store.installation_id,
            "edition": store.edition,
            "company_name": store.company_name,
            "store_name": store.store_name,
            "owner_name": store.owner_name,
            "inn": store.inn,
            "email": store.email,
            "currency": store.currency,
            "currency_label": store.currency_label,
        },
    )
