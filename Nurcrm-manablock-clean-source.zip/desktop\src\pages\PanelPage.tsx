import type { ReactElement } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { FinancePage }   from './Finance/FinancePage'
import { AnalyticsPage } from './Analytics/AnalyticsPage'
import { ReceiptsPage }  from './Receipts/ReceiptsPage'
import { PanelAddProductPage } from './PanelAddProductPage'
import { PanelProductReportPage } from './PanelProductReportPage'
import { PanelProductFilterProvider, usePanelProductFilter } from './panel/PanelProductFilterContext'
import { ProductReportModalProvider } from '../context/ProductReportModalProvider'
import { PanelKindFilter } from './panel/PanelKindFilter'
import { PosConnectionBadge } from '../components/PosConnectionBadge'
import './PanelPage.css'

type PanelTab = 'finance' | 'analytics' | 'receipts' | 'product-report' | 'add-product'

const VALID_TABS: PanelTab[] = ['finance', 'analytics', 'receipts', 'product-report', 'add-product']

/* ── SVG иконки ── */
const IcFinance = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none"
       stroke="currentColor" strokeWidth="2"
       strokeLinecap="round" strokeLinejoin="round">
    <rect x="2" y="5" width="20" height="14" rx="3"/>
    <path d="M2 10h20M6 15h4"/>
  </svg>
)
const IcAnalytics = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none"
       stroke="currentColor" strokeWidth="2"
       strokeLinecap="round" strokeLinejoin="round">
    <path d="M3 3v18h18"/>
    <path d="M7 16l4-5 4 3 4-7"/>
  </svg>
)
const IcAddProduct = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none"
       stroke="currentColor" strokeWidth="2"
       strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="3" width="18" height="18" rx="3"/>
    <path d="M12 8v8M8 12h8"/>
  </svg>
)
const IcReceipts = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none"
       stroke="currentColor" strokeWidth="2"
       strokeLinecap="round" strokeLinejoin="round">
    <path d="M4 2h16v22l-3-2-2 2-2-2-2 2-2-2-3 2V2z"/>
    <path d="M8 8h8M8 12h8M8 16h5"/>
  </svg>
)
const IcReport = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none"
       stroke="currentColor" strokeWidth="2"
       strokeLinecap="round" strokeLinejoin="round">
    <path d="M4 4h16v16H4z"/>
    <path d="M8 9h8M8 13h8M8 17h4"/>
  </svg>
)
const IcArrow = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
       stroke="currentColor" strokeWidth="2.2"
       strokeLinecap="round" strokeLinejoin="round">
    <path d="M19 12H5m0 0 7 7m-7-7 7-7"/>
  </svg>
)
const TABS: {
  id: PanelTab
  label: string
  sub: string
  Icon: () => ReactElement
}[] = [
  { id: 'finance',     label: 'Финансы',       sub: 'Выручка · Платежи', Icon: IcFinance   },
  { id: 'analytics',   label: 'Аналитика',     sub: 'Графики · Тренды',  Icon: IcAnalytics },
  { id: 'receipts',    label: 'Журнал чеков', sub: 'Сегодня · печать',    Icon: IcReceipts  },
  { id: 'product-report', label: 'Отчёт товаров', sub: 'Продажи · Остатки', Icon: IcReport },
  { id: 'add-product', label: 'Добавить товар', sub: 'Демо · локально', Icon: IcAddProduct },
]

function PanelPageBody() {
  const [searchParams, setSearchParams] = useSearchParams()
  const { productKind, setProductKind } = usePanelProductFilter()
  const raw = searchParams.get('tab') as PanelTab
  const tab: PanelTab = VALID_TABS.includes(raw) ? raw : 'finance'
  const setTab = (next: PanelTab) =>
    setSearchParams({ tab: next }, { replace: true })

  return (
    <div className="pp">

      {/* ── Шапка ── */}
      <header className="pp__header">
        <div className="pp__header-left">
          <Link to="/" className="pp__back">
            <IcArrow />
            <span>Касса</span>
          </Link>
          <div className="pp__divider" aria-hidden />
          <div className="pp__header-brand">
            <p className="pp__title">Панель управления</p>
            <p className="pp__subtitle">Финансы · Аналитика · Чеки · Добавить товар</p>
          </div>
          <PosConnectionBadge />
        </div>

        {/* Мобиль */}
        <nav className="pp__mobile-tabs" aria-label="Разделы">
          {TABS.map(({ id, label, Icon }) => (
            <button
              key={id}
              type="button"
              onClick={() => setTab(id)}
              className={`pp__mobile-tab${tab === id ? ' pp__mobile-tab--on' : ''}`}
            >
              <Icon />
              {label}
            </button>
          ))}
        </nav>
      </header>

      {/* ── Тело ── */}
      <div className="pp__body">

        {/* Сайдбар */}
        <aside className="pp__sidebar" aria-label="Навигация">

          <div className="pp__sidebar-section">
            <p className="pp__sidebar-label">Раздел</p>
            <nav className="pp__nav">
              {TABS.map(({ id, label, sub, Icon }) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => setTab(id)}
                  className={`pp__nav-item${tab === id ? ' pp__nav-item--on' : ''}`}
                  aria-current={tab === id ? 'page' : undefined}
                >
                  <span className="pp__nav-icon"><Icon /></span>
                  <span className="pp__nav-body">
                    <span className="pp__nav-label">{label}</span>
                    <span className="pp__nav-sub">{sub}</span>
                  </span>
                  {tab === id && <span className="pp__nav-bar" aria-hidden />}
                </button>
              ))}
            </nav>
          </div>

          <div className="pp__sidebar-hr" />

          <div className="pp__sidebar-section">
            <p className="pp__sidebar-label">Тип товаров</p>
            <PanelKindFilter value={productKind} onChange={setProductKind} />
            <p className="pp__filter-hint">
              Весовые — на развес (кг), штучные — поштучные позиции. Действует на финансы, аналитику, чеки и отчёт товаров.
            </p>
          </div>

        </aside>

        {/* Контент — все вкладки остаются смонтированными, чтобы не терять данные и не дублировать запросы */}
        <main className="pp__main">
          <div className="pp__content">
            <div className={`pp__pane${tab === 'finance' ? ' pp__pane--active' : ''}`} hidden={tab !== 'finance'}>
              <FinancePage embedded active={tab === 'finance'} />
            </div>
            <div className={`pp__pane${tab === 'analytics' ? ' pp__pane--active' : ''}`} hidden={tab !== 'analytics'}>
              <AnalyticsPage embedded active={tab === 'analytics'} />
            </div>
            <div className={`pp__pane${tab === 'receipts' ? ' pp__pane--active' : ''}`} hidden={tab !== 'receipts'}>
              <ReceiptsPage embedded active={tab === 'receipts'} />
            </div>
            <div className={`pp__pane${tab === 'product-report' ? ' pp__pane--active' : ''}`} hidden={tab !== 'product-report'}>
              <PanelProductReportPage active={tab === 'product-report'} />
            </div>
            <div className={`pp__pane${tab === 'add-product' ? ' pp__pane--active' : ''}`} hidden={tab !== 'add-product'}>
              <PanelAddProductPage />
            </div>
          </div>
        </main>

      </div>
    </div>
  )
}

export function PanelPage() {
  return (
    <PanelProductFilterProvider>
      <ProductReportModalProvider>
        <PanelPageBody />
      </ProductReportModalProvider>
    </PanelProductFilterProvider>
  )
}