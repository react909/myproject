import { useCallback, useEffect, useMemo, useState } from 'react'
import { AnimatePresence } from 'framer-motion'
import { getCurrentAccountKey } from '../../services/accountSession'
import { usePanelProductFilter } from '../panel/PanelProductFilterContext'
import {
  receiptMatchesProductKind,
  receiptRevenueForKind,
} from '../panelFilterUtils'
import { usePanelAsyncLoad } from '../../hooks/usePanelAsyncLoad'
import { HeavyPageGate } from '../HeavyPageGate'
import { LoadingScreen } from '../LoadingScreen'
import { PanelFetchOverlay } from '../PanelFetchOverlay'
import { useNotifications } from '../../components/notifications/NotificationProvider'
import { ReceiptsHeader } from './components/ReceiptsHeader'
import { ReceiptsFilters } from './components/ReceiptsFilters'
import { ReceiptsStats } from './components/ReceiptStats'
import { ReceiptsTable } from './components/ReceiptsTable'
import { ReceiptDetailsModal } from './components/ReceiptDetailsModal'
import { RefundModal } from './components/RefundModal'
import { printDuplicateReceipt } from '../../services/receiptPrint'
import { fetchReceipts, fetchReceiptDetails, refundReceipt as refundReceiptApi } from '../../services/receipts'
import { mapLimited } from '../../services/productReport'
import { defaultReceiptsFilters } from './receiptFilters'
import { receiptRuDateToIso } from '../../utils/today'
import type { Receipt, ReceiptsFilters as Filters, RefundLineSelection } from './types'
import './ReceiptsPage.css'

export type ReceiptsPageProps = {
  embedded?: boolean
  active?: boolean
}

export function ReceiptsPage({ embedded = false, active = true }: ReceiptsPageProps) {
  const { productKind } = usePanelProductFilter()
  const { push } = useNotifications()

  const {
    data: allReceipts,
    isLoading,
    isRefreshing,
    error,
    hasData,
    reload,
  } = usePanelAsyncLoad<Receipt[]>(
    async (signal) => {
      const list = await fetchReceipts(300, signal)
      if (productKind === 'all') return list
      return mapLimited(list, 10, (receipt) =>
        receipt.items.length > 0 ? Promise.resolve(receipt) : fetchReceiptDetails(receipt),
      )
    },
    [productKind],
    active,
    `panel:receipts:${getCurrentAccountKey()}:300:${productKind}`,
  )

  useEffect(() => {
    const onInvalidate = () => {
      if (active) reload()
    }
    window.addEventListener('nurcrm-data-invalidated', onInvalidate)
    return () => window.removeEventListener('nurcrm-data-invalidated', onInvalidate)
  }, [active, reload])

  useEffect(() => {
    if (!error) return
    push({
      kind: 'error',
      title: 'CRM',
      message: error,
      dismissMs: 8000,
    })
  }, [error, push])

  const receipts = allReceipts ?? []
  const [filters, setFilters] = useState<Filters>(() => defaultReceiptsFilters())
  const [selectedReceipt, setSelectedReceipt] = useState<Receipt | null>(null)
  const [refundReceipt, setRefundReceipt] = useState<Receipt | null>(null)

  const cashiers = useMemo(() => {
    const set = new Set(receipts.map((r) => r.cashier))
    return Array.from(set).sort()
  }, [receipts])

  const filteredReceipts = useMemo(() => {
    return receipts.filter((r) => {
      if (filters.search && !r.number.toLowerCase().includes(filters.search.toLowerCase())) {
        return false
      }

      if (filters.customer) {
        const needle = filters.customer.trim().toLowerCase()
        const name = (r.customerName ?? '').toLowerCase()
        if (!name.includes(needle)) return false
      }

      if (filters.product) {
        const needle = filters.product.trim().toLowerCase()
        const hit = r.items.some((item) => item.name.toLowerCase().includes(needle))
        if (!hit && r.items.length > 0) return false
        if (!hit && r.items.length === 0 && !r.number.toLowerCase().includes(needle)) return false
      }

      if (filters.dateFrom) {
        const iso = receiptRuDateToIso(r.date)
        if (iso && iso < filters.dateFrom) return false
      }

      if (filters.dateTo) {
        const iso = receiptRuDateToIso(r.date)
        if (iso && iso > filters.dateTo) return false
      }

      if (filters.timeFrom && r.time < filters.timeFrom) return false
      if (filters.timeTo && r.time > filters.timeTo) return false

      if (filters.paymentMethod !== 'all' && r.paymentMethod !== filters.paymentMethod) {
        return false
      }

      if (filters.status !== 'all' && r.status !== filters.status) {
        return false
      }

      if (filters.cashier !== 'all' && r.cashier !== filters.cashier) {
        return false
      }

      return receiptMatchesProductKind(r, productKind)
    })
  }, [receipts, filters, productKind])

  const stats = useMemo(() => {
    const totalReceipts = filteredReceipts.length
    const totalRevenue = filteredReceipts.reduce(
      (s, r) => s + receiptRevenueForKind(r, productKind),
      0,
    )
    const totalRefunds = filteredReceipts.reduce((sum, receipt) => {
      if (receipt.status !== 'refunded' && receipt.status !== 'partial_refund') return sum
      const returnedItems = receipt.items
        .filter((item) => item.refunded || item.refundedQuantity)
        .reduce((itemSum, item) => {
          const qty = item.refundedQuantity ?? item.quantity
          return itemSum + (item.total / Math.max(item.quantity, 1)) * qty
        }, 0)
      return sum + (returnedItems > 0 ? returnedItems : receipt.total)
    }, 0)
    const avgCheck = totalReceipts > 0 ? Math.round(totalRevenue / totalReceipts) : 0

    return { totalReceipts, totalRevenue, totalRefunds, avgCheck }
  }, [filteredReceipts, productKind])

  // Список чеков приходит без позиций — при открытии деталей/возврата
  // подгружаем полную продажу (товары + кассир) по id.
  const openDetails = useCallback(async (receipt: Receipt) => {
    setSelectedReceipt(receipt)
    const full = await fetchReceiptDetails(receipt)
    setSelectedReceipt((current) => (current && current.id === receipt.id ? full : current))
  }, [])

  const openRefund = useCallback(async (receipt: Receipt) => {
    const full = receipt.items.length > 0 ? receipt : await fetchReceiptDetails(receipt)
    setRefundReceipt(full)
  }, [])

  const handlePrint = async (receipt: Receipt) => {
    const result = await printDuplicateReceipt(receipt)
    if (result?.ok) {
      push({
        kind: 'success',
        title: 'Печать',
        message: `Дубликат чека ${receipt.number} отправлен на принтер`,
        dismissMs: 4000,
      })
    } else {
      push({
        kind: 'error',
        title: 'Принтер',
        message: result?.message ?? 'Не удалось напечатать дубликат',
        dismissMs: 8000,
      })
    }
  }

  const handleRefund = async (items: RefundLineSelection[], reason: string) => {
    if (!refundReceipt) return
    try {
      await refundReceiptApi(refundReceipt, items, reason)
      setRefundReceipt(null)
      reload()
      push({
        kind: 'success',
        title: 'Возврат',
        message: `Возврат по чеку ${refundReceipt.number} оформлен.`,
      })
    } catch (err: any) {
      push({
        kind: 'error',
        title: 'Возврат',
        message: err?.response?.data?.detail ?? err?.message ?? 'CRM не приняла возврат',
        dismissMs: 8000,
      })
    }
  }

  const handleExport = async () => {
    const rows = await mapLimited(filteredReceipts, 6, (r) =>
      r.items.length > 0 ? Promise.resolve(r) : fetchReceiptDetails(r),
    )
    const csv = [
      'Номер,Дата,Время,Кассир,Оплата,Статус,Товар,Кол-во,Цена,Себестоимость,Выручка,Прибыль',
      ...rows.flatMap((r) => r.items.map((item) => {
        const cost = (item.purchasePrice ?? 0) * item.quantity
        const profit = item.total - cost
        return [
          r.number,
          r.date,
          r.time,
          r.cashier,
          r.paymentMethod,
          r.status,
          item.name,
          item.quantity,
          item.price,
          cost,
          item.total,
          profit,
        ].map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(';')
      })),
    ].join('\n')
    const blob = new Blob([`\ufeff${csv}`], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `receipts-${new Date().toISOString().slice(0, 10)}.csv`
    a.click()
    URL.revokeObjectURL(url)
  }

  const periodLabel = filters.period === 'today'
    ? 'Сегодня'
    : filters.period === 'week'
      ? '7 дней'
      : 'Все чеки'

  const inner = (
    <div className={`receipts-page panel-fetch-shell${embedded ? ' receipts-page--embedded' : ''}`}>
      {isRefreshing && hasData ? <PanelFetchOverlay label="Обновление чеков…" /> : null}

      <ReceiptsHeader
        totalReceipts={receipts.length}
        filteredCount={filteredReceipts.length}
        periodLabel={periodLabel}
        onRefresh={reload}
        onExport={handleExport}
        isRefreshing={isRefreshing}
        embedded={embedded}
      />

      <div className="receipts-page__body">
        <ReceiptsFilters filters={filters} onFiltersChange={setFilters} cashiers={cashiers} />

        <ReceiptsStats
          totalReceipts={stats.totalReceipts}
          totalRevenue={stats.totalRevenue}
          totalRefunds={stats.totalRefunds}
          avgCheck={stats.avgCheck}
        />

        <ReceiptsTable
          receipts={filteredReceipts}
          onViewDetails={openDetails}
          onPrint={handlePrint}
          onRefund={openRefund}
        />
      </div>

      <AnimatePresence>
        {selectedReceipt && (
          <ReceiptDetailsModal
            receipt={selectedReceipt}
            onClose={() => setSelectedReceipt(null)}
            onPrint={() => {
              handlePrint(selectedReceipt)
              setSelectedReceipt(null)
            }}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {refundReceipt && (
          <RefundModal
            receipt={refundReceipt}
            onConfirm={handleRefund}
            onCancel={() => setRefundReceipt(null)}
          />
        )}
      </AnimatePresence>
    </div>
  )

  if (!hasData && isLoading) {
    return (
      <LoadingScreen
        title="Загрузка истории чеков..."
        subtitle="Берём продажи, кассиров, оплату и позиции из CRM"
      />
    )
  }

  if (!hasData) {
    return (
      <LoadingScreen
        title="Загрузка истории чеков..."
        subtitle={error ?? 'Берём продажи, кассиров, оплату и позиции из CRM'}
      />
    )
  }

  if (embedded) return inner

  return (
    <HeavyPageGate
      loadingTitle="Загрузка истории чеков..."
      loadingSubtitle="Подготовка данных для отображения"
    >
      {inner}
    </HeavyPageGate>
  )
}
