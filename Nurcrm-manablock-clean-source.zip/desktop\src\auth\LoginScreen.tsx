import { forwardRef, useImperativeHandle, useRef, useState } from 'react'
import client from '../api/client'
import { prepareAccountSession } from '../services/accountSession'
import logoImage from '../assets/images.png'
import './LoginScreen.css'

export type LoginScreenHandle = {
  submit: () => void
  focusInput: () => void
}

type LoginScreenProps = {
  onSuccess: (username: string) => void
  onNotify: (message: string) => void
  activeInputRef?: React.RefObject<HTMLInputElement | null>
  version?: string
}

export const LoginScreen = forwardRef<LoginScreenHandle, LoginScreenProps>(
  function LoginScreen({ onSuccess, onNotify, activeInputRef, version = '1.0.0' }, ref) {
    const [username, setUsername] = useState(
      () => localStorage.getItem('nurcrm-last-username') ?? '',
    )
    const [password, setPassword] = useState('')
    const [showPass, setShowPass] = useState(false)
    const [busy, setBusy] = useState(false)
    const [error, setError] = useState('')
    const usernameInputRef = useRef<HTMLInputElement>(null)

    const handleSubmit = async () => {
      setError('')
      const trimmed = username.trim()
      if (!trimmed || !password) {
        setError('Введите логин и пароль')
        return
      }

      setBusy(true)
      try {
        localStorage.setItem('nurcrm-api-url', 'http://127.0.0.1:8000')
        const res = await client.post('/api/auth/login', {
          username: trimmed,
          password,
        })

        const token = res.data?.access_token
        if (!token) throw new Error('Сервер не вернул токен')

        localStorage.setItem('nurcrm-token', token)
        localStorage.removeItem('nurcrm-refresh-token')
        if (res.data?.user) {
          try {
            localStorage.setItem('nurcrm-user', JSON.stringify(res.data.user))
          } catch {
            /* ignore */
          }
        }
        localStorage.setItem('nurcrm-user-email', trimmed)
        localStorage.setItem('nurcrm-last-username', trimmed)
        prepareAccountSession(trimmed)
        onNotify('Вход выполнен')
        onSuccess(trimmed)
      } catch (err: any) {
        const detail =
          err?.response?.data?.detail
          || err?.message
          || 'Ошибка входа'
        setError(typeof detail === 'string' ? detail : 'Ошибка входа')
        onNotify(typeof detail === 'string' ? detail : 'Ошибка входа')
      } finally {
        setBusy(false)
      }
    }

    useImperativeHandle(ref, () => ({
      submit: () => void handleSubmit(),
      focusInput: () => {
        const el = activeInputRef?.current ?? usernameInputRef.current
        el?.focus()
      },
    }))

    return (
      <div className="ls-root">
        <div className="ls-left">
          <div className="ls-left__circle ls-left__circle--lg" />
          <div className="ls-left__circle ls-left__circle--sm" />
          <div className="ls-brand">
            <div className="ls-logo-wrap">
              <img src={logoImage} alt="Logo" className="ls-logo" />
            </div>
            <div>
              <div className="ls-brand__name">
                NurCRM Offline
                <span>.</span>
              </div>
              <div className="ls-brand__tagline">Локальная касса без интернета</div>
            </div>
          </div>
          <div className="ls-divider" />
          <div className="ls-features">
            <div>Товары и остатки — на этом компьютере</div>
            <div>Продажи, чеки, долги, смены</div>
            <div>Принтер, весы, сканер</div>
          </div>
        </div>

        <div className="ls-right">
          <form
            className="ls-card"
            onSubmit={(e) => {
              e.preventDefault()
              void handleSubmit()
            }}
          >
            <h1 className="ls-title">Вход</h1>
            <p className="ls-subtitle">Локальный аккаунт магазина</p>

            <label className="ls-field">
              <span>Логин</span>
              <input
                ref={(el) => {
                  usernameInputRef.current = el
                  if (activeInputRef && 'current' in activeInputRef) {
                    ;(activeInputRef as React.MutableRefObject<HTMLInputElement | null>).current = el
                  }
                }}
                type="text"
                autoComplete="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                disabled={busy}
              />
            </label>

            <label className="ls-field">
              <span>Пароль</span>
              <div className="ls-pass-wrap">
                <input
                  type={showPass ? 'text' : 'password'}
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  disabled={busy}
                />
                <button type="button" className="ls-pass-toggle" onClick={() => setShowPass((v) => !v)}>
                  {showPass ? 'Скрыть' : 'Показать'}
                </button>
              </div>
            </label>

            {error && <p className="ls-error">{error}</p>}

            <button type="submit" className="ls-submit" disabled={busy}>
              {busy ? 'Вход…' : 'Войти'}
            </button>

            <p className="ls-version">v{version} · Offline</p>
          </form>
        </div>
      </div>
    )
  },
)
