/**
 * Production ICO для exe, NSIS installer, ярлыков и taskbar.
 * Источник: src/assets/images.png (тот же логотип, что в dist/assets/images-*.png).
 */
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import pngToIco from 'png-to-ico'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const root = path.resolve(__dirname, '..')

function resolveLogoPng() {
  const candidates = [
    path.join(root, 'src', 'assets', 'images.png'),
    path.join(root, 'assets', 'images.png'),
    path.join(root, 'assets', 'logo.png'),
  ]

  const distAssets = path.join(root, 'dist', 'assets')
  if (fs.existsSync(distAssets)) {
    const hashed = fs
      .readdirSync(distAssets)
      .filter((f) => /^images-.+\.png$/i.test(f))
      .sort()
    if (hashed[0]) candidates.push(path.join(distAssets, hashed[0]))
  }

  for (const p of candidates) {
    if (fs.existsSync(p)) return p
  }
  return null
}

const src = resolveLogoPng()
if (!src) {
  console.error(
    'Logo PNG not found. Add desktop/src/assets/images.png (app logo) and rerun.',
  )
  process.exit(1)
}

const outDirs = [
  path.join(root, 'build-resources'),
  path.join(root, 'electron'),
]
for (const dir of outDirs) {
  fs.mkdirSync(dir, { recursive: true })
}

const buildPng = path.join(root, 'build-resources', 'logo.png')
fs.copyFileSync(src, buildPng)

/** png-to-ico создаёт multi-size ICO из одного PNG */
const buf = await pngToIco(buildPng)
if (buf.length > 400_000) {
  console.warn(`WARN: icon.ico is large (${buf.length} bytes) — check logo resolution`)
}

for (const dir of outDirs) {
  const outIco = path.join(dir, 'icon.ico')
  fs.writeFileSync(outIco, buf)
  console.log('OK:', outIco, `(${buf.length} bytes) from ${path.relative(root, src)}`)
}
