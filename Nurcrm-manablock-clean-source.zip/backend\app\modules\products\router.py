from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field
from sqlalchemy import or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.security import get_current_user
from app.db.database import get_db_session
from app.db.models import Category, Product, StockMove, User

router = APIRouter(prefix="/api", tags=["products"])


class CategoryOut(BaseModel):
    id: int
    name: str
    sort_order: int


class CategoryCreate(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    sort_order: int = 0


class ProductOut(BaseModel):
    id: int
    name: str
    barcode: str
    extra_barcodes: str
    kind: str
    unit: str
    price: float
    wholesale_price: float
    cost_price: float
    stock_qty: float
    category_id: int | None
    category_name: str | None = None
    image: str
    is_active: bool


class ProductCreate(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    barcode: str = ""
    extra_barcodes: str = ""
    kind: str = Field(default="piece", pattern="^(piece|weight|service)$")
    unit: str = "шт"
    price: float = Field(ge=0)
    wholesale_price: float = Field(default=0, ge=0)
    cost_price: float = Field(default=0, ge=0)
    stock_qty: float = Field(default=0)
    category_id: int | None = None
    image: str = ""


class ProductUpdate(BaseModel):
    name: str | None = None
    barcode: str | None = None
    extra_barcodes: str | None = None
    kind: str | None = None
    unit: str | None = None
    price: float | None = None
    wholesale_price: float | None = None
    cost_price: float | None = None
    stock_qty: float | None = None
    category_id: int | None = None
    image: str | None = None
    is_active: bool | None = None


def _product_out(p: Product, category_name: str | None = None) -> ProductOut:
    return ProductOut(
        id=p.id,
        name=p.name,
        barcode=p.barcode,
        extra_barcodes=p.extra_barcodes,
        kind=p.kind,
        unit=p.unit,
        price=p.price,
        wholesale_price=p.wholesale_price,
        cost_price=p.cost_price,
        stock_qty=p.stock_qty,
        category_id=p.category_id,
        category_name=category_name,
        image=p.image,
        is_active=p.is_active,
    )


@router.get("/categories", response_model=list[CategoryOut])
async def list_categories(
    session: AsyncSession = Depends(get_db_session),
    _: User = Depends(get_current_user),
) -> list[CategoryOut]:
    rows = (await session.execute(select(Category).order_by(Category.sort_order, Category.name))).scalars().all()
    return [CategoryOut(id=c.id, name=c.name, sort_order=c.sort_order) for c in rows]


@router.post("/categories", response_model=CategoryOut, status_code=status.HTTP_201_CREATED)
async def create_category(
    payload: CategoryCreate,
    session: AsyncSession = Depends(get_db_session),
    _: User = Depends(get_current_user),
) -> CategoryOut:
    cat = Category(name=payload.name.strip(), sort_order=payload.sort_order)
    session.add(cat)
    await session.commit()
    await session.refresh(cat)
    return CategoryOut(id=cat.id, name=cat.name, sort_order=cat.sort_order)


@router.get("/products", response_model=list[ProductOut])
async def list_products(
    q: str = Query(default=""),
    active_only: bool = Query(default=True),
    session: AsyncSession = Depends(get_db_session),
    _: User = Depends(get_current_user),
) -> list[ProductOut]:
    stmt = select(Product, Category.name).outerjoin(Category, Product.category_id == Category.id)
    if active_only:
        stmt = stmt.where(Product.is_active.is_(True))
    if q.strip():
        like = f"%{q.strip()}%"
        stmt = stmt.where(
            or_(
                Product.name.ilike(like),
                Product.barcode.ilike(like),
                Product.extra_barcodes.ilike(like),
            )
        )
    stmt = stmt.order_by(Product.name)
    rows = (await session.execute(stmt)).all()
    return [_product_out(p, cat_name) for p, cat_name in rows]


@router.get("/products/{product_id}", response_model=ProductOut)
async def get_product(
    product_id: int,
    session: AsyncSession = Depends(get_db_session),
    _: User = Depends(get_current_user),
) -> ProductOut:
    row = (
        await session.execute(
            select(Product, Category.name)
            .outerjoin(Category, Product.category_id == Category.id)
            .where(Product.id == product_id)
        )
    ).first()
    if not row:
        raise HTTPException(status_code=404, detail="Товар не найден.")
    p, cat_name = row
    return _product_out(p, cat_name)


@router.post("/products", response_model=ProductOut, status_code=status.HTTP_201_CREATED)
async def create_product(
    payload: ProductCreate,
    session: AsyncSession = Depends(get_db_session),
    user: User = Depends(get_current_user),
) -> ProductOut:
    unit = payload.unit
    if payload.kind == "weight":
        unit = "кг"
    elif payload.kind == "service":
        unit = "усл"
    product = Product(
        name=payload.name.strip(),
        barcode=payload.barcode.strip(),
        extra_barcodes=payload.extra_barcodes.strip(),
        kind=payload.kind,
        unit=unit,
        price=payload.price,
        wholesale_price=payload.wholesale_price,
        cost_price=payload.cost_price,
        stock_qty=0 if payload.kind == "service" else payload.stock_qty,
        category_id=payload.category_id,
        image=payload.image,
    )
    session.add(product)
    await session.flush()
    if payload.kind != "service" and payload.stock_qty != 0:
        session.add(
            StockMove(
                product_id=product.id,
                qty_delta=payload.stock_qty,
                reason="adjust",
                ref_type="initial",
                note="Начальный остаток",
                user_id=user.id,
            )
        )
    await session.commit()
    await session.refresh(product)
    return _product_out(product)


@router.patch("/products/{product_id}", response_model=ProductOut)
async def update_product(
    product_id: int,
    payload: ProductUpdate,
    session: AsyncSession = Depends(get_db_session),
    user: User = Depends(get_current_user),
) -> ProductOut:
    product = (await session.execute(select(Product).where(Product.id == product_id))).scalar_one_or_none()
    if not product:
        raise HTTPException(status_code=404, detail="Товар не найден.")
    data = payload.model_dump(exclude_unset=True)
    new_stock = data.pop("stock_qty", None)
    for key, value in data.items():
        setattr(product, key, value)
    if new_stock is not None and product.kind != "service":
        delta = float(new_stock) - float(product.stock_qty)
        if abs(delta) > 1e-9:
            product.stock_qty = float(new_stock)
            session.add(
                StockMove(
                    product_id=product.id,
                    qty_delta=delta,
                    reason="adjust",
                    ref_type="manual",
                    note="Корректировка остатка",
                    user_id=user.id,
                )
            )
    await session.commit()
    await session.refresh(product)
    return _product_out(product)


@router.delete("/products/{product_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_product(
    product_id: int,
    session: AsyncSession = Depends(get_db_session),
    _: User = Depends(get_current_user),
) -> None:
    product = (await session.execute(select(Product).where(Product.id == product_id))).scalar_one_or_none()
    if not product:
        raise HTTPException(status_code=404, detail="Товар не найден.")
    product.is_active = False
    await session.commit()
