import { useState } from 'react'
import type { Receipt } from '../types'

type Props = {
  receipts: Receipt[]
  onViewDetails: (r: Receipt) => void
  onPrint: (r: Receipt) => void
  onRefund: (r: Receipt) => void
}

const STATUS_MAP = {
  completed:      { label: 'Продано',            cls: 'completed' },
  debt:           { label: 'Долг',               cls: 'debt' },
  refunded:       { label: 'Возврат',            cls: 'refunded'  },
  partial_refund: { label: 'Частичный возврат',  cls: 'partial_refund' },
  canceled:       { label: 'Отменён',            cls: 'canceled' },
}
const PAY_MAP = {
  cash:  { label: 'Наличные', icon: '💵' },
  card:  { label: 'Карта',    icon: '💳' },
  mixed: { label: 'Смешанная',icon: '🔀' },
  debt:  { label: 'В долг',   icon: '📝' },
}

const IcEye = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
    stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
    <circle cx="12" cy="12" r="3"/>
  </svg>
)
const IcPrint = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
    stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M6 9V2h12v7M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/>
    <path d="M6 14h12v8H6z"/>
  </svg>
)
const IcRefund = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
    stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="1 4 1 10 7 10"/>
    <path d="M3.51 15a9 9 0 1 0 .49-3.96"/>
  </svg>
)

export function ReceiptsTable({ receipts, onViewDetails, onPrint, onRefund }: Props) {
  const [sortKey, setSortKey]   = useState<'date' | 'total' | 'number'>('date')
  const [sortDir, setSortDir]   = useState<'asc' | 'desc'>('desc')
  const [page, setPage]         = useState(1)
  const PER_PAGE = 20

  const handleSort = (key: typeof sortKey) => {
    if (sortKey === key) setSortDir(d => d === 'asc' ? 'desc' : 'asc')
    else { setSortKey(key); setSortDir('desc') }
  }

  const sorted = [...receipts].sort((a, b) => {
    let cmp = 0
    if (sortKey === 'total')  cmp = a.total - b.total
    if (sortKey === 'number') cmp = a.number.localeCompare(b.number)
    if (sortKey === 'date') {
      const toMs = (r: Receipt) => {
        const [d, m, y] = r.date.split('.')
        return new Date(`${y}-${m}-${d} ${r.time}`).getTime()
      }
      cmp = toMs(a) - toMs(b)
    }
    return sortDir === 'asc' ? cmp : -cmp
  })

  const totalPages = Math.ceil(sorted.length / PER_PAGE)
  const paged = sorted.slice((page - 1) * PER_PAGE, page * PER_PAGE)

  if (receipts.length === 0) {
    return (
      <div className="receipts-empty">
        <div className="receipts-empty__icon">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none"
            stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"
            opacity="0.3">
            <path d="M4 2h16v22l-3-2-2 2-2-2-2 2-2-2-3 2V2z"/>
            <path d="M8 8h8M8 12h8M8 16h5"/>
          </svg>
        </div>
        <p className="receipts-empty__text">Чеки не найдены</p>
        <p className="receipts-empty__hint">Попробуйте изменить фильтры или сбросить поиск</p>
      </div>
    )
  }

  const SortIcon = ({ col }: { col: typeof sortKey }) => {
    if (sortKey !== col) return (
      <svg width="10" height="10" viewBox="0 0 24 24" fill="none"
        stroke="currentColor" strokeWidth="2" opacity="0.3">
        <path d="M12 5v14M5 12l7-7 7 7"/>
      </svg>
    )
    return (
      <svg width="10" height="10" viewBox="0 0 24 24" fill="none"
        stroke="currentColor" strokeWidth="2.5"
        style={{ transform: sortDir === 'asc' ? 'rotate(0deg)' : 'rotate(180deg)' }}>
        <path d="M12 5v14M5 12l7-7 7 7"/>
      </svg>
    )
  }

  return (
    <div className="receipts-table-wrap">
      <table className="receipts-table">
        <thead>
          <tr>
            <th
              className="receipts-table__th--sort"
              onClick={() => handleSort('number')}
            >
              № Чека <SortIcon col="number"/>
            </th>
            <th
              className="receipts-table__th--sort"
              onClick={() => handleSort('date')}
            >
              Дата / Время <SortIcon col="date"/>
            </th>
            <th>Кассир</th>
            <th>Позиций</th>
            <th
              className="receipts-table__th--sort"
              onClick={() => handleSort('total')}
            >
              Сумма <SortIcon col="total"/>
            </th>
            <th>Оплата</th>
            <th>Статус</th>
            <th>Действия</th>
          </tr>
        </thead>
        <tbody>
          {paged.map((r, i) => (
            <tr
              key={r.id}
              className="receipts-table__row"
              style={{ animationDelay: `${i * 20}ms` }}
            >
              <td className="receipts-table__number">{r.number}</td>
              <td>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                  <span style={{ fontWeight: 600, fontSize: 13 }}>{r.date}</span>
                  <span style={{ fontSize: 11, color: 'var(--text-3)', fontWeight: 500 }}>{r.time}</span>
                </div>
              </td>
              <td style={{ fontSize: 13, color: 'var(--text-2)' }}>{r.cashier}</td>
              <td style={{ fontSize: 13, color: 'var(--text-2)', textAlign: 'center' }}>
                {r.items.length}
              </td>
              <td className="receipts-table__total">
                {r.total.toLocaleString('ru-RU')} сом
                {r.discount > 0 && (
                  <span style={{
                    display: 'block', fontSize: 10.5, color: 'var(--red)',
                    fontWeight: 600, marginTop: 1,
                  }}>
                    −{r.discount.toLocaleString('ru-RU')} сом скидка
                  </span>
                )}
              </td>
              <td>
                <span className="receipts-table__payment">
                  {PAY_MAP[r.paymentMethod].label}
                </span>
              </td>
              <td>
                <span className={`receipts-table__status receipts-table__status--${STATUS_MAP[r.status].cls}`}>
                  {STATUS_MAP[r.status].label}
                </span>
              </td>
              <td>
                <div className="receipts-table__actions">
                  <button
                    type="button"
                    className="receipts-action-btn receipts-action-btn--view"
                    onClick={() => onViewDetails(r)}
                    title="Просмотр деталей"
                  >
                    <IcEye/>
                  </button>
                  <button
                    type="button"
                    className="receipts-action-btn receipts-action-btn--print"
                    onClick={() => onPrint(r)}
                    title="Печать дубликата"
                  >
                    <IcPrint/>
                  </button>
                  {r.status === 'completed' && (
                    <button
                      type="button"
                      className="receipts-refund-pill"
                      onClick={() => onRefund(r)}
                      title="Оформить возврат клиенту"
                    >
                      <IcRefund/>
                      <span>Возврат</span>
                    </button>
                  )}
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Пагинация */}
      {totalPages > 1 && (
        <div className="receipts-pagination">
          <span className="receipts-pagination__info">
            {((page - 1) * PER_PAGE) + 1}–{Math.min(page * PER_PAGE, sorted.length)} из {sorted.length}
          </span>
          <div className="receipts-pagination__controls">
            <button
              type="button"
              className="receipts-pagination__btn"
              onClick={() => setPage(p => Math.max(1, p - 1))}
              disabled={page === 1}
            >
              ←
            </button>
            {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
              const p = Math.max(1, Math.min(page - 2, totalPages - 4)) + i
              return (
                <button
                  key={p}
                  type="button"
                  className={`receipts-pagination__btn${page === p ? ' receipts-pagination__btn--on' : ''}`}
                  onClick={() => setPage(p)}
                >
                  {p}
                </button>
              )
            })}
            <button
              type="button"
              className="receipts-pagination__btn"
              onClick={() => setPage(p => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
            >
              →
            </button>
          </div>
        </div>
      )}
    </div>
  )
}