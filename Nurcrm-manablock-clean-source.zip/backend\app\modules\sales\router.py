from __future__ import annotations

from datetime import UTC, datetime

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.security import get_current_user
from app.db.database import get_db_session
from app.db.models import DebtPayment, Product, Sale, SaleCounter, SaleItem, Shift, StockMove, User

router = APIRouter(prefix="/api", tags=["sales"])


class SaleItemIn(BaseModel):
    product_id: int | None = None
    name: str
    is_weight: bool = False
    is_service: bool = False
    quantity: float = Field(gt=0)
    unit_price: float = Field(ge=0)
    discount: float = Field(default=0, ge=0)
    line_total: float = Field(ge=0)


class SaleCreateRequest(BaseModel):
    items: list[SaleItemIn] = Field(min_length=1)
    payment_method: str = Field(pattern="^(cash|card|mixed|debt)$")
    subtotal: float = Field(ge=0)
    discount_total: float = Field(default=0, ge=0)
    total: float = Field(ge=0)
    cash_received: float = Field(default=0, ge=0)
    card_amount: float = Field(default=0, ge=0)
    change_amount: float = Field(default=0, ge=0)
    client_name: str = ""
    client_phone: str = ""
    note: str = ""


class SaleItemOut(BaseModel):
    id: int
    product_id: int | None
    name: str
    is_weight: bool
    is_service: bool
    quantity: float
    unit_price: float
    discount: float
    line_total: float


class SaleOut(BaseModel):
    id: int
    doc_number: int
    status: str
    payment_method: str
    subtotal: float
    discount_total: float
    total: float
    cash_received: float
    card_amount: float
    change_amount: float
    debt_balance: float
    client_name: str
    client_phone: str
    cashier_name: str
    shift_id: int | None
    created_at: str
    paid_at: str | None
    items: list[SaleItemOut] = []


class DebtPayRequest(BaseModel):
    amount: float = Field(gt=0)
    payment_method: str = Field(default="cash", pattern="^(cash|card)$")
    cash_received: float = Field(default=0, ge=0)


class RefundItemIn(BaseModel):
    sale_item_id: int
    quantity: float = Field(gt=0)


class RefundRequest(BaseModel):
    items: list[RefundItemIn] = Field(min_length=1)
    note: str = ""


def _sale_out(sale: Sale) -> SaleOut:
    return SaleOut(
        id=sale.id,
        doc_number=sale.doc_number,
        status=sale.status,
        payment_method=sale.payment_method,
        subtotal=sale.subtotal,
        discount_total=sale.discount_total,
        total=sale.total,
        cash_received=sale.cash_received,
        card_amount=sale.card_amount,
        change_amount=sale.change_amount,
        debt_balance=sale.debt_balance,
        client_name=sale.client_name,
        client_phone=sale.client_phone,
        cashier_name=sale.cashier_name,
        shift_id=sale.shift_id,
        created_at=sale.created_at.isoformat() if sale.created_at else "",
        paid_at=sale.paid_at.isoformat() if sale.paid_at else None,
        items=[
            SaleItemOut(
                id=i.id,
                product_id=i.product_id,
                name=i.name,
                is_weight=i.is_weight,
                is_service=i.is_service,
                quantity=i.quantity,
                unit_price=i.unit_price,
                discount=i.discount,
                line_total=i.line_total,
            )
            for i in (sale.items or [])
        ],
    )


async def _next_doc_number(session: AsyncSession) -> int:
    counter = (await session.execute(select(SaleCounter).where(SaleCounter.id == 1))).scalar_one_or_none()
    if counter is None:
        counter = SaleCounter(id=1, last_number=0)
        session.add(counter)
        await session.flush()
    counter.last_number += 1
    return counter.last_number


async def _open_shift(session: AsyncSession, user: User) -> Shift | None:
    return (
        await session.execute(
            select(Shift).where(Shift.status == "open", Shift.user_id == user.id).order_by(Shift.id.desc())
        )
    ).scalar_one_or_none()


@router.post("/sales", response_model=SaleOut, status_code=status.HTTP_201_CREATED)
async def create_sale(
    payload: SaleCreateRequest,
    session: AsyncSession = Depends(get_db_session),
    user: User = Depends(get_current_user),
) -> SaleOut:
    shift = await _open_shift(session, user)
    if shift is None:
        # auto-open a shift for convenience in offline mode
        shift = Shift(user_id=user.id, open_cash=0, status="open", cashbox_name="Основная")
        session.add(shift)
        await session.flush()

    now = datetime.now(UTC)
    is_debt = payload.payment_method == "debt"
    sale = Sale(
        doc_number=await _next_doc_number(session),
        status="debt" if is_debt else "paid",
        payment_method=payload.payment_method,
        subtotal=payload.subtotal,
        discount_total=payload.discount_total,
        total=payload.total,
        cash_received=payload.cash_received,
        card_amount=payload.card_amount,
        change_amount=payload.change_amount,
        debt_balance=payload.total if is_debt else 0,
        client_name=payload.client_name.strip(),
        client_phone=payload.client_phone.strip(),
        shift_id=shift.id,
        user_id=user.id,
        cashier_name=user.full_name or user.username,
        created_at=now,
        paid_at=None if is_debt else now,
        note=payload.note,
    )
    session.add(sale)
    await session.flush()

    for line in payload.items:
        cost = 0.0
        if line.product_id and not line.is_service:
            product = (
                await session.execute(select(Product).where(Product.id == line.product_id))
            ).scalar_one_or_none()
            if product:
                cost = float(product.cost_price)
                if product.kind != "service":
                    product.stock_qty = float(product.stock_qty) - float(line.quantity)
                    session.add(
                        StockMove(
                            product_id=product.id,
                            qty_delta=-float(line.quantity),
                            reason="sale",
                            ref_type="sale",
                            ref_id=str(sale.id),
                            user_id=user.id,
                        )
                    )
        session.add(
            SaleItem(
                sale_id=sale.id,
                product_id=line.product_id,
                name=line.name,
                is_weight=line.is_weight,
                is_service=line.is_service,
                quantity=line.quantity,
                unit_price=line.unit_price,
                discount=line.discount,
                line_total=line.line_total,
                cost_price=cost,
            )
        )

    shift.sales_count += 1
    shift.sales_total = float(shift.sales_total) + float(payload.total)
    await session.commit()

    result = (
        await session.execute(
            select(Sale).options(selectinload(Sale.items)).where(Sale.id == sale.id)
        )
    ).scalar_one()
    return _sale_out(result)


@router.get("/sales", response_model=list[SaleOut])
async def list_sales(
    status_filter: str | None = Query(default=None, alias="status"),
    limit: int = Query(default=100, le=500),
    date_from: str | None = None,
    date_to: str | None = None,
    session: AsyncSession = Depends(get_db_session),
    _: User = Depends(get_current_user),
) -> list[SaleOut]:
    stmt = select(Sale).options(selectinload(Sale.items)).order_by(Sale.id.desc()).limit(limit)
    if status_filter:
        stmt = stmt.where(Sale.status == status_filter)
    if date_from:
        try:
            dt = datetime.fromisoformat(date_from)
            stmt = stmt.where(Sale.created_at >= dt)
        except ValueError:
            pass
    if date_to:
        try:
            dt = datetime.fromisoformat(date_to)
            stmt = stmt.where(Sale.created_at <= dt)
        except ValueError:
            pass
    rows = (await session.execute(stmt)).scalars().all()
    return [_sale_out(s) for s in rows]


@router.get("/sales/{sale_id}", response_model=SaleOut)
async def get_sale(
    sale_id: int,
    session: AsyncSession = Depends(get_db_session),
    _: User = Depends(get_current_user),
) -> SaleOut:
    sale = (
        await session.execute(
            select(Sale).options(selectinload(Sale.items)).where(Sale.id == sale_id)
        )
    ).scalar_one_or_none()
    if not sale:
        raise HTTPException(status_code=404, detail="Чек не найден.")
    return _sale_out(sale)


@router.get("/debts", response_model=list[SaleOut])
async def list_debts(
    session: AsyncSession = Depends(get_db_session),
    _: User = Depends(get_current_user),
) -> list[SaleOut]:
    rows = (
        await session.execute(
            select(Sale)
            .options(selectinload(Sale.items))
            .where(Sale.status == "debt", Sale.debt_balance > 0)
            .order_by(Sale.created_at.desc())
        )
    ).scalars().all()
    return [_sale_out(s) for s in rows]


@router.post("/sales/{sale_id}/pay-debt", response_model=SaleOut)
async def pay_debt(
    sale_id: int,
    payload: DebtPayRequest,
    session: AsyncSession = Depends(get_db_session),
    user: User = Depends(get_current_user),
) -> SaleOut:
    sale = (
        await session.execute(
            select(Sale).options(selectinload(Sale.items)).where(Sale.id == sale_id)
        )
    ).scalar_one_or_none()
    if not sale or sale.status != "debt":
        raise HTTPException(status_code=404, detail="Долг не найден.")
    amount = round(float(payload.amount), 2)
    if amount > float(sale.debt_balance) + 0.01:
        raise HTTPException(status_code=400, detail="Сумма больше остатка долга.")
    change = 0.0
    cash_received = float(payload.cash_received or 0)
    if payload.payment_method == "cash":
        if cash_received < amount:
            cash_received = amount
        change = round(cash_received - amount, 2)

    session.add(
        DebtPayment(
            sale_id=sale.id,
            amount=amount,
            payment_method=payload.payment_method,
            cash_received=cash_received,
            change_amount=change,
            user_id=user.id,
        )
    )
    sale.debt_balance = round(float(sale.debt_balance) - amount, 2)
    if sale.debt_balance <= 0.01:
        sale.debt_balance = 0
        sale.status = "paid"
        sale.paid_at = datetime.now(UTC)
    await session.commit()
    await session.refresh(sale)
    return _sale_out(sale)


@router.post("/sales/{sale_id}/refund", response_model=SaleOut)
async def refund_sale(
    sale_id: int,
    payload: RefundRequest,
    session: AsyncSession = Depends(get_db_session),
    user: User = Depends(get_current_user),
) -> SaleOut:
    sale = (
        await session.execute(
            select(Sale).options(selectinload(Sale.items)).where(Sale.id == sale_id)
        )
    ).scalar_one_or_none()
    if not sale:
        raise HTTPException(status_code=404, detail="Чек не найден.")
    if sale.status in ("canceled",):
        raise HTTPException(status_code=400, detail="Чек уже отменён.")

    item_map = {i.id: i for i in sale.items}
    refunded_total = 0.0
    for entry in payload.items:
        item = item_map.get(entry.sale_item_id)
        if not item:
            raise HTTPException(status_code=400, detail=f"Позиция {entry.sale_item_id} не найдена.")
        qty = min(float(entry.quantity), float(item.quantity))
        if qty <= 0:
            continue
        unit_net = float(item.line_total) / float(item.quantity) if item.quantity else 0
        refunded_total += unit_net * qty
        item.quantity = float(item.quantity) - qty
        item.line_total = round(float(item.line_total) - unit_net * qty, 2)
        if item.product_id and not item.is_service:
            product = (
                await session.execute(select(Product).where(Product.id == item.product_id))
            ).scalar_one_or_none()
            if product and product.kind != "service":
                product.stock_qty = float(product.stock_qty) + qty
                session.add(
                    StockMove(
                        product_id=product.id,
                        qty_delta=qty,
                        reason="return",
                        ref_type="sale",
                        ref_id=str(sale.id),
                        note=payload.note,
                        user_id=user.id,
                    )
                )

    remaining_lines = [i for i in sale.items if i.quantity > 1e-9]
    if not remaining_lines:
        sale.status = "refunded"
        sale.total = 0
    else:
        sale.status = "partial_refund"
        sale.total = round(max(0.0, float(sale.total) - refunded_total), 2)
    sale.note = (sale.note + " | " + payload.note).strip(" |")
    await session.commit()
    await session.refresh(sale)
    return _sale_out(sale)
