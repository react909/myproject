import { useCallback, useId, useRef, useState, type FormEvent, type KeyboardEvent } from 'react'
import {
  panelDemoProductsStorageKey,
  readPanelDemoProducts,
  type StoredPanelProduct,
} from '../catalog/panelProductsStorage'
import { normalizeBarcode } from '../catalog/barcodeLookup'
import { generateEan13Barcode, parseExtraBarcodes } from '../catalog/barcodeGen'
import { createProduct, extractApiError } from '../services/products'
import './PanelAddProductPage.css'

export type DemoPanelProduct = StoredPanelProduct

const HOTKEYS = ['F1', 'F2', 'F3', 'F4', 'F5', 'F6', 'F7', 'F8', 'F9', 'F10', 'F11', 'F12'] as const

function genId() {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) {
    return crypto.randomUUID()
  }
  return `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`
}

function loadStored(): DemoPanelProduct[] {
  return readPanelDemoProducts()
}

type StatusKind = 'ok' | 'warn' | 'err' | ''

export function PanelAddProductPage() {
  const formId = useId()
  const [items, setItems] = useState<DemoPanelProduct[]>(loadStored)
  const [name, setName] = useState('')
  const [price, setPrice] = useState('')
  const [wholesalePrice, setWholesalePrice] = useState('')
  const [purchasePrice, setPurchasePrice] = useState('')
  const [barcode, setBarcode] = useState('')
  const [extraBarcodesRaw, setExtraBarcodesRaw] = useState('')
  const [category, setCategory] = useState('')
  const [brand, setBrand] = useState('')
  const [minimumQuantity, setMinimumQuantity] = useState('')
  const [expiryDate, setExpiryDate] = useState('')
  const [hotkey, setHotkey] = useState('')
  const [kind, setKind] = useState<'piece' | 'weight'>('piece')
  const [productKind, setProductKind] = useState<'product' | 'service'>('product')
  const [preview, setPreview] = useState<string | undefined>()
  const [busy, setBusy] = useState(false)
  const [status, setStatus] = useState('')
  const [statusKind, setStatusKind] = useState<StatusKind>('')
  const barcodeScanRef = useRef('')
  const barcodeLastKeyAt = useRef(0)

  const persist = useCallback((next: DemoPanelProduct[]) => {
    setItems(next)
    try {
      localStorage.setItem(panelDemoProductsStorageKey(), JSON.stringify(next))
    } catch {
      /* ignore */
    }
    window.dispatchEvent(new Event('nurcrm-panel-products'))
  }, [])

  const onPickImage = (fileList: FileList | null) => {
    const file = fileList?.[0]
    if (!file || !file.type.startsWith('image/')) return
    setBusy(true)
    const reader = new FileReader()
    reader.onloadend = () => {
      const r = reader.result
      setPreview(typeof r === 'string' ? r : undefined)
      setBusy(false)
    }
    reader.onerror = () => setBusy(false)
    reader.readAsDataURL(file)
  }

  const handleBarcodeKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault()
      e.stopPropagation()
      const code = normalizeBarcode(barcodeScanRef.current || barcode)
      if (code) setBarcode(code)
      barcodeScanRef.current = ''
      barcodeLastKeyAt.current = 0
      return
    }
    if (e.key.length === 1) {
      const now = Date.now()
      if (now - barcodeLastKeyAt.current > 80) barcodeScanRef.current = ''
      barcodeScanRef.current += e.key
      barcodeLastKeyAt.current = now
    }
  }

  const resetForm = () => {
    setName('')
    setPrice('')
    setWholesalePrice('')
    setPurchasePrice('')
    setBarcode('')
    setExtraBarcodesRaw('')
    setCategory('')
    setBrand('')
    setMinimumQuantity('')
    setExpiryDate('')
    setHotkey('')
    setKind('piece')
    setProductKind('product')
    setPreview(undefined)
    barcodeScanRef.current = ''
  }

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault()
    const trimmed = name.trim()
    const normalizedBarcode = normalizeBarcode(barcode)
    const n = Number.parseFloat(price.replace(',', '.'))
    const purchase = Number.parseFloat(purchasePrice.replace(',', '.'))
    const wholesale = Number.parseFloat(wholesalePrice.replace(',', '.'))
    const minQty = Number.parseFloat(minimumQuantity.replace(',', '.'))
    if (!trimmed) {
      setStatusKind('err')
      setStatus('Укажите название товара.')
      return
    }
    if (!Number.isFinite(n) || n < 0) {
      setStatusKind('err')
      setStatus('Укажите корректную цену продажи.')
      return
    }

    const extraBarcodes = parseExtraBarcodes(extraBarcodesRaw)

    const next: DemoPanelProduct = {
      id: genId(),
      name: trimmed,
      priceRub: Math.round(n * 100) / 100,
      wholesalePriceRub:
        Number.isFinite(wholesale) && wholesale >= 0 ? Math.round(wholesale * 100) / 100 : undefined,
      purchasePriceRub: Number.isFinite(purchase) && purchase >= 0 ? Math.round(purchase * 100) / 100 : undefined,
      kind: productKind === 'service' ? 'piece' : kind,
      productKind,
      barcode: normalizedBarcode || undefined,
      extraBarcodes: extraBarcodes.length > 0 ? extraBarcodes : undefined,
      category: category.trim() || undefined,
      brand: brand.trim() || undefined,
      minimumQuantity: Number.isFinite(minQty) && minQty >= 0 ? minQty : undefined,
      expiryDate: expiryDate || undefined,
      hotkeyGroup: hotkey || undefined,
      imageDataUrl: preview,
      createdAt: new Date().toISOString(),
    }

    setBusy(true)
    setStatus('')
    setStatusKind('')
    try {
      await createProduct({
        kind: productKind,
        name: next.name,
        barcode: next.barcode,
        code: extraBarcodes[0],
        article: extraBarcodes.length > 1 ? extraBarcodes.slice(1).join(', ') : undefined,
        price: String(next.priceRub),
        wholesale_price: next.wholesalePriceRub != null ? String(next.wholesalePriceRub) : undefined,
        purchase_price: next.purchasePriceRub != null ? String(next.purchasePriceRub) : undefined,
        minimum_quantity: next.minimumQuantity != null ? String(next.minimumQuantity) : undefined,
        is_weight: productKind === 'service' ? false : next.kind === 'weight',
        category_name: next.category,
        brand_name: next.brand,
        expiration_date: next.expiryDate,
        hotkey_group: next.hotkeyGroup ?? undefined,
      })
      persist([...items, next])
      setStatusKind('ok')
      setStatus(productKind === 'service' ? 'Услуга сохранена в CRM.' : 'Товар сохранён в CRM.')
      resetForm()
    } catch (err: any) {
      persist([...items, next])
      setStatusKind('warn')
      setStatus(`CRM отклонила товар (сохранён локально): ${extractApiError(err)}`)
      resetForm()
    } finally {
      setBusy(false)
    }
  }

  const remove = (id: string) => {
    persist(items.filter((x) => x.id !== id))
  }

  return (
    <div className="pap">
      <header className="pap__hero">
        <h2 className="pap__title">Добавить товар / услугу</h2>
        <p className="pap__sub">Заполните карточку — позиция уходит в CRM и в каталог кассы.</p>
      </header>

      <form
        className="pap__form"
        onSubmit={handleSubmit}
        onKeyDown={(e) => {
          if (e.key === 'Enter' && (e.target as HTMLElement).tagName !== 'BUTTON' && (e.target as HTMLElement).tagName !== 'TEXTAREA') {
            e.preventDefault()
          }
        }}
        aria-labelledby={`${formId}-heading`}
      >
        <span id={`${formId}-heading`} className="pap__sr-only">
          Форма нового товара
        </span>

        <section className="pap__section">
          <h3 className="pap__section-title">Основное</h3>
          <div className="pap__grid">
            <label className="pap__label pap__label--wide">
              Название*
              <input
                className="pap__input"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Например, Cola 0.5"
                maxLength={120}
                required
              />
            </label>

            <label className="pap__label">
              Штрихкод
              <div className="pap__barcode-row">
                <input
                  className="pap__input"
                  data-barcode-field="1"
                  inputMode="numeric"
                  value={barcode}
                  onChange={(e) => {
                    setBarcode(e.target.value)
                    barcodeScanRef.current = ''
                  }}
                  onKeyDown={handleBarcodeKeyDown}
                  placeholder="Сканер или вручную"
                  maxLength={64}
                />
                <button
                  type="button"
                  className="pap__gen-barcode"
                  onClick={() => setBarcode(generateEan13Barcode())}
                >
                  Сгенерировать
                </button>
              </div>
            </label>

            <label className="pap__label pap__label--wide">
              Доп. штрихкоды
              <textarea
                className="pap__input pap__textarea"
                value={extraBarcodesRaw}
                onChange={(e) => setExtraBarcodesRaw(e.target.value)}
                placeholder="По одному в строке или через запятую"
                rows={2}
              />
            </label>

            <label className="pap__label">
              Горячая клавиша
              <select className="pap__input" value={hotkey} onChange={(e) => setHotkey(e.target.value)}>
                <option value="">— не задана —</option>
                {HOTKEYS.map((k) => (
                  <option key={k} value={k}>
                    {k}
                  </option>
                ))}
              </select>
            </label>

            <div className="pap__label pap__label--wide">
              Тип позиции
              <div className="pap__segment" role="radiogroup" aria-label="Тип позиции">
                <button
                  type="button"
                  className={`pap__seg-btn ${productKind === 'product' ? 'is-active' : ''}`}
                  aria-pressed={productKind === 'product'}
                  onClick={() => setProductKind('product')}
                >
                  Товар
                </button>
                <button
                  type="button"
                  className={`pap__seg-btn ${productKind === 'service' ? 'is-active' : ''}`}
                  aria-pressed={productKind === 'service'}
                  onClick={() => setProductKind('service')}
                >
                  Услуга
                </button>
              </div>
            </div>

            {productKind === 'product' && (
            <div className="pap__label pap__label--wide">
              Единица учёта
              <div className="pap__segment" role="radiogroup" aria-label="Единица учёта">
                <button
                  type="button"
                  className={`pap__seg-btn ${kind === 'piece' ? 'is-active' : ''}`}
                  aria-pressed={kind === 'piece'}
                  onClick={() => setKind('piece')}
                >
                  Штучный
                </button>
                <button
                  type="button"
                  className={`pap__seg-btn ${kind === 'weight' ? 'is-active' : ''}`}
                  aria-pressed={kind === 'weight'}
                  onClick={() => setKind('weight')}
                >
                  Весовой (кг)
                </button>
              </div>
            </div>
            )}
          </div>
        </section>

        <section className="pap__section">
          <h3 className="pap__section-title">Цены и остаток</h3>
          <div className="pap__grid">
            <label className="pap__label">
              Цена продажи, сом*
              <input
                className="pap__input"
                inputMode="decimal"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                placeholder="0"
                required
              />
            </label>

            <label className="pap__label">
              Закупка, сом
              <input
                className="pap__input"
                inputMode="decimal"
                value={purchasePrice}
                onChange={(e) => setPurchasePrice(e.target.value)}
                placeholder="0"
              />
            </label>

            <label className="pap__label">
              Оптовая цена, сом
              <input
                className="pap__input"
                inputMode="decimal"
                value={wholesalePrice}
                onChange={(e) => setWholesalePrice(e.target.value)}
                placeholder="0"
              />
            </label>

            {productKind === 'product' && (
            <label className="pap__label">
              Мин. остаток, {kind === 'weight' ? 'кг' : 'шт'}
              <input
                className="pap__input"
                inputMode="decimal"
                value={minimumQuantity}
                onChange={(e) => setMinimumQuantity(e.target.value)}
                placeholder="0"
              />
            </label>
            )}

            {productKind === 'product' && (
            <label className="pap__label">
              Срок годности
              <input className="pap__input" type="date" value={expiryDate} onChange={(e) => setExpiryDate(e.target.value)} />
            </label>
            )}
          </div>
        </section>

        <section className="pap__section">
          <h3 className="pap__section-title">Классификация</h3>
          <div className="pap__grid">
            <label className="pap__label">
              Категория
              <input className="pap__input" value={category} onChange={(e) => setCategory(e.target.value)} placeholder="Напитки" />
            </label>
            <label className="pap__label">
              Бренд
              <input className="pap__input" value={brand} onChange={(e) => setBrand(e.target.value)} placeholder="Brand" />
            </label>
          </div>
        </section>

        <section className="pap__section">
          <h3 className="pap__section-title">Фото</h3>
          <div className="pap__photo-row">
            {preview ? (
              <div className="pap__preview-wrap">
                <img src={preview} alt="" className="pap__preview" />
                <button type="button" className="pap__linkish" onClick={() => setPreview(undefined)}>
                  Убрать фото
                </button>
              </div>
            ) : (
              <label className="pap__dropzone">
                <span className="pap__dropzone-ic">+</span>
                <span>Загрузить изображение</span>
                <input
                  type="file"
                  accept="image/*"
                  className="pap__file-hidden"
                  onChange={(ev) => onPickImage(ev.target.files)}
                  disabled={busy}
                />
              </label>
            )}
          </div>
        </section>

        <div className="pap__actions">
          <button type="submit" className="pap__submit" disabled={busy}>
            {busy ? 'Сохраняем…' : 'Сохранить товар'}
          </button>
          {status && <p className={`pap__status pap__status--${statusKind || 'info'}`}>{status}</p>}
        </div>
      </form>

      <section className="pap__list-section" aria-labelledby={`${formId}-list`}>
        <h3 id={`${formId}-list`} className="pap__list-title">
          Добавлено локально ({items.length})
        </h3>
        {items.length === 0 ? (
          <p className="pap__empty">Пока пусто — добавьте первый товар.</p>
        ) : (
          <ul className="pap__list">
            {items
              .slice()
              .reverse()
              .map((p) => (
                <li key={p.id} className="pap__row">
                  <div className="pap__thumb">
                    {p.imageDataUrl ? (
                      <img src={p.imageDataUrl} alt="" />
                    ) : (
                      <span className="pap__thumb-ph">Нет фото</span>
                    )}
                  </div>
                  <div className="pap__row-body">
                    <span className="pap__row-name">{p.name}</span>
                    <span className="pap__row-meta">
                      продажа {p.priceRub.toLocaleString('ru-RU')} сом
                      {(p.wholesalePriceRub ?? 0) > 0 ? ` · опт ${p.wholesalePriceRub!.toLocaleString('ru-RU')} сом` : ''}
                      {' · '}
                      закупка {(p.purchasePriceRub ?? 0).toLocaleString('ru-RU')} сом · {p.productKind === 'service' ? 'услуга' : p.kind === 'weight' ? 'вес' : 'шт.'}
                    </span>
                    {(p.category || p.brand) && <span className="pap__row-meta">{[p.category, p.brand].filter(Boolean).join(' · ')}</span>}
                    {(p.barcode || p.hotkeyGroup) && (
                      <span className="pap__row-meta">
                        {[p.barcode ? `ШК: ${p.barcode}` : null, p.hotkeyGroup ? `клавиша ${p.hotkeyGroup}` : null]
                          .filter(Boolean)
                          .join(' · ')}
                      </span>
                    )}
                  </div>
                  <button type="button" className="pap__remove" onClick={() => remove(p.id)}>
                    Удалить
                  </button>
                </li>
              ))}
          </ul>
        )}
      </section>
    </div>
  )
}
