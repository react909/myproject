import './PanelFetchOverlay.css'

type PanelFetchOverlayProps = {
  label?: string
}

export function PanelFetchOverlay({ label = 'Обновление данных…' }: PanelFetchOverlayProps) {
  return (
    <div className="panel-fetch-overlay" aria-live="polite" aria-busy="true">
      <span className="panel-fetch-overlay__spinner" aria-hidden />
      <span>{label}</span>
    </div>
  )
}
