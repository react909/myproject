import { useEffect, useState } from 'react'

/** Ровная секундная метка для часов в шапке */
export function useClock() {
  const [now, setNow] = useState(() => new Date())
  useEffect(() => {
    setNow(new Date())
    const alignMs = 1000 - (Date.now() % 1000)
    let tick: ReturnType<typeof setInterval> | undefined
    const first = window.setTimeout(() => {
      setNow(new Date())
      tick = setInterval(() => setNow(new Date()), 1000)
    }, alignMs)
    return () => {
      clearTimeout(first)
      if (tick !== undefined) clearInterval(tick)
    }
  }, [])
  return now
}
