import type { AppSettings } from '../settings/appSettings'
import type { ReceiptPrintPayload } from '../receipt/receiptTemplate'

export type DeviceStatusSnapshot = {
  printer: {
    connected: boolean
    lastError: string | null
    lastTestAt: string | null
    lastResponse?: string | null
    activeStrategyId?: string | null
  }
  scale: {
    connected: boolean
    lastError: string | null
    lastWeightKg: number | null
    lastTestAt: string | null
    lastResponse?: string | null
  }
  scanner: {
    connected: boolean
    lastError: string | null
    lastBarcode?: string | null
    lastScanAt?: string | null
    lastResponse?: string | null
  }
  keyboard?: {
    connected: boolean
    lastError: string | null
    lastResponse?: string | null
  }
  cashDrawer: { connected: boolean; lastError: string | null }
  settingsLoaded?: boolean
}

declare global {
  interface Window {
    nurcrm?: {
      platform: string
      getMeta: () => Promise<{
        version: string
        isPackaged: boolean
        platform: string
        state: Record<string, unknown>
      }>
      markReady: () => Promise<unknown>
    }
    electronAPI?: {
      minimize?: () => void
      close?: () => void
      getFullscreen?: () => Promise<boolean>
      setFullscreen?: (v: boolean) => Promise<void>
      toggleFullscreen?: () => Promise<boolean>
      onFullscreenChange?: (cb: (v: boolean) => void) => () => void
    }
    updaterAPI?: {
      getInfo: () => Promise<{ currentVersion: string; changelog: Record<string, unknown> }>
      check: (feedUrl?: string) => Promise<unknown>
      download: () => Promise<unknown>
      install: () => Promise<unknown>
      getChangelog: (version: string) => Promise<unknown>
      onStatus: (cb: (payload: import('../services/updater/updater.client').UpdaterStatusPayload) => void) => () => void
      onProgress: (cb: (payload: import('../services/updater/updater.client').UpdaterProgressPayload) => void) => () => void
    }
    devicesAPI?: {
      applySettings: (settings: AppSettings) => Promise<{ ok: boolean }>
      getStatus: () => Promise<DeviceStatusSnapshot>
      testPrinter: (settings: AppSettings) => Promise<{
        ok: boolean
        message: string
        savedStrategyId?: string
        tried?: Array<{ id: string; label: string; ok: boolean }>
      }>
      reconnect?: (settings: AppSettings) => Promise<DeviceStatusSnapshot>
      testScale: (settings: AppSettings) => Promise<{ ok: boolean; message: string }>
      runDiagnostics: (settings: AppSettings) => Promise<unknown>
      printReceipt: (payload: ReceiptPrintPayload, settings: AppSettings) => Promise<{ ok: boolean; message?: string }>
      listPorts: () => Promise<Array<{ path: string; manufacturer?: string }>>
      getLiveWeight: () => Promise<{
        kg: number | null
        connected: boolean
        stable: boolean
        error?: string | null
      }>
      requestScaleRead?: () => Promise<{
        kg: number | null
        connected: boolean
        stable: boolean
        error?: string | null
      }>
      setScaleWeightKg: (kg: number) => Promise<{
        kg: number | null
        connected: boolean
        stable: boolean
        error?: string | null
      }>
      reportBarcodeScan?: (code: string) => Promise<DeviceStatusSnapshot>
      onScaleWeight?: (
        cb: (payload: {
          kg: number | null
          connected: boolean
          stable: boolean
          error?: string | null
        }) => void,
      ) => () => void
    }
    logsAPI?: {
      read: (channel?: string, limit?: number) => Promise<unknown[]>
    }
    systemAPI?: {
      setAutoLaunch: (enabled: boolean) => Promise<{ ok: boolean; message?: string }>
      openTouchKeyboard: () => Promise<{ ok: boolean }>
      applyKiosk: (enabled: boolean) => Promise<{ ok: boolean }>
    }
  }
}

export {}
