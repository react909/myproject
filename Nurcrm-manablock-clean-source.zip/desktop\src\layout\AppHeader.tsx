import logoImage from '../assets/images.png'
import { useClock } from '../hooks/useClock'
import { useNotifications } from '../components/notifications/NotificationProvider'

function IcoPanel() {
  return (
    <svg viewBox="0 0 24 24" fill="none" aria-hidden>
      <path
        d="M4 4h7v7H4V4zM13 4h7v7h-7V4zM4 13h7v7H4v-7zM13 13h7v7h-7v-7z"
        stroke="currentColor"
        strokeWidth="1.55"
        strokeLinejoin="round"
      />
    </svg>
  )
}

function IcoBell() {
  return (
    <svg viewBox="0 0 24 24" fill="none" aria-hidden>
      <path
        d="M12 3a5 5 0 0 0-5 5v2.5c0 .9-.3 1.8-.9 2.5L5 15.5h14l-1.1-2.5c-.6-.7-.9-1.6-.9-2.5V8a5 5 0 0 0-5-5Z"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      <path d="M10 18a2 2 0 0 0 4 0" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
    </svg>
  )
}

function IcoSettings() {
  return (
    <svg viewBox="0 0 24 24" fill="none" aria-hidden>
      <path
        d="M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z"
        stroke="currentColor"
        strokeWidth="1.7"
        strokeLinejoin="round"
      />
      <path
        d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9c.26.604.852 1.003 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"
        stroke="currentColor"
        strokeWidth="1.25"
        strokeLinejoin="round"
      />
    </svg>
  )
}

function IcoLogout() {
  return (
    <svg viewBox="0 0 24 24" fill="none" aria-hidden>
      <path
        d="M10 17H6a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2h4"
        stroke="currentColor"
        strokeWidth="1.7"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M15 12H3M20 12l-4-4M20 12l-4 4"
        stroke="currentColor"
        strokeWidth="1.7"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

function IcoMinimize() {
  return (
    <svg viewBox="0 0 24 24" fill="none" aria-hidden>
      <path d="M4 12h16" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
    </svg>
  )
}

function IcoExpand() {
  return (
    <svg viewBox="0 0 24 24" fill="none" aria-hidden>
      <path
        d="M2 2h6M2 2v6M22 2h-6M22 2v6M2 22h6M2 22v-6M22 22h-6M22 22v-6"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

function IcoExitFullscreen() {
  return (
    <svg viewBox="0 0 24 24" fill="none" aria-hidden>
      <path
        d="M4.5 4.5L12 12M19.5 4.5L12 12M4.5 19.5L12 12M19.5 19.5L12 12"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

function IcoClose() {
  return (
    <svg viewBox="0 0 24 24" fill="none" aria-hidden>
      <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
    </svg>
  )
}

function IcoReceipts() {
  return (
    <svg viewBox="0 0 24 24" fill="none" aria-hidden>
      <path
        d="M4 2h16v22l-3-2-2 2-2-2-2 2-2-2-3 2V2z"
        stroke="currentColor"
        strokeWidth="1.55"
        strokeLinejoin="round"
      />
      <path d="M8 8h8M8 12h8M8 16h5" stroke="currentColor" strokeWidth="1.55" strokeLinecap="round" />
    </svg>
  )
}

export type AppHeaderProps = {
  username: string
  salesCount: number
  shiftOpen?: boolean
  shiftRevenue?: number
  /** Живой вес с весов для блока «Общий вес в чеке» (кг), null — «—» */
  scaleDisplayKg?: number | null
  /** Вес устоялся ~3 с — можно нажать «Зафиксировать» */
  scaleWeightStable?: boolean
  totalRub: number
  isFullscreen: boolean
  onToggleFullscreen: () => void
  onMinimize: () => void
  /** Центр управления: финансы / аналитика / чеки — одна точка входа */
  onOpenPanel: () => void
  /** Журнал чеков в панели */
  onOpenReceiptsJournal?: () => void
  onOpenSettings: () => void
  onLogout: () => void
  onCloseApp: () => void
  scaleEnabled: boolean
  onFixScaleWeight: () => void
}

function formatKg(kg: number): string {
  return (kg >= 0 ? kg : 0).toFixed(3).replace('.', ',')
}

export function AppHeader({
  username,
  salesCount,
  shiftOpen = false,
  shiftRevenue = 0,
  scaleDisplayKg = null,
  scaleWeightStable = false,
  totalRub,
  isFullscreen,
  onToggleFullscreen,
  onMinimize,
  onOpenPanel,
  onOpenReceiptsJournal,
  onOpenSettings,
  onLogout,
  onCloseApp,
  scaleEnabled,
  onFixScaleWeight,
}: AppHeaderProps) {
  const { unreadCount, toggleCenter } = useNotifications()
  const now = useClock()
  const hh = String(now.getHours()).padStart(2, '0')
  const mm = String(now.getMinutes()).padStart(2, '0')
  const ss = String(now.getSeconds()).padStart(2, '0')
  const scaleKgStr =
    scaleDisplayKg != null && Number.isFinite(scaleDisplayKg) && scaleDisplayKg > 0
      ? formatKg(scaleDisplayKg)
      : '—'
  const rubStr = totalRub.toLocaleString('ru-RU', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
  const canFix =
    scaleEnabled &&
    scaleWeightStable &&
    scaleDisplayKg != null &&
    scaleDisplayKg > 0

  return (
    <header className="app-header">
      <div className="app-header__left">
        <div className="app-header__brand">
          <img className="app-header__logo" src={logoImage} alt="NurCRM" />
          <div className="app-header__brand-text">
            <span className="app-header__system">NurCRM POS</span>
            <time className="app-header__clock-mono" dateTime={now.toISOString()} aria-live="polite" aria-atomic="true">
              {hh}:{mm}:{ss}
            </time>
          </div>
        </div>
      </div>

      <div
        className="app-header__showcase"
        aria-live="polite"
        aria-label={`Вес на весах ${scaleKgStr} кг, к оплате ${rubStr} рублей`}
      >
        {scaleEnabled && (
          <div
            className={`app-header__showcase-tile app-header__showcase-tile--weight${scaleWeightStable ? ' app-header__showcase-tile--stable' : ''}`}
          >
            <span className="app-header__showcase-label">Вес на весах, кг</span>
            <div className="app-header__weight-stack">
              <span
                className={`app-header__showcase-value app-header__showcase-value--kg${scaleKgStr === '—' ? ' app-header__showcase-value--empty' : ''}${scaleDisplayKg != null ? ' app-header__showcase-value--live-on' : ''}`}
              >
                {scaleKgStr}
              </span>
              <button
                type="button"
                className={`app-header__fix-weight${canFix ? ' app-header__fix-weight--ready' : ''}`}
                disabled={!canFix}
                onClick={onFixScaleWeight}
                title={
                  canFix
                    ? 'Зафиксировать устойчивый вес и добавить в чек'
                    : scaleDisplayKg != null && scaleDisplayKg > 0
                      ? 'Подождите, пока вес перестанет меняться (~3 сек)'
                      : 'Положите товар на весы'
                }
              >
                Зафиксировать
              </button>
            </div>
          </div>
        )}

        <div className="app-header__showcase-tile app-header__showcase-tile--pay">
          <span className="app-header__showcase-label">К оплате</span>
          <span className="app-header__showcase-value app-header__showcase-value--rub">{rubStr} сом</span>
        </div>
      </div>

      <div className="app-header__right">
        <div className="cashier-chip" aria-label={`Кассир: ${username}`}>
          <div className="cashier-chip__avatar">{username.charAt(0).toUpperCase()}</div>
          <div className="cashier-chip__info">
            <span className="cashier-chip__name">{username}</span>
            <span className="cashier-chip__sub">
              {shiftOpen
                ? `${salesCount} транзакций · ${shiftRevenue.toLocaleString('ru-RU', { maximumFractionDigits: 0 })} сом`
                : 'Смена закрыта'}
            </span>
          </div>
        </div>

        <div className="header-sep" aria-hidden="true" />

        <div className="header-tray">
          <div className="header-btns">
            <button type="button" className="header-btn header-btn--panel" onClick={onOpenPanel} title="Панель управления" aria-label="Панель управления">
              <IcoPanel />
            </button>

            {onOpenReceiptsJournal && (
              <button
                type="button"
                className="header-btn"
                onClick={onOpenReceiptsJournal}
                title="Журнал чеков"
                aria-label="Журнал чеков"
              >
                <IcoReceipts />
              </button>
            )}

            <button
              type="button"
              className="header-btn header-btn--notify"
              onClick={toggleCenter}
              title="Уведомления"
              aria-label={`Уведомления${unreadCount ? `, непрочитано ${unreadCount}` : ''}`}
            >
              <IcoBell />
              {unreadCount > 0 ? <span className="header-btn__badge">{unreadCount > 9 ? '9+' : unreadCount}</span> : null}
            </button>

            <button type="button" className="header-btn" onClick={onOpenSettings} title="Настройки" aria-label="Настройки">
              <IcoSettings />
            </button>

            <button
              type="button"
              className="header-btn header-btn--logout"
              onClick={onLogout}
              title="Выйти из аккаунта"
              aria-label="Выйти"
            >
              <IcoLogout />
            </button>
          </div>

          <div className="window-controls" aria-label="Управление окном">
            <button type="button" className="wctrl-btn wctrl-btn--minimize" onClick={onMinimize} title="Свернуть" aria-label="Свернуть окно">
              <IcoMinimize />
            </button>

            <button
              type="button"
              className={`wctrl-btn wctrl-btn--fullscreen${isFullscreen ? ' is-active' : ''}`}
              onClick={onToggleFullscreen}
              title={isFullscreen ? 'Выйти из полного экрана' : 'Полный экран'}
              aria-label={isFullscreen ? 'Выйти из полного экрана' : 'Полный экран'}
              aria-pressed={isFullscreen}
            >
              {isFullscreen ? <IcoExitFullscreen /> : <IcoExpand />}
            </button>

            <button type="button" className="wctrl-btn wctrl-btn--close" onClick={onCloseApp} title="Закрыть приложение" aria-label="Закрыть приложение">
              <IcoClose />
            </button>
          </div>
        </div>
      </div>
    </header>
  )
}
