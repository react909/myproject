from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic import AliasChoices, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "NurCRM Offline"
    app_version: str = "1.0.0"
    jwt_secret: str = Field(
        default="nurcrm-offline-local-secret-change-me",
        validation_alias=AliasChoices("JWT_SECRET", "NURCRM_JWT_SECRET"),
    )
    jwt_algorithm: str = "HS256"
    jwt_hours: int = 72
    sqlite_path: str = Field(
        default=str(Path.cwd() / "nurcrm.db"),
        validation_alias=AliasChoices("SQLITE_PATH", "NURCRM_SQLITE_PATH"),
    )
    host: str = "127.0.0.1"
    port: int = 8000

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @property
    def sqlite_dsn(self) -> str:
        path = Path(self.sqlite_path).resolve()
        path.parent.mkdir(parents=True, exist_ok=True)
        # SQLAlchemy async sqlite URL
        return f"sqlite+aiosqlite:///{path.as_posix()}"


@lru_cache
def get_settings() -> Settings:
    return Settings()
