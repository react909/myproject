from __future__ import annotations

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.security import get_current_user, require_roles
from app.db.database import get_db_session
from app.db.models import StoreSettings, User

router = APIRouter(prefix="/api/settings", tags=["settings"])


class StoreSettingsOut(BaseModel):
    installation_id: str
    edition: str
    company_name: str
    store_name: str
    owner_name: str
    inn: str
    email: str
    currency: str
    currency_label: str
    address: str
    phone: str
    setup_completed: bool


class StoreSettingsUpdate(BaseModel):
    # Edition is stored locally now. Future license activation may update it
    # through a dedicated service without changing the store-settings contract.
    edition: str | None = Field(default=None, pattern="^(start|standard)$")
    company_name: str | None = Field(default=None, max_length=255)
    store_name: str | None = Field(default=None, max_length=255)
    owner_name: str | None = Field(default=None, max_length=255)
    inn: str | None = Field(default=None, max_length=32)
    email: str | None = Field(default=None, max_length=255)
    currency: str | None = Field(default=None, max_length=16)
    currency_label: str | None = Field(default=None, max_length=32)
    address: str | None = Field(default=None, max_length=512)
    phone: str | None = Field(default=None, max_length=64)


async def _get_or_create(session: AsyncSession) -> StoreSettings:
    row = (await session.execute(select(StoreSettings).limit(1))).scalar_one_or_none()
    if row is None:
        row = StoreSettings()
        session.add(row)
        await session.commit()
        await session.refresh(row)
    return row


def _out(row: StoreSettings) -> StoreSettingsOut:
    return StoreSettingsOut(
        installation_id=row.installation_id,
        edition=row.edition,
        company_name=row.company_name,
        store_name=row.store_name,
        owner_name=row.owner_name,
        inn=row.inn,
        email=row.email,
        currency=row.currency,
        currency_label=row.currency_label,
        address=row.address,
        phone=row.phone,
        setup_completed=row.setup_completed,
    )


@router.get("/store", response_model=StoreSettingsOut)
async def get_store_settings(
    session: AsyncSession = Depends(get_db_session),
    _: User = Depends(get_current_user),
) -> StoreSettingsOut:
    return _out(await _get_or_create(session))


@router.patch("/store", response_model=StoreSettingsOut)
async def update_store_settings(
    payload: StoreSettingsUpdate,
    session: AsyncSession = Depends(get_db_session),
    _: User = Depends(require_roles("owner", "admin")),
) -> StoreSettingsOut:
    row = await _get_or_create(session)
    data = payload.model_dump(exclude_unset=True)
    for key, value in data.items():
        setattr(row, key, value)
    await session.commit()
    await session.refresh(row)
    return _out(row)


@router.get("/capabilities")
async def get_capabilities(
    session: AsyncSession = Depends(get_db_session),
    _: User = Depends(get_current_user),
) -> dict:
    store = await _get_or_create(session)
    return {
        "edition": store.edition,
        "mode": "offline",
        "installation_id": store.installation_id,
        # Contract reserved for future local-license and Cloud adapters.
        "license_activation_available": False,
        "cloud_migration_available": False,
        "custom_update_server_configured": False,
    }
