import { Link } from 'react-router-dom'

type Props = {
  totalReceipts: number
  filteredCount?: number
  periodLabel?: string
  onRefresh: () => void
  onExport: () => void
  isRefreshing?: boolean
  embedded?: boolean
}

const IcArrow = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none"
    stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M19 12H5m0 0 7 7m-7-7 7-7"/>
  </svg>
)
const IcRefresh = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none"
    stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M1 4v6h6M23 20v-6h-6"/>
    <path d="M20.49 9A9 9 0 0 0 5.64 5.64L1 10m22 4-4.64 4.36A9 9 0 0 1 3.51 15"/>
  </svg>
)
const IcExport = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none"
    stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>
  </svg>
)

export function ReceiptsHeader({ totalReceipts, filteredCount, periodLabel, onRefresh, onExport, isRefreshing, embedded }: Props) {
  return (
    <header className={`receipts-header${embedded ? ' receipts-header--embedded' : ''}`}>
      {!embedded && (
        <Link to="/" className="receipts-header__back">
          <IcArrow /> <span>Касса</span>
        </Link>
      )}

      <div className="receipts-header__title-block">
        <h1 className="receipts-header__title">Журнал чеков</h1>
        <p className="receipts-header__subtitle">
          {periodLabel ?? 'Сегодня'}
          &nbsp;·&nbsp; {(filteredCount ?? totalReceipts).toLocaleString('ru-RU')} чек(ов)
          &nbsp;·&nbsp; смотреть · печать · возврат
        </p>
      </div>

      <div className="receipts-header__actions">
        <button type="button" className="receipts-header__btn" onClick={onExport}>
          <IcExport /> <span>Экспорт</span>
        </button>
        <button
          type="button"
          className={`receipts-header__btn receipts-header__btn--primary`}
          onClick={onRefresh}
          disabled={isRefreshing}
        >
          <IcRefresh /> <span>{isRefreshing ? 'Обновление...' : 'Обновить'}</span>
        </button>
      </div>
    </header>
  )
}