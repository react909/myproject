import { useOutletContext } from 'react-router-dom'
import type { AppSettings } from '../appSettings'
import { SettingsHelpFooter } from '../SettingsHelpFooter'

type ContextType = {
  settings: AppSettings
  setSettings: React.Dispatch<React.SetStateAction<AppSettings>>
}

export function PaymentSection() {
  const { settings, setSettings } = useOutletContext<ContextType>()

  const pickQr = (files: FileList | null) => {
    const file = files?.[0]
    if (!file || !file.type.startsWith('image/')) return
    const reader = new FileReader()
    reader.onloadend = () => {
      const result = reader.result
      if (typeof result !== 'string') return
      setSettings((prev) => ({
        ...prev,
        paymentQr: { ...prev.paymentQr, imageDataUrl: result },
      }))
    }
    reader.readAsDataURL(file)
  }

  return (
    <section className="settings-section">
      <h2 className="settings-section__title">Оплата / QR</h2>
      <p className="settings-section__desc">
        QR хранится отдельно от товаров и показывается только при оплате картой.
      </p>

      <div className="settings-form">
        <label className="settings-field">
          <span className="settings-field__label">Название кассы / магазина</span>
          <input
            className="settings-field__input"
            value={settings.paymentQr.storeName ?? ''}
            onChange={(e) =>
              setSettings((prev) => ({
                ...prev,
                paymentQr: { ...prev.paymentQr, storeName: e.target.value },
              }))
            }
            placeholder="NurCRM"
          />
        </label>

        <p className="settings-field__hint">
          Адрес и телефон на чеке — в разделе <strong>Печать чеков</strong>.
        </p>

        <label className="settings-field">
          <span className="settings-field__label">QR картинка</span>
          <input className="settings-field__input" type="file" accept="image/*" onChange={(e) => pickQr(e.target.files)} />
        </label>

        {settings.paymentQr.imageDataUrl && (
          <div className="settings-qr-preview">
            <img src={settings.paymentQr.imageDataUrl} alt="QR для оплаты картой" />
            <button
              type="button"
              className="settings-btn"
              onClick={() =>
                setSettings((prev) => ({
                  ...prev,
                  paymentQr: { ...prev.paymentQr, imageDataUrl: undefined },
                }))
              }
            >
              Убрать QR
            </button>
          </div>
        )}

        <label className="settings-field">
          <span className="settings-field__label">QR ссылка / строка</span>
          <input
            className="settings-field__input"
            value={settings.paymentQr.paymentUrl ?? ''}
            onChange={(e) =>
              setSettings((prev) => ({
                ...prev,
                paymentQr: { ...prev.paymentQr, paymentUrl: e.target.value },
              }))
            }
            placeholder="https://..."
          />
        </label>
      </div>

      <SettingsHelpFooter>
        <p>
          Если QR-картинка тяжёлая, лучше использовать ссылку. Так приложение меньше хранит данных и быстрее открывает оплату.
        </p>
      </SettingsHelpFooter>
    </section>
  )
}
