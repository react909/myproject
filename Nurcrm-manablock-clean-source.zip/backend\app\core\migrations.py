from __future__ import annotations

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncConnection

from app.db.models import Base

SCHEMA_VERSION = 3


async def run_migrations(engine: AsyncEngine) -> None:
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
        await conn.execute(
            text(
                """
                CREATE TABLE IF NOT EXISTS schema_version (
                    id INTEGER PRIMARY KEY CHECK (id = 1),
                    version INTEGER NOT NULL
                )
                """
            )
        )
        row = (await conn.execute(text("SELECT version FROM schema_version WHERE id = 1"))).fetchone()
        current = int(row[0]) if row else 0
        if current < SCHEMA_VERSION:
            await _apply_upgrades(conn, current, SCHEMA_VERSION)
            if row:
                await conn.execute(
                    text("UPDATE schema_version SET version = :v WHERE id = 1"),
                    {"v": SCHEMA_VERSION},
                )
            else:
                await conn.execute(
                    text("INSERT INTO schema_version (id, version) VALUES (1, :v)"),
                    {"v": SCHEMA_VERSION},
                )
        # WAL for better concurrent read/write
        await conn.execute(text("PRAGMA journal_mode=WAL"))
        await conn.execute(text("PRAGMA foreign_keys=ON"))


async def _apply_upgrades(conn: AsyncConnection, from_version: int, to_version: int) -> None:
    if from_version < 2 <= to_version:
        columns = {
            row[1]
            for row in (
                await conn.execute(text("PRAGMA table_info(store_settings)"))
            ).fetchall()
        }
        additions = {
            "installation_id": "VARCHAR(36) NOT NULL DEFAULT ''",
            "edition": "VARCHAR(16) NOT NULL DEFAULT 'start'",
            "company_name": "VARCHAR(255) NOT NULL DEFAULT ''",
            "inn": "VARCHAR(32) NOT NULL DEFAULT ''",
            "email": "VARCHAR(255) NOT NULL DEFAULT ''",
        }
        for name, definition in additions.items():
            if name not in columns:
                await conn.execute(
                    text(f"ALTER TABLE store_settings ADD COLUMN {name} {definition}")
                )
        await conn.execute(
            text(
                """
                UPDATE store_settings
                SET installation_id = lower(hex(randomblob(4))) || '-' ||
                    lower(hex(randomblob(2))) || '-4' ||
                    substr(lower(hex(randomblob(2))), 2) || '-a' ||
                    substr(lower(hex(randomblob(2))), 2) || '-' ||
                    lower(hex(randomblob(6)))
                WHERE installation_id = ''
                """
            )
        )
    if from_version < 3 <= to_version:
        columns = {
            row[1]
            for row in (
                await conn.execute(text("PRAGMA table_info(store_settings)"))
            ).fetchall()
        }
        if "setup_version" not in columns:
            # Existing installations must pass through the corrected setup
            # flow once. Newly completed setups write the current version.
            await conn.execute(
                text(
                    "ALTER TABLE store_settings "
                    "ADD COLUMN setup_version INTEGER NOT NULL DEFAULT 0"
                )
            )
