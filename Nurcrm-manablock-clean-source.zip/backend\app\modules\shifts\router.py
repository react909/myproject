from __future__ import annotations

from datetime import UTC, datetime

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.security import get_current_user
from app.db.database import get_db_session
from app.db.models import Shift, User

router = APIRouter(prefix="/api/shifts", tags=["shifts"])


class ShiftOut(BaseModel):
    id: int
    status: str
    opened_at: str
    closed_at: str | None
    open_cash: float
    close_cash: float
    sales_count: int
    sales_total: float
    user_id: int
    cashbox_name: str


class ShiftOpenRequest(BaseModel):
    open_cash: float = Field(default=0, ge=0)
    cashbox_name: str = "Основная"


class ShiftCloseRequest(BaseModel):
    close_cash: float = Field(default=0, ge=0)


def _shift_out(s: Shift) -> ShiftOut:
    return ShiftOut(
        id=s.id,
        status=s.status,
        opened_at=s.opened_at.isoformat() if s.opened_at else "",
        closed_at=s.closed_at.isoformat() if s.closed_at else None,
        open_cash=s.open_cash,
        close_cash=s.close_cash,
        sales_count=s.sales_count,
        sales_total=s.sales_total,
        user_id=s.user_id,
        cashbox_name=s.cashbox_name,
    )


@router.get("/current", response_model=ShiftOut | None)
async def current_shift(
    session: AsyncSession = Depends(get_db_session),
    user: User = Depends(get_current_user),
) -> ShiftOut | None:
    shift = (
        await session.execute(
            select(Shift).where(Shift.status == "open", Shift.user_id == user.id).order_by(Shift.id.desc())
        )
    ).scalar_one_or_none()
    return _shift_out(shift) if shift else None


@router.post("/open", response_model=ShiftOut, status_code=status.HTTP_201_CREATED)
async def open_shift(
    payload: ShiftOpenRequest,
    session: AsyncSession = Depends(get_db_session),
    user: User = Depends(get_current_user),
) -> ShiftOut:
    existing = (
        await session.execute(
            select(Shift).where(Shift.status == "open", Shift.user_id == user.id)
        )
    ).scalar_one_or_none()
    if existing:
        return _shift_out(existing)
    shift = Shift(
        user_id=user.id,
        open_cash=payload.open_cash,
        cashbox_name=payload.cashbox_name,
        status="open",
    )
    session.add(shift)
    await session.commit()
    await session.refresh(shift)
    return _shift_out(shift)


@router.post("/{shift_id}/close", response_model=ShiftOut)
async def close_shift(
    shift_id: int,
    payload: ShiftCloseRequest,
    session: AsyncSession = Depends(get_db_session),
    user: User = Depends(get_current_user),
) -> ShiftOut:
    shift = (await session.execute(select(Shift).where(Shift.id == shift_id))).scalar_one_or_none()
    if not shift or shift.status != "open":
        raise HTTPException(status_code=404, detail="Открытая смена не найдена.")
    if shift.user_id != user.id and user.role not in ("owner", "admin"):
        raise HTTPException(status_code=403, detail="Недостаточно прав.")
    shift.status = "closed"
    shift.closed_at = datetime.now(UTC)
    shift.close_cash = payload.close_cash
    await session.commit()
    await session.refresh(shift)
    return _shift_out(shift)


@router.get("", response_model=list[ShiftOut])
async def list_shifts(
    limit: int = 50,
    session: AsyncSession = Depends(get_db_session),
    _: User = Depends(get_current_user),
) -> list[ShiftOut]:
    rows = (
        await session.execute(select(Shift).order_by(Shift.id.desc()).limit(min(limit, 200)))
    ).scalars().all()
    return [_shift_out(s) for s in rows]
