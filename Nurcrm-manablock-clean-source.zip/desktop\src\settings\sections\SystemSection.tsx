// src/settings/sections/SystemSection.tsx

import { useOutletContext } from 'react-router-dom'
import type { AppSettings } from '../appSettings'
import { SettingsHelpFooter } from '../SettingsHelpFooter'

type ContextType = {
  settings: AppSettings
  setSettings: React.Dispatch<React.SetStateAction<AppSettings>>
}

export function SystemSection() {
  const { settings, setSettings } = useOutletContext<ContextType>()

  const patchSystem = (patch: Partial<AppSettings['system']>) => {
    setSettings((prev) => {
      const next = { ...prev, system: { ...prev.system, ...patch } }
      void window.systemAPI?.setAutoLaunch?.(next.system.startWithWindows)
      void window.systemAPI?.applyKiosk?.(next.system.alwaysFullscreen)
      return next
    })
  }

  return (
    <section className="settings-section">
      <h2 className="settings-section__title">Система</h2>
      <p className="settings-section__desc">Общее поведение приложения после запуска</p>

      <div className="settings-form">
        <label className="settings-toggle">
          <input
            type="checkbox"
            checked={settings.system.startWithWindows}
            onChange={(e) => patchSystem({ startWithWindows: e.target.checked })}
          />
          <span>Автозапуск вместе с Windows</span>
        </label>

        <label className="settings-toggle">
          <input
            type="checkbox"
            checked={settings.system.showKeyboardOnFocus}
            onChange={(e) => patchSystem({ showKeyboardOnFocus: e.target.checked })}
          />
          <span>Встроенная клавиатура NurCRM при фокусе поля ввода</span>
        </label>

        <label className="settings-toggle">
          <input
            type="checkbox"
            checked={settings.system.alwaysFullscreen}
            onChange={(e) => patchSystem({ alwaysFullscreen: e.target.checked })}
          />
          <span>Полный экран без рамки (скрыть кнопку окна)</span>
        </label>
        <p className="settings-field__hint">
          Для режима киоска: рабочий стол пользователя виден только в окне приложения.
        </p>
      </div>

      <SettingsHelpFooter title="Чем «Система» отличается от других экранов">
        <p>
          Здесь собрано то, что относится к <strong>запуску Windows и режиму окна приложения</strong>, а не к
          весам, чекам или обновлениям прошивки.
        </p>
        <ul>
          <li>«Экран» — про размер и плотность элементов в каталоге.</li>
          <li>«Подключение» — про COM и протокол для оборудования.</li>
        </ul>
        <p className="settings-help-footer__idea">
          <strong>Идеи:</strong> экспорт/импорт всех настроек в один файл; привязка к профилю кассира; отдельный
          «URL API» для сервера NurCRM — чтобы после тиражирования Manablock на сеть касс не править адреса
          вручную.
        </p>
      </SettingsHelpFooter>
    </section>
  )
}
