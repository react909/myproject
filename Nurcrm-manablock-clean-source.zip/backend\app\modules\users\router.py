from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.security import get_current_user, hash_password, require_roles
from app.db.database import get_db_session
from app.db.models import User

router = APIRouter(prefix="/api/users", tags=["users"])


class UserOut(BaseModel):
    id: int
    username: str
    full_name: str
    role: str
    is_active: bool


class UserCreate(BaseModel):
    username: str = Field(min_length=2, max_length=255)
    password: str = Field(min_length=4, max_length=128)
    full_name: str = Field(default="", max_length=255)
    role: str = Field(default="cashier", pattern="^(admin|cashier)$")


class UserUpdate(BaseModel):
    full_name: str | None = None
    role: str | None = Field(default=None, pattern="^(admin|cashier|owner)$")
    is_active: bool | None = None
    password: str | None = Field(default=None, min_length=4, max_length=128)


@router.get("", response_model=list[UserOut])
async def list_users(
    session: AsyncSession = Depends(get_db_session),
    _: User = Depends(require_roles("owner", "admin")),
) -> list[UserOut]:
    rows = (await session.execute(select(User).order_by(User.id))).scalars().all()
    return [
        UserOut(
            id=u.id,
            username=u.username,
            full_name=u.full_name,
            role=u.role,
            is_active=u.is_active,
        )
        for u in rows
    ]


@router.post("", response_model=UserOut, status_code=status.HTTP_201_CREATED)
async def create_user(
    payload: UserCreate,
    session: AsyncSession = Depends(get_db_session),
    _: User = Depends(require_roles("owner", "admin")),
) -> UserOut:
    exists = (
        await session.execute(select(User).where(User.username == payload.username.strip()))
    ).scalar_one_or_none()
    if exists:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Логин занят.")
    user = User(
        username=payload.username.strip(),
        full_name=payload.full_name.strip(),
        hashed_password=hash_password(payload.password),
        role=payload.role,
    )
    session.add(user)
    await session.commit()
    await session.refresh(user)
    return UserOut(
        id=user.id,
        username=user.username,
        full_name=user.full_name,
        role=user.role,
        is_active=user.is_active,
    )


@router.patch("/{user_id}", response_model=UserOut)
async def update_user(
    user_id: int,
    payload: UserUpdate,
    session: AsyncSession = Depends(get_db_session),
    current: User = Depends(require_roles("owner", "admin")),
) -> UserOut:
    user = (await session.execute(select(User).where(User.id == user_id))).scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="Пользователь не найден.")
    if user.role == "owner" and current.role != "owner":
        raise HTTPException(status_code=403, detail="Нельзя менять владельца.")
    if payload.full_name is not None:
        user.full_name = payload.full_name
    if payload.role is not None and user.role != "owner":
        user.role = payload.role
    if payload.is_active is not None and user.role != "owner":
        user.is_active = payload.is_active
    if payload.password:
        user.hashed_password = hash_password(payload.password)
    await session.commit()
    await session.refresh(user)
    return UserOut(
        id=user.id,
        username=user.username,
        full_name=user.full_name,
        role=user.role,
        is_active=user.is_active,
    )
